"""Giao diện chung: màu, chữ, khung 3 ngăn, điều hướng, âm thanh, đọc tiếng Anh, đồng hồ học.

QUY ƯỚC CHO CÁC TRANG
- Chuyển trang:   ui.go("n3", "quiz", eid="de01")   (KHÔNG gọi st.rerun() trực tiếp; dùng ui.rerun())
- Trang hiện tại: ui.view(), ui.params()
- Âm thanh:       ui.fx("correct", streak=3) · ui.fx("wrong", text="câu đúng để đọc") · ui.fx("speak", text=...)
- HTML an toàn:   ui.md("chữ có **đậm**")  → chuỗi HTML;  ui.html("<div>..</div>") → vẽ ra
"""
from __future__ import annotations

import html as _html
import json
import re
import time

import streamlit as st

from . import clock, progress, storage

TABS = [("n1", "Lịch học", ":material/calendar_month:"),
        ("n2", "Từ & Ngữ pháp", ":material/menu_book:"),
        ("n3", "Đề thi", ":material/edit_note:")]

ROLE = {  # màu các cụm khi dịch
    "ai": ("AI", "r-ai"), "lam": ("LÀM GÌ", "r-lam"), "cai": ("CÁI GÌ", "r-cai"),
    "odau": ("Ở ĐÂU", "r-odau"), "khi": ("KHI NÀO", "r-khi"), "them": ("THÊM", "r-them"),
}


# ======================= ĐIỀU HƯỚNG =======================
def _ss():
    ss = st.session_state
    ss.setdefault("tab", "n1")
    ss.setdefault("view", "home")
    ss.setdefault("params", {})
    return ss


def tab() -> str:
    return _ss().tab


def view() -> str:
    return _ss().view


def params() -> dict:
    return _ss().params


def go(tab_: str, view_: str = "home", **kw):
    ss = _ss()
    ss.tab, ss.view, ss.params = tab_, view_, kw
    ss.scroll_top = True
    rerun()


def rerun():
    storage.flush()
    st.rerun()


# ======================= CHỮ & KHỐI HTML =======================
_BOLD = re.compile(r"\*\*(.+?)\*\*")


def md(text) -> str:
    """Chuỗi thường → HTML an toàn: **đậm** → <b>, xuống dòng → <br>."""
    s = _html.escape(str(text or ""))
    s = _BOLD.sub(r"<b>\1</b>", s)
    return s.replace("\n", "<br>")


def esc(text) -> str:
    return _html.escape(str(text or ""))


def html(s: str):
    st.markdown(s, unsafe_allow_html=True)


def box(color: str, label: str, body_html: str) -> str:
    """Hộp màu: color = green|red|blue|orange|gray."""
    return f'<div class="hb-box {color}"><div class="hb-box-label">{esc(label)}</div>{body_html}</div>'


def bar(frac: float, color: str = "green") -> str:
    p = max(0, min(100, round(frac * 100)))
    return f'<div class="hb-bar {color}"><span style="width:{p}%"></span></div>'


def chunks_html(chunks: list[dict], vi_line: str = "") -> str:
    """Các cụm dịch có màu theo vai (AI · LÀM GÌ · CÁI GÌ ...)."""
    parts = []
    for c in chunks:
        lab, cls = ROLE.get(c.get("role", ""), ("", "r-them"))
        parts.append(f'<span class="hb-chunk {cls}"><small>{lab}</small><b>{esc(c["en"])}</b>'
                     f'<span>{esc(c["vi"])}</span></span>')
    line = f'<div class="hb-vi-line">{md(vi_line)}</div>' if vi_line else ""
    return f'<div class="hb-chunks">{"".join(parts)}</div>{line}'


def title(text: str, sub: str = ""):
    html(f'<div class="hb-title">{esc(text)}</div>' + (f'<div class="hb-sub">{md(sub)}</div>' if sub else ""))


def back(label: str, tab_: str, view_: str = "home", key: str = "back", **kw):
    if st.button(f"← {label}", key=f"hbback_{key}", type="tertiary"):
        go(tab_, view_, **kw)


# ======================= ÂM THANH & ĐỌC =======================
def fx(kind: str, **kw):
    """Xếp 1 hiệu ứng để phát khi trang vẽ xong.
    kind: correct(streak) | wrong(text) | speak(text) | bell(i: 0 nhẹ, 1 còi, 2 chuông trường)"""
    s = storage.db()["settings"]
    if kind in ("correct", "wrong", "bell") and not s.get("sound", True):
        if kind == "wrong" and s.get("speak_wrong", True) and kw.get("text"):
            kind = "speak"
            kw = {"text": kw["text"], "delay": 300}
        else:
            return
    if kind == "wrong" and not s.get("speak_wrong", True):
        kw.pop("text", None)
    st.session_state.setdefault("_fx", []).append({"k": kind, **kw})


def speak_button(text: str, key: str, label: str = "Nghe", icon: str = ":material/volume_up:"):
    if st.button(label, key=f"spk_{key}", icon=icon):
        fx("speak", text=text)


_JS_PATH = None


def _hb_js() -> str:
    global _JS_PATH
    from pathlib import Path
    if _JS_PATH is None:
        _JS_PATH = (Path(__file__).parent / "hb.js").read_text(encoding="utf-8")
    return _JS_PATH


def render_bridge():
    """Cài thư viện âm thanh + đồng hồ vào trang (1 lần) và phát các hiệu ứng đang chờ."""
    effects = st.session_state.pop("_fx", [])
    nonce = f"{time.time():.6f}" if effects else "idle"
    code = json.dumps(_hb_js())
    top = "true" if st.session_state.pop("scroll_top", False) else "false"
    with st.container(key="hbfx"):
        st.iframe(f"""<script>
(function(){{
  var P = window.parent;
  try {{
    if (!P.HB || P.HB.ver !== "7") {{
      var s = P.document.createElement('script'); s.textContent = {code}; P.document.head.appendChild(s);
    }}
    if ({top}) {{ var m = P.document.querySelector('[data-testid="stMain"]') || P.document.scrollingElement; if (m) m.scrollTo(0,0); P.scrollTo(0,0); }}
    P.HB.run({json.dumps(effects)}, "{nonce}");
  }} catch(e) {{ console.log("HB", e); }}
}})();
</script>""", height=1)


# ======================= KHUNG TRANG =======================
LIGHT = dict(bg="#F6F5EE", card="#FFFFFF", ink="#1F2A24", muted="#5B6660", line="#DCDDD3", soft="#EEEEE6",
             green="#2F7A4D", green_soft="#E3F0E6", green_ink="#1F5C38",
             orange="#F2A65A", orange_dark="#C96A1B", orange_soft="#FCEBDC", orange_ink="#8A4510",
             ok="#237A45", ok_soft="#DDF1E3", bad="#B4233C", bad_soft="#FBE3E7",
             blue_soft="#E8ECF4", blue_ink="#34466B", purple_soft="#EFE6F5", purple_ink="#5B3A78")
DARK = dict(bg="#121814", card="#1C2420", ink="#E8EDE9", muted="#A5B0A9", line="#33403A", soft="#26302B",
            green="#4FA36F", green_soft="#1F3A2A", green_ink="#A8DDB9",
            orange="#F2A65A", orange_dark="#F2A65A", orange_soft="#3B2A1A", orange_ink="#F6C590",
            ok="#5CC184", ok_soft="#1D3B29", bad="#F07A8E", bad_soft="#43222A",
            blue_soft="#222B3D", blue_ink="#B9C6E4", purple_soft="#2F2538", purple_ink="#D3BCE6")


def is_dark() -> bool:
    mode = storage.db()["settings"].get("theme", "auto")
    return mode == "dark" or (mode == "auto" and clock.is_night())


def inject_css():
    c = DARK if is_dark() else LIGHT
    vars_ = ";".join(f"--hb-{k.replace('_', '-')}:{v}" for k, v in c.items())
    st.markdown(f"<style>:root{{{vars_}}}</style>", unsafe_allow_html=True)
    st.markdown(_CSS, unsafe_allow_html=True)
    if is_dark():
        st.markdown(_DARK_CSS, unsafe_allow_html=True)


def header():
    left = clock.days_left()
    s = progress.streak()
    cd = "Hôm nay thi!" if left == 0 else ("Đã thi xong" if left < 0 else f"Còn <b>{left}</b> ngày")
    streak = f'<span class="hb-chip orange">Chuỗi <b>{s}</b> ngày</span>' if s else \
        '<span class="hb-chip gray">Học hôm nay để mở chuỗi</span>'
    err = st.session_state.get("db_error")
    html(f'<div class="hb-head"><div class="hb-brand">Học Bá</div>'
         f'<div class="hb-head-chips"><span class="hb-chip green">{cd}</span>{streak}</div></div>')
    if err:
        st.warning(err, icon=":material/cloud_off:")


def nav():
    with st.container(key="hbnav"):
        for tid, label, icon in TABS:
            active = tab() == tid
            if st.button(label, key=f"nav_{tid}", icon=icon, type="primary" if active else "secondary",
                         width="stretch"):
                if not active or view() != "home":
                    go(tid, "home")


@st.fragment(run_every=15)
def autosave():
    """Chạy nền mỗi 15 giây: còn thay đổi chưa lưu thì lưu lên GitHub."""
    if st.session_state.get("db_dirty"):
        storage.flush(force=True)


_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=Lexend:wght@500;600;700&display=swap');
html, body, .stApp, [data-testid="stAppViewContainer"] { background: var(--hb-bg) !important; color: var(--hb-ink); }
.stApp, .stApp p, .stApp li, .stApp label, .stApp input, .stApp textarea, .stApp button, .stMarkdown {
  font-family: 'Be Vietnam Pro', system-ui, sans-serif; }
.stApp p, .stApp li { font-size: 16px; line-height: 1.55; }
[data-testid="stHeader"], [data-testid="stToolbar"], [data-testid="stDecoration"], #MainMenu, footer,
[data-testid="stStatusWidget"] { display: none !important; }
[data-testid="stMainBlockContainer"], .block-container { max-width: 1080px; padding-top: 12px !important;
  padding-bottom: 110px !important; padding-left: 16px; padding-right: 16px; }
.st-key-hbfx { position: absolute !important; width: 0 !important; height: 0 !important; overflow: hidden; }
.st-key-hbfx iframe { width: 0 !important; height: 0 !important; border: 0; }

/* ---- đầu trang ---- */
.hb-head { display:flex; align-items:center; gap:10px; flex-wrap:wrap; padding: 4px 140px 6px 0; min-height: 44px; }
.hb-brand { font-family: Lexend, sans-serif; font-weight: 700; font-size: 24px; color: var(--hb-green); }
.hb-head-chips { display:flex; gap:6px; flex-wrap:wrap; }
@media (max-width: 899px) { .hb-head { padding-right: 0; gap: 4px 10px; } .hb-brand { flex: 1 1 100%; padding-right: 140px; } }
div:has(> .st-key-hbnav), div:has(> .st-key-hbfx) { position: absolute !important; height: 0 !important; margin: 0 !important; }
/* khối chỉ chứa <style> thì không chiếm chỗ */
[data-testid="stElementContainer"]:has(> [data-testid="stMarkdown"] style):not(:has(.hb-head)) { display: none !important; }

/* ---- thanh 3 ngăn: điện thoại = thanh dưới, laptop = cột trái ---- */
.st-key-hbnav { position: fixed !important; z-index: 990; left: 0; right: 0; bottom: 0; margin: 0 !important;
  background: var(--hb-card); border-top: 1px solid var(--hb-line); padding: 6px 8px calc(6px + env(safe-area-inset-bottom));
  display: flex !important; flex-direction: row !important; gap: 6px !important; }
.st-key-hbnav > div { flex: 1 1 0; min-width: 0; width: auto !important; }
.st-key-hbnav [data-testid="stButton"], .st-key-hbnav button { width: 100% !important; }
.st-key-hbnav button { min-height: 54px !important; flex-direction: column; gap: 0 !important; border-radius: 14px !important;
  padding: 4px 2px !important; border: 0 !important; }
.st-key-hbnav button p { font-size: 12.5px !important; font-weight: 600; white-space: nowrap; }
.st-key-hbnav button[kind="secondary"] { background: transparent !important; color: var(--hb-muted) !important; }
.st-key-hbnav button[kind="primary"] { background: var(--hb-green-soft) !important; color: var(--hb-green-ink) !important; }
@media (min-width: 900px) {
  .st-key-hbnav { top: 0; bottom: 0; right: auto; width: 104px; flex-direction: column !important; justify-content: flex-start;
    padding: 76px 8px 8px; border-top: 0; border-right: 1px solid var(--hb-line); }
  .st-key-hbnav > div { flex: 0 0 auto; }
  .st-key-hbnav button { min-height: 72px !important; }
  .st-key-hbnav button p { white-space: normal; text-align: center; line-height: 1.2; }
  [data-testid="stMainBlockContainer"], .block-container { padding-left: 128px !important; padding-bottom: 48px !important; }
}

/* ---- nút ---- */
.stApp button[kind="primary"], .stApp button[kind="secondary"] { min-height: 46px; border-radius: 14px; font-weight: 600; }
.stApp button[kind="primary"] p, .stApp button[kind="secondary"] p { font-size: 15.5px; font-weight: 600; }
.stApp button[kind="secondary"] { background: var(--hb-card); border: 1.5px solid var(--hb-line); color: var(--hb-ink); }
.stApp button[kind="tertiary"] { color: var(--hb-green); font-weight: 600; padding-left: 0; }
.stApp button[kind="tertiary"] p { font-size: 15px; font-weight: 600; }

/* ---- khối dùng chung ---- */
.hb-title { font-family: Lexend, sans-serif; font-weight: 700; font-size: 22px; line-height: 1.3; margin: 4px 0 2px; color: var(--hb-ink); }
.hb-sub { color: var(--hb-muted); font-size: 14.5px; margin-bottom: 8px; }
.hb-h2 { font-family: Lexend, sans-serif; font-weight: 600; font-size: 17px; margin: 14px 0 6px; color: var(--hb-ink); }
.hb-muted { color: var(--hb-muted); font-size: 14px; }
.hb-card { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 18px; padding: 14px 16px; margin: 0 0 10px; color: var(--hb-ink); }
.hb-card.green { background: var(--hb-green-soft); border-color: transparent; }
.hb-card.orange { background: var(--hb-orange-soft); border-color: transparent; }
.hb-chip { display:inline-flex; align-items:center; gap:4px; padding: 3px 10px; border-radius: 999px; font-size: 13px; font-weight: 600; white-space: nowrap; }
.hb-chip.green { background: var(--hb-green-soft); color: var(--hb-green-ink); }
.hb-chip.orange { background: var(--hb-orange-soft); color: var(--hb-orange-ink); }
.hb-chip.red { background: var(--hb-bad-soft); color: var(--hb-bad); }
.hb-chip.blue { background: var(--hb-blue-soft); color: var(--hb-blue-ink); }
.hb-chip.gray { background: var(--hb-soft); color: var(--hb-muted); }
.hb-box { border-radius: 16px; padding: 12px 14px; margin: 0 0 10px; font-size: 15.5px; line-height: 1.55; color: var(--hb-ink); }
.hb-box-label { font-family: Lexend, sans-serif; font-weight: 700; font-size: 13px; letter-spacing: .3px; margin-bottom: 4px; }
.hb-box.green { background: var(--hb-ok-soft); } .hb-box.green .hb-box-label { color: var(--hb-ok); }
.hb-box.red { background: var(--hb-bad-soft); } .hb-box.red .hb-box-label { color: var(--hb-bad); }
.hb-box.blue { background: var(--hb-blue-soft); } .hb-box.blue .hb-box-label { color: var(--hb-blue-ink); }
.hb-box.orange { background: var(--hb-orange-soft); } .hb-box.orange .hb-box-label { color: var(--hb-orange-ink); }
.hb-box.gray { background: var(--hb-soft); } .hb-box.gray .hb-box-label { color: var(--hb-muted); }
.hb-bar { height: 10px; border-radius: 99px; background: var(--hb-soft); overflow: hidden; }
.hb-bar span { display:block; height: 100%; border-radius: 99px; background: var(--hb-green); }
.hb-bar.orange span { background: var(--hb-orange); } .hb-bar.red span { background: var(--hb-bad); }
.hb-ok { color: var(--hb-ok); font-weight: 700; } .hb-bad { color: var(--hb-bad); font-weight: 700; }

/* ---- câu hỏi ---- */
.hb-prompt { color: var(--hb-muted); font-size: 14px; margin-bottom: 4px; }
.hb-q { font-size: 19px; line-height: 1.55; font-weight: 500; color: var(--hb-ink); margin: 2px 0 10px; }
.hb-opt { display:flex; gap:10px; align-items:flex-start; border-radius: 14px; padding: 10px 12px; margin: 0 0 8px;
  background: var(--hb-card); border: 1.5px solid var(--hb-line); color: var(--hb-ink); }
.hb-opt .k { flex: 0 0 30px; height: 30px; border-radius: 9px; background: var(--hb-soft); display:flex; align-items:center;
  justify-content:center; font-weight: 700; }
.hb-opt .t { flex: 1; font-size: 16px; } .hb-opt .t small { display:block; color: var(--hb-muted); font-size: 14px; margin-top: 2px; }
.hb-opt .m { font-weight: 800; font-size: 18px; }
.hb-opt.ok { background: var(--hb-ok-soft); border: 2px solid var(--hb-ok); } .hb-opt.ok .k { background: var(--hb-ok); color: #fff; } .hb-opt.ok .m { color: var(--hb-ok); }
.hb-opt.bad { background: var(--hb-bad-soft); border: 2px solid var(--hb-bad); } .hb-opt.bad .k { background: var(--hb-bad); color: #fff; } .hb-opt.bad .m { color: var(--hb-bad); }
.hb-passage { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 16px; padding: 12px 14px;
  font-size: 15.5px; line-height: 1.7; max-height: 340px; overflow-y: auto; color: var(--hb-ink); }

/* ---- cụm dịch ---- */
.hb-chunks { display:flex; flex-wrap: wrap; gap: 6px; margin: 4px 0 8px; }
.hb-chunk { display:inline-flex; flex-direction: column; border-radius: 12px; padding: 5px 10px; min-width: 60px; }
.hb-chunk small { font-size: 10.5px; font-weight: 700; letter-spacing: .4px; opacity: .8; }
.hb-chunk b { font-size: 15px; } .hb-chunk span { font-size: 14px; }
.r-ai { background: var(--hb-blue-soft); color: var(--hb-blue-ink); }
.r-lam { background: var(--hb-ok-soft); color: var(--hb-green-ink); }
.r-cai { background: var(--hb-orange-soft); color: var(--hb-orange-ink); }
.r-odau { background: var(--hb-purple-soft); color: var(--hb-purple-ink); }
.r-khi { background: var(--hb-soft); color: var(--hb-ink); }
.r-them { background: var(--hb-soft); color: var(--hb-muted); }
.hb-vi-line { font-size: 15.5px; color: var(--hb-ink); background: var(--hb-soft); border-radius: 12px; padding: 8px 12px; margin-bottom: 8px; }

/* chỉ hiện trên điện thoại / chỉ hiện trên laptop */
@media (max-width: 899px) { .hb-desk { display: none !important; } }
@media (min-width: 900px) { .hb-mob { display: none !important; } }

/* ---- thẻ từ ---- */
.hb-flash { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 22px; padding: 22px 18px; text-align: center; margin-bottom: 10px; color: var(--hb-ink); }
.hb-flash .w { font-family: Lexend, sans-serif; font-size: 34px; font-weight: 700; }
.hb-flash .ipa { color: var(--hb-muted); font-size: 16px; }

/* ---- bảng ---- */
.hb-table { width: 100%; border-collapse: collapse; font-size: 14.5px; color: var(--hb-ink); }
.hb-table th { text-align: left; color: var(--hb-muted); font-weight: 600; padding: 6px 6px; border-bottom: 1px solid var(--hb-line); }
.hb-table td { padding: 8px 6px; border-bottom: 1px solid var(--hb-line); vertical-align: top; }

/* ô vuông ngày học */
.hb-days { display:grid; grid-template-columns: repeat(7, 1fr); gap: 5px; }
.hb-days div { aspect-ratio: 1; border-radius: 7px; background: var(--hb-soft); display:flex; align-items:center; justify-content:center; font-size: 11px; color: var(--hb-muted); }
.hb-days div.on { background: var(--hb-green); color: #fff; } .hb-days div.today { outline: 2px solid var(--hb-orange); }
.hb-days div.exam { background: var(--hb-orange); color: #fff; }

[data-testid="stDialog"] section[role="dialog"] { border-radius: 22px !important; }
[data-testid="stDialog"] button[kind="primary"], [data-testid="stDialog"] button[kind="secondary"] { min-height: 46px; border-radius: 14px; font-weight: 600; }
.stApp button[data-variant="segmented_control"], .stApp button[data-variant="pills"] { min-height: 40px; }
[data-testid="stExpander"] details { border-radius: 16px !important; border-color: var(--hb-line) !important; background: var(--hb-card); }
[data-testid="stExpander"] summary p { font-weight: 600; }
</style>
"""

_DARK_CSS = """
<style>
.stApp [data-testid="stMarkdownContainer"], .stApp [data-testid="stWidgetLabel"] p, .stApp label, .stApp p, .stApp li,
.stApp h1, .stApp h2, .stApp h3, .stApp [data-testid="stCaptionContainer"] { color: var(--hb-ink) !important; }
.stApp [data-testid="stCaptionContainer"] p { color: var(--hb-muted) !important; }
.stApp button[kind="secondary"], .stApp button[kind="secondaryFormSubmit"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
.stApp input, .stApp textarea, .stApp [data-baseweb="select"] > div, .stApp [data-baseweb="input"],
.stApp [data-baseweb="textarea"], .stApp [data-testid="stNumberInputContainer"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
.stApp [data-baseweb="popover"] li, .stApp [data-baseweb="menu"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; }
.stApp [data-testid="stFileUploaderDropzone"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; }
.stApp [data-testid="stExpander"] details, .stApp [data-testid="stExpander"] summary { background: var(--hb-card) !important; color: var(--hb-ink) !important; }
.stApp button[data-variant="segmented_control"], .stApp button[data-variant="pills"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
.stApp button[data-variant="segmented_control"] p, .stApp button[data-variant="pills"] p { color: inherit !important; }
.stApp button[data-variant="segmented_control"][aria-checked="true"], .stApp button[data-variant="segmented_control"][data-selected="true"],
.stApp button[data-variant="pills"][aria-checked="true"], .stApp button[data-variant="pills"][data-selected="true"] { background: var(--hb-green-soft) !important; color: var(--hb-green-ink) !important; border-color: var(--hb-green) !important; }
.stApp [data-testid="stTextInputRootElement"], .stApp [data-testid="stTextAreaRootElement"], .stApp [data-testid="stSelectbox"] div[role="combobox"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
[data-testid="stDialog"] section[role="dialog"], .stDialog [role="dialog"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; }
[data-testid="stDialog"] p, [data-testid="stDialog"] label, [data-testid="stDialog"] h2, [data-testid="stDialog"] span { color: var(--hb-ink) !important; }
[data-testid="stDialog"] button[kind="secondary"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
[data-testid="stDialog"] button[aria-label="Close"] svg { fill: var(--hb-ink) !important; color: var(--hb-ink) !important; }
.stApp [data-testid="stAlert"] { background: var(--hb-soft) !important; color: var(--hb-ink) !important; }
.stApp [data-testid="stCheckbox"] span, .stApp [data-testid="stRadio"] div { color: var(--hb-ink); }
.stApp [data-testid="stVerticalBlockBorderWrapper"] { border-color: var(--hb-line) !important; }
</style>
"""
