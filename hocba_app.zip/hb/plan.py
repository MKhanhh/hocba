"""Lịch học: việc của từng ngày, tick xong, dời ngày, tự đánh dấu xong, mục tiêu tuần.

Mỗi việc (task) trong data/schedule.json có dạng:
  {type: vocab|translate|wrong|lesson|exam|exam_weak|exam_day, ref?, mode?, part?, title, minutes, review?}
Mã việc (id) = "<ngày gốc>#<thứ tự>", ví dụ "2026-10-22#3".
"""
from __future__ import annotations

from datetime import date, timedelta

from . import data, progress, srs, storage
from .clock import EXAM_DAY, START_DAY, today


def _db():
    return storage.db()


def days() -> list[dict]:
    return data.schedule()


def day_info(d: date) -> dict | None:
    s = d.isoformat()
    for x in days():
        if x["date"] == s:
            return x
    return None


_CACHE: dict = {}


def _all_tasks() -> dict:
    if "all" in _CACHE:
        return _CACHE["all"]
    out = {}
    for x in days():
        for i, t in enumerate(x["tasks"]):
            out[f"{x['date']}#{i}"] = {**t, "id": f"{x['date']}#{i}", "orig": x["date"]}
    _CACHE["all"] = out
    return out


def task(tid: str) -> dict | None:
    return _all_tasks().get(tid)


def task_date(tid: str) -> str:
    return _db()["moves"].get(tid) or tid.split("#")[0]


def tasks_for(d: date) -> list[dict]:
    """Việc của ngày d (đã tính việc dời đi / dời đến). Mỗi việc có thêm id, orig, done, moved."""
    s = d.isoformat()
    out = []
    for tid, t in _all_tasks().items():
        if task_date(tid) == s:
            out.append({**t, "done": is_done(tid), "moved": tid in _db()["moves"]})
    return out


def is_done(tid: str) -> bool:
    return tid in _db()["tasks_done"]


def set_done(tid: str, done: bool = True):
    if done:
        _db()["tasks_done"][tid] = today().isoformat()
        progress.mark_activity()
    else:
        _db()["tasks_done"].pop(tid, None)
    storage.touch()


def move(tid: str, new_day: date):
    if new_day.isoformat() == tid.split("#")[0]:
        _db()["moves"].pop(tid, None)
    else:
        _db()["moves"][tid] = new_day.isoformat()
    storage.touch()


def budget(d: date) -> int:
    x = day_info(d)
    return x["budget"] if x else 0


def planned_minutes(d: date) -> int:
    return sum(t["minutes"] for t in tasks_for(d))


def free_minutes(d: date) -> int:
    return budget(d) - planned_minutes(d)


def move_choices(tid: str) -> list[tuple[date, int]]:
    """Các ngày có thể dời tới (từ hôm nay đến 21/11) kèm số phút còn rảnh."""
    t0 = max(today(), START_DAY)
    out = []
    d = t0
    while d < EXAM_DAY:
        if d.isoformat() != task_date(tid):
            out.append((d, free_minutes(d)))
        d += timedelta(days=1)
    return out


def suggest_day(tid: str) -> date | None:
    """Ngày gần nhất còn đủ giờ rảnh cho việc này."""
    t = task(tid)
    need = t["minutes"] if t else 30
    for d, free in move_choices(tid):
        if d > today() and free >= need:
            return d
    ch = move_choices(tid)
    return max(ch, key=lambda x: x[1])[0] if ch else None


def overdue() -> list[dict]:
    """Việc của những ngày trước hôm nay mà chưa xong."""
    t = today().isoformat()
    out = []
    for tid, tk in _all_tasks().items():
        if task_date(tid) < t and not is_done(tid):
            out.append({**tk, "done": False, "date": task_date(tid)})
    return out


def auto_done(type_: str, ref=None, part: str | None = None, mode: str | None = None):
    """Tự tick việc khớp sớm nhất (hôm nay hoặc còn nợ) khi người học làm xong việc đó trong app."""
    t = today().isoformat()
    cands = []
    for tid, tk in _all_tasks().items():
        if is_done(tid) or task_date(tid) > t or tk["type"] != type_:
            continue
        if ref is not None and str(tk.get("ref")) != str(ref):
            continue
        if part and tk.get("part") and tk["part"] != part:
            continue
        if mode and tk.get("mode") and tk["mode"] != mode:
            continue
        cands.append((0 if task_date(tid) == t else 1, task_date(tid), tid))
    if cands:   # ưu tiên việc của hôm nay, rồi tới việc nợ cũ nhất
        set_done(sorted(cands)[0][2])
        return True
    return False


def refresh_auto():
    """Gọi mỗi lần mở app: tick việc 'ôn thẻ', 'câu sai', 'luyện dịch' nếu đã làm đủ hôm nay."""
    t = today()
    for tk in tasks_for(t):
        if tk["done"]:
            continue
        if tk["type"] == "vocab" and srs.learned_on(t.isoformat())["new"] + srs.learned_on(t.isoformat())["reviews"] > 0 \
                and not srs.due_ids() and not srs.new_ids_today():
            set_done(tk["id"])
        elif tk["type"] == "translate" and progress.translate_count() >= 3:
            set_done(tk["id"])
        elif tk["type"] == "wrong" and progress.wrong_list() and not progress.wrong_due():
            set_done(tk["id"])


def week_of(d: date) -> list[date]:
    mon = d - timedelta(days=d.weekday())
    return [mon + timedelta(days=i) for i in range(7)]


def week_goals(d: date) -> dict:
    """Mục tiêu tuần chứa ngày d: {'tasks': (xong, tổng), 'words': (đã học mới, mục tiêu),
    'exams': (lượt đề xong, mục tiêu), 'lessons': (xong, mục tiêu)}"""
    wk = week_of(d)
    tasks = [tk for x in wk for tk in tasks_for(x)]
    words_target = sum(len((day_info(x) or {}).get("new_words", [])) for x in wk)
    words_done = sum(srs.learned_on(x.isoformat())["new"] for x in wk)
    ex = [tk for tk in tasks if tk["type"] in ("exam", "exam_weak")]
    le = [tk for tk in tasks if tk["type"] == "lesson"]
    return {
        "tasks": (sum(tk["done"] for tk in tasks), len(tasks)),
        "words": (words_done, words_target),
        "exams": (sum(tk["done"] for tk in ex), len(ex)),
        "lessons": (sum(tk["done"] for tk in le), len(le)),
    }


def start_target(tk: dict) -> tuple[str, str, dict]:
    """Nút 'Bắt đầu' của 1 việc mở trang nào: (tab, view, params)."""
    ty = tk["type"]
    if ty == "vocab":
        return "n2", "cards", {}
    if ty == "translate":
        return "n2", "translate", {}
    if ty == "lesson":
        return "n2", "lesson", {"lid": tk["ref"], "review": bool(tk.get("review"))}
    if ty == "exam":
        return "n3", "exam", {"eid": data.exam_id(tk["ref"]), "part": tk.get("part", "1-50"),
                              "mode": tk.get("mode", "new")}
    if ty == "exam_weak":
        eid = progress.weakest_exam()
        if eid:
            return "n3", "exam", {"eid": eid, "part": "1-50", "mode": "redo"}
        return "n3", "home", {}
    return "n3", "wrong", {}
