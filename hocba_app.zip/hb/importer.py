"""Đọc file người học tải lên (.docx / .pdf) → dữ liệu đề thi hoặc từ vựng.

Thuần Python (không cần Streamlit) để test riêng được:
    lines = read_text(file_bytes, "De 20.docx")
    ex = parse_exam(lines)      # {"questions", "passages", "problems"}
    ws = parse_vocab(lines)     # [{"word","ipa","pos","meaning","example"}]

Quy ước dòng do read_text trả về:
- Mỗi đoạn văn = 1 dòng. Xuống dòng mềm trong đoạn = tách thành nhiều dòng.
- Bảng nhiều cột: mỗi hàng = 1 dòng "| ô 1 | ô 2 | ... |".  Bảng 1 cột: mỗi đoạn trong ô = 1 dòng.
- Chữ in đậm / gạch chân / tô màu / tô nền được bọc trong ** ** (để nhận ra đáp án được đánh dấu).
- Danh sách tự đánh số của Word được thêm số vào đầu dòng ("1. ", "A. "...).
"""
from __future__ import annotations

import io
import re
import zipfile

PART_LABEL = {"vocab": "Từ vựng", "grammar": "Ngữ pháp", "transform": "Biến đổi câu",
              "cloze": "Điền từ", "reading": "Đọc hiểu"}
TRANSFORM_PROMPT = "Chọn câu có nghĩa giống câu gốc nhất:"
LETTERS = "ABCD"


class ReadError(Exception):
    """Không đọc được file. .kind = 'broken' | 'image' | 'type'."""

    def __init__(self, kind: str, msg: str = ""):
        super().__init__(msg or kind)
        self.kind = kind


# =====================================================================
#                              ĐỌC FILE
# =====================================================================
def read_text(file_bytes: bytes, filename: str) -> list[str]:
    name = (filename or "").lower()
    if name.endswith(".pdf") or file_bytes[:5] == b"%PDF-":
        return _read_pdf(file_bytes)
    if name.endswith(".docx") or file_bytes[:2] == b"PK":
        return _read_docx(file_bytes)
    raise ReadError("type", "Chỉ đọc được file .docx hoặc .pdf")


def _read_pdf(b: bytes) -> list[str]:
    try:
        from pypdf import PdfReader
        r = PdfReader(io.BytesIO(b))
        pages = [(p.extract_text() or "") for p in r.pages]
    except Exception as e:  # noqa: BLE001
        raise ReadError("broken", str(e)) from e
    lines = []
    for t in pages:
        for ln in t.replace("\r", "\n").split("\n"):
            ln = ln.replace(" ", " ").rstrip()
            if ln.strip():
                lines.append(ln.strip())
    if sum(len(x) for x in lines) < 40:
        raise ReadError("image", "PDF không có chữ")
    return lines


# ---------------- DOCX ----------------
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _wval(el, tag):
    if el is None:
        return None
    x = el.find(W + tag)
    if x is None:
        return None
    return x.get(W + "val", "true")


def _on(v) -> bool:
    return v is not None and v not in ("0", "false", "none", "off")


def _run_emph(r) -> bool:
    rpr = r.find(W + "rPr")
    if rpr is None:
        return False
    if _on(_wval(rpr, "b")) or _on(_wval(rpr, "u")):
        return True
    col = _wval(rpr, "color")
    if col and col.lower() not in ("auto", "000000", "true", "1f1f1f", "222222", "333333", "262626", "0d0d0d", "1a1a1a"):
        return True
    hl = _wval(rpr, "highlight")
    if hl and hl not in ("none", "true"):
        return True
    shd = rpr.find(W + "shd")
    if shd is not None and (shd.get(W + "fill") or "auto").lower() not in ("auto", "ffffff", "000000"):
        return True
    return False


def _encode(chars: list[tuple[str, bool]]) -> str:
    """[(chữ, có_nhấn)] → chuỗi có ** ** quanh phần nhấn (bỏ khoảng trắng ra ngoài)."""
    out = []
    i, n = 0, len(chars)
    while i < n:
        c, e = chars[i]
        if not e or not c.strip():
            out.append(c)
            i += 1
            continue
        j = i
        while j < n and (chars[j][1] or not chars[j][0].strip()):
            j += 1
        # lùi bỏ khoảng trắng cuối
        k = j
        while k > i and not chars[k - 1][0].strip():
            k -= 1
        out.append("**" + "".join(x for x, _ in chars[i:k]) + "**")
        out.append("".join(x for x, _ in chars[k:j]))
        i = j
    return "".join(out)


class _Numbering:
    """Tính số của danh sách tự đánh số trong Word (1. 2. 3. / a. b. c. / A. B. ...)."""

    def __init__(self, doc):
        self.fmt = {}      # (numId, ilvl) -> (numFmt, lvlText, start)
        self.count = {}    # numId -> [đếm mỗi cấp]
        self.style_num = {}
        try:
            numxml = doc.part.numbering_part.element
        except Exception:  # noqa: BLE001
            numxml = None
        if numxml is not None:
            absd = {}
            for a in numxml.findall(W + "abstractNum"):
                lv = {}
                for l in a.findall(W + "lvl"):
                    il = int(l.get(W + "ilvl", "0"))
                    lv[il] = (_wval(l, "numFmt") or "decimal", _wval(l, "lvlText") or f"%{il + 1}.",
                              int(_wval(l, "start") or 1))
                absd[a.get(W + "abstractNumId")] = lv
            for nm in numxml.findall(W + "num"):
                nid = nm.get(W + "numId")
                aid = _wval(nm, "abstractNumId")
                for il, v in absd.get(aid, {}).items():
                    self.fmt[(nid, il)] = v
        try:
            for s in doc.styles:
                el = s.element
                ppr = el.find(W + "pPr")
                if ppr is not None and ppr.find(W + "numPr") is not None:
                    npr = ppr.find(W + "numPr")
                    self.style_num[s.style_id] = (_wval(npr, "numId"), int(_wval(npr, "ilvl") or 0))
        except Exception:  # noqa: BLE001
            pass

    @staticmethod
    def _fmt(n: int, kind: str) -> str:
        if kind == "upperLetter":
            return chr(64 + (n - 1) % 26 + 1)
        if kind == "lowerLetter":
            return chr(96 + (n - 1) % 26 + 1)
        if kind in ("upperRoman", "lowerRoman"):
            vals = [(10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
            s, m = "", n
            for v, r in vals:
                while m >= v:
                    s += r
                    m -= v
            return s if kind == "upperRoman" else s.lower()
        if kind in ("bullet", "none"):
            return ""
        return str(n)

    def label(self, p) -> str:
        ppr = p.find(W + "pPr")
        nid, il = None, 0
        if ppr is not None:
            npr = ppr.find(W + "numPr")
            if npr is not None:
                nid, il = _wval(npr, "numId"), int(_wval(npr, "ilvl") or 0)
            elif ppr.find(W + "pStyle") is not None:
                sid = ppr.find(W + "pStyle").get(W + "val")
                if sid in self.style_num:
                    nid, il = self.style_num[sid]
        if not nid or nid == "0":
            return ""
        kind, text, start = self.fmt.get((nid, il), ("decimal", f"%{il + 1}.", 1))
        cnt = self.count.setdefault(nid, [0] * 9)
        cnt[il] += 1
        for k in range(il + 1, 9):
            cnt[k] = 0
        if kind == "bullet":
            return "• "
        out = text
        for k in range(il + 1):
            kk, _, st = self.fmt.get((nid, k), ("decimal", "", 1))
            out = out.replace(f"%{k + 1}", self._fmt(cnt[k] + st - 1 if k == il else max(cnt[k], 1) + st - 1, kk))
        return out + " "


def _para_lines(p, numbering) -> list[str]:
    chars: list[tuple[str, bool]] = []
    lab = numbering.label(p) if numbering else ""
    for c in lab:
        chars.append((c, False))
    for r in p.iter(W + "r"):
        e = _run_emph(r)
        for ch in r:
            t = ch.tag
            if t == W + "t":
                chars.extend((c, e) for c in (ch.text or ""))
            elif t == W + "tab":
                chars.append(("\t", False))
            elif t in (W + "br", W + "cr"):
                chars.append(("\n", False))
            elif t == W + "noBreakHyphen":
                chars.append(("-", e))
            elif t == W + "sym":
                chars.append(("•", False))
    s = _encode(chars).replace(" ", " ")
    return [x.rstrip() for x in s.split("\n") if x.strip() and x.strip() != "****"]


def _cell_paras(tc, numbering):
    out = []
    for el in tc:
        if el.tag == W + "p":
            out.extend(_para_lines(el, numbering))
        elif el.tag == W + "tbl":
            for row in _table_rows(el, numbering):
                out.append(" ".join(" ".join(c) for c in row))
    return out


def _table_rows(tbl, numbering):
    rows = []
    for tr in tbl.findall(W + "tr"):
        cells = []
        for tc in tr.findall(W + "tc"):
            tcpr = tc.find(W + "tcPr")
            if tcpr is not None and tcpr.find(W + "vMerge") is not None and \
                    tcpr.find(W + "vMerge").get(W + "val") is None:
                cells.append([])  # ô gộp dọc (phần tiếp theo) → rỗng
                continue
            cells.append(_cell_paras(tc, numbering))
        rows.append(cells)
    return rows


def _read_docx(b: bytes) -> list[str]:
    try:
        import docx  # python-docx
        doc = docx.Document(io.BytesIO(b))
    except (zipfile.BadZipFile, KeyError, ValueError) as e:
        raise ReadError("broken", str(e)) from e
    except Exception as e:  # noqa: BLE001
        raise ReadError("broken", str(e)) from e
    numbering = _Numbering(doc)
    lines: list[str] = []

    def walk(container):
        for el in container:
            if el.tag == W + "p":
                lines.extend(_para_lines(el, numbering))
            elif el.tag == W + "tbl":
                rows = _table_rows(el, numbering)
                ncol = max((sum(1 for c in r if c) for r in rows), default=0)
                if ncol <= 1:
                    for r in rows:
                        for c in r:
                            lines.extend(c)
                else:
                    for r in rows:
                        cells = [" ".join(x.strip() for x in c).replace("\t", " ") for c in r]
                        if any(x.strip() for x in cells):
                            lines.append("| " + " | ".join(cells) + " |")
            elif el.tag == W + "sdt":  # khối nội dung (content control)
                sc = el.find(W + "sdtContent")
                if sc is not None:
                    walk(sc)

    walk(doc.element.body)
    if not any(_plain(x).strip() for x in lines):
        raise ReadError("image", "Word không có chữ")
    return lines


# =====================================================================
#                          TIỆN ÍCH CHUỖI
# =====================================================================
def _plain(s: str) -> str:
    return s.replace("**", "")


def _marks(s: str) -> tuple[str, list[bool]]:
    """Bỏ ** ** → (chữ thường, mặt nạ nhấn từng ký tự)."""
    text, mask, on = [], [], False
    i = 0
    while i < len(s):
        if s.startswith("**", i):
            on = not on
            i += 2
            continue
        text.append(s[i])
        mask.append(on)
        i += 1
    return "".join(text), mask


def _ws(s: str) -> str:
    s = s.replace("\t", " ").replace("\\_", "_")
    s = re.sub(r"[     ]+", " ", s)
    return s.strip()


def _cells(line: str) -> list[str] | None:
    s = line.strip()
    if not s.startswith("|"):
        return None
    s = s.strip("|")
    return [c.strip() for c in s.split("|")]


def _norm_letter(c: str) -> str:
    return c.upper() if c and c.upper() in LETTERS else ""


# =====================================================================
#                            TÁCH ĐỀ THI
# =====================================================================
Q_RE = re.compile(r"^\s*(?:(?:câu|cau|question|q)\s*(\d{1,3})([ab])?\s*[.):\-–]?|(\d{1,3})([ab])?\s*[.)]|(\d{1,3})([ab])?\s*:)\s*(.*)$",
                  re.I | re.S)
QPAREN_RE = re.compile(r"^\s*\((\d{1,3})\)\s*(.*)$", re.S)
OPT_UP = re.compile(r"(?<![^\s(])\(?([A-D])[.)](?=\s|\S)")
OPT_LO = re.compile(r"(?<![^\s(])\(?([a-d])[.)](?=\s)")
ANS_LINE = re.compile(r"^\s*(?:→|=>|->|⇒)?\s*(?:đáp\s*án(?:\s*đúng)?|đa|answer|ans|key|chọn)\s*[:\-–=]?\s*\(?([A-Da-d])\)?(?![\wÀ-ỹ])\s*[.:\-–]?\s*(.*)$", re.I)
WHY_LINE = re.compile(r"^\s*(?:giải\s*thích|vì\s*sao|lời\s*giải|explanation|why|hướng\s*dẫn)\s*[:\-–]\s*(.+)$", re.I)
KEY_HEAD = re.compile(r"^\s*(?:#+\s*)?(?:bảng\s+)?(?:đáp\s*án|dap\s*an|answer\s*keys?|answers|keys?|key\s*answers?|lời\s*giải)\b", re.I)
PAIR_RE = re.compile(r"(?<![\w/,.])(?:[Cc]âu\s*)?(\d{1,3}[ab]?)\s*(?:[.\-:)–=]\s*|\s+)\(?([A-D])\)?(?![\wÀ-ỹ])|"
                     r"(?<![\w/,.])(?:[Cc]âu\s*)?(\d{1,3}[ab]?)\s*[.\-:)–=]\s*\(?([a-d])\)?(?![\wÀ-ỹ])")
BLANK_RE = re.compile(r"\(\s*\d{1,3}\s*\)\s*(?:_{2,}|…{2,}|\.{4,}|\[\s*\]|-{3,})|_{3,}\s*\(\s*\d{1,3}\s*\)")
HEAD_START = re.compile(r"^\s*(?:•|-\s|phần|part|section|exercise|bài\s+\d|directions?\b|instructions?\b|"
                        r"(?:[IVX]{1,4})\s*[.):\-]\s|mark the letter|choose|chọn|read\b|đọc|điền|fill|rewrite|viết lại)",
                        re.I)
END_RE = re.compile(r"^[\s_\-–=*]*(?:the end|hết|--- hết ---)[\s_\-–=*!.]*$", re.I)

PART_KEYS = [
    ("transform", ["rewrite", "same meaning", "closest in meaning to the original", "original sentence",
                   "transformation", "biến đổi", "viết lại", "nghĩa giống câu", "closest in meaning to the sentence",
                   "sentence that is closest", "đồng nghĩa với câu"]),
    ("cloze", ["cloze", "blanks in", "numbered blank", "điền từ vào đoạn", "điền vào đoạn", "điền vào chỗ trống trong đoạn",
               "completes the passage", "complete the passage", "each of the numbered", "(36)"]),
    ("reading", ["reading", "read the passage", "read the text", "read the following", "answer the question",
                 "read and choose", "read and answer", "đọc hiểu", "đọc đoạn", "đọc bài"]),
    ("vocab", ["vocabulary", "từ vựng", "closest meaning", "closest in meaning", "opposite in meaning", "word choice",
               "underlined word", "synonym", "antonym"]),
    ("grammar", ["grammar", "ngữ pháp", "tense", "verb form", "structure"]),
]


def _part_of_heading(s: str):
    low = s.lower()
    if re.search(r"\bfill\b.*\b(passage|text|đoạn)\b|\b(passage|text)\b.*\bblanks?\b|\bblanks?\b.*\b(passage|text)\b|\(3\d\)",
                 low) and "read the passage and answer" not in low:
        return "cloze"
    for key, words in PART_KEYS:
        for w in words:
            if w in low:
                return key
    return None


def _guess_part_by_num(n: int, total: int) -> str:
    if total >= 45:
        if n <= 15:
            return "vocab"
        if n <= 30:
            return "grammar"
        if n <= 35:
            return "transform"
        if n <= 45:
            return "cloze"
        return "reading"
    return "grammar"


def split_options(text: str, mask: list[bool] | None = None):
    """'... A. x B. y C. z D. w' → (phần trước, [x,y,z,w], [nhấn?×4]) hoặc None.
    Nhận cả A) (A) a. và lựa chọn nằm trên nhiều dòng."""
    for rx in (OPT_UP, OPT_LO):
        marks = list(rx.finditer(text))
        picked, i = [], 0
        for m in marks:
            if i < 4 and m.group(1).upper() == LETTERS[i]:
                picked.append(m)
                i += 1
        if not picked:
            continue
        if picked[0].group(1).upper() != "A":
            continue
        opts, emph = [], []
        for k, m in enumerate(picked):
            start, end = m.end(), picked[k + 1].start() if k + 1 < len(picked) else len(text)
            seg = text[start:end]
            opts.append(_ws(seg.replace("\n", " ")))
            if mask:
                seg_mask = mask[m.start():end]
                seg_chars = text[m.start():end]
                vis = [e for c, e in zip(seg_chars, seg_mask) if c.strip()]
                emph.append(bool(vis) and sum(vis) >= max(1, len(vis) * 0.6))
            else:
                emph.append(False)
        return text[: picked[0].start()], opts, emph
    return None


def _take_pairs(text: str, out: dict):
    for m in PAIR_RE.finditer(text):
        n, a = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        if not n:
            continue
        n = n.lower()
        key = int(n) if n.isdigit() else n
        out.setdefault(key, a.upper())


def _key_row(cells: list[str], answers: dict, whys: dict) -> bool:
    """Hàng bảng đáp án. Trả True nếu đọc được gì đó."""
    cl = [_ws(_plain(c)) for c in cells]
    got = False
    # hàng giải thích: | 1 | A. learning | Vì sao ... |
    if len(cl) >= 3 and re.fullmatch(r"(?:câu\s*)?\d{1,3}[ab]?", cl[0], re.I):
        m = re.match(r"^\(?([A-Da-d])\)?(?![\wÀ-ỹ])", cl[1])
        rest = " ".join(c for c in cl[2:] if c)
        if m and len(rest) >= 12 and len(PAIR_RE.sub("", rest).strip(" |.,;")) >= 8:
            n = re.sub(r"\D*(\d+[ab]?)", r"\1", cl[0].lower())
            key = int(n) if n.isdigit() else n
            answers.setdefault(key, m.group(1).upper())
            whys.setdefault(key, _ws(rest))
            return True
    for i in range(len(cl) - 1):
        a, b = cl[i], cl[i + 1]
        mm = re.fullmatch(r"(?:câu\s*)?(\d{1,3}[ab]?)\s*[.:)]?", a, re.I)
        bb = re.fullmatch(r"\(?([A-Da-d])\)?\s*[.:]?", b)
        if mm and bb:
            n = mm.group(1).lower()
            answers.setdefault(int(n) if n.isdigit() else n, bb.group(1).upper())
            got = True
    if not got:
        # ô chứa sẵn "1.A" "2-B"
        before = len(answers)
        for c in cl:
            if re.fullmatch(r"(?:câu\s*)?\d{1,3}[ab]?\s*[.\-:)–=]?\s*\(?[A-Da-d]\)?\.?", c, re.I):
                _take_pairs(c, answers)
        got = len(answers) > before
    return got


def _is_key_header_row(cells: list[str]) -> bool:
    low = [_ws(_plain(c)).lower() for c in cells]
    has_num = any(x in ("câu", "cau", "no", "no.", "#", "question", "stt", "số câu") for x in low)
    has_key = any(x in ("đáp án", "đa", "answer", "key", "đáp án đúng", "keys", "answers") for x in low)
    return has_num and has_key


def _join_text(parts: list[str]) -> str:
    out = ""
    for p in parts:
        p = _ws(p)
        if not p:
            continue
        if not out:
            out = p
        elif re.match(r"^[A-Za-zÀ-ỹ][\w .']{0,14}:\s", p) or re.match(r"^[-–•]\s", p):
            out += "\n" + p  # hội thoại "A: ..." / "Tom: ..."
        else:
            out += " " + p
    return out


def _join_passage(parts: list[str]) -> str:
    out = ""
    for p in parts:
        p = _ws(p)
        if not p:
            continue
        if not out:
            out = p
        elif re.search(r"[.!?:\"”'’)]$", out):
            out += "\n" + p
        else:
            out += " " + p
    return out


def parse_exam(lines: list[str]) -> dict:
    qs: list[dict] = []          # câu thô theo thứ tự gặp
    cur = None
    section = None               # phần hiện tại theo tiêu đề
    in_key = False
    answers: dict = {}
    whys: dict = {}
    passages = {"cloze": [], "reading": []}
    pass_title = {"cloze": "", "reading": ""}
    pass_target = None           # đoạn văn đang gom (cloze|reading)

    def close():
        nonlocal cur
        if cur is not None:
            qs.append(cur)
        cur = None

    def opts_done(q) -> bool:
        if q is None:
            return False
        t, m = _marks("\n".join(q["raw"]))
        r = split_options(t, m)
        return bool(r and len(r[1]) == 4)

    def add_passage(tgt, line):
        nonlocal pass_target
        pl = _ws(_plain(line))
        if not passages[tgt] and not pass_title[tgt] and len(pl) < 90 and not re.search(r"[.!?,]$", pl) \
                and not BLANK_RE.search(pl):
            pass_title[tgt] = pl
        else:
            m = re.match(r"^\*\*([^*]{2,90})\*\*\s+(.{40,})$", line.strip(" |"), re.S)
            if m and not passages[tgt] and not pass_title[tgt]:
                pass_title[tgt] = _ws(m.group(1))
                passages[tgt].append(_ws(_plain(m.group(2))))
            else:
                passages[tgt].append(pl)
        pass_target = tgt

    for raw_line in lines:
        line = raw_line.rstrip()
        if not _plain(line).strip():
            continue
        cells = _cells(line)

        # ---------- vùng đáp án ----------
        if in_key:
            if cells is not None:
                if not _key_row(cells, answers, whys):
                    _take_pairs(" ".join(_plain(c) for c in cells), answers)
                continue
            p = _ws(_plain(line))
            m = re.match(r"^(?:câu\s*)?(\d{1,3}[ab]?)\s*[.\-:)–]\s*\(?([A-D])\)?(?![\wÀ-ỹ])[\s.\-–:]*(.{12,})$", p, re.I)
            if m:
                n = m.group(1).lower()
                k = int(n) if n.isdigit() else n
                answers.setdefault(k, m.group(2).upper())
                whys.setdefault(k, _ws(m.group(3)))
                continue
            wm = WHY_LINE.match(p)
            if wm and answers:
                last = list(answers)[-1]
                whys.setdefault(last, _ws(wm.group(1)))
                continue
            _take_pairs(p, answers)
            continue

        plain_line = _ws(_plain(line))

        # ---------- bảng ----------
        if cells is not None:
            if _is_key_header_row(cells):
                close()
                in_key = True
                continue
            cl = [_ws(_plain(c)) for c in cells]
            nonempty = [c for c in cl if c]
            if len(nonempty) >= 2 and all(re.fullmatch(r"\d{1,3}[ab]?|\(?[A-Da-d]\)?", c) for c in nonempty) and \
                    any(re.fullmatch(r"[A-Da-d]", c.strip("()")) for c in nonempty) and \
                    any(c.isdigit() for c in nonempty):
                _key_row(cells, answers, whys)
                continue
            # hàng bảng khác: gộp thành 1 dòng thường
            line = "  ".join(c for c in cells if _plain(c).strip())
            plain_line = _ws(_plain(line))
            if not plain_line:
                continue

        # ---------- tiêu đề đáp án ----------
        if KEY_HEAD.match(plain_line) and not ANS_LINE.match(plain_line) and len(plain_line) < 120 \
                and not re.search(r"question|câu hỏi|passage", plain_line, re.I):
            close()
            in_key = True
            _take_pairs(plain_line, answers)
            continue

        if END_RE.match(plain_line):
            close()
            pass_target = None
            continue

        # ---------- đáp án / giải thích ngay dưới câu ----------
        am = ANS_LINE.match(plain_line)
        if am and (cur is not None or qs):
            tgt = cur if cur is not None else qs[-1]
            tgt["inline_ans"] = am.group(1).upper()
            rest = _ws(am.group(2))
            if len(rest) >= 12:
                tgt["why"] = rest
            continue
        wm = WHY_LINE.match(plain_line)
        if wm and (cur is not None or qs):
            tgt = cur if cur is not None else qs[-1]
            tgt["why"] = _ws(wm.group(1))
            continue

        # ---------- dòng đáp án nhanh "1.A 2.B 3-C ..." ----------
        prs = list(PAIR_RE.finditer(plain_line))
        if len(prs) >= 3 and len(PAIR_RE.sub("", plain_line).strip(" ,;|.")) <= 12 and \
                not split_options(plain_line):
            close()
            _take_pairs(plain_line, answers)
            continue

        # ---------- câu hỏi mới ----------
        ls = line.strip()
        qm = Q_RE.match(ls.replace("**", "", 2) if ls.startswith("**") else ls)
        mline = None
        if qm:
            num = qm.group(1) or qm.group(3) or qm.group(5)
            suf = qm.group(2) or qm.group(4) or qm.group(6) or ""
            body = qm.group(7)
            # bỏ ** còn sót sau số câu ("**1. **text")
            body = re.sub(r"^\s*\*\*\s*", "", body) if body.lstrip().startswith("**") and \
                body.count("**") % 2 == 1 else body
            if 1 <= int(num) <= 200 and not (qm.group(5) and not body.strip()):
                mline = (int(num) if not suf else f"{int(num)}{suf.lower()}", body)
        if mline is None:
            pm = QPAREN_RE.match(_plain(line))
            if pm and split_options(pm.group(2)) and 1 <= int(pm.group(1)) <= 200:
                mline = (int(pm.group(1)), pm.group(2))
        if mline is not None:
            # dòng kiểu "1." nằm trong đoạn văn đọc hiểu? → số câu phải hợp lý
            close()
            num, body = mline
            cur = {"num": num, "raw": [body] if body.strip() else [], "section": section, "inline_ans": "",
                   "why": ""}
            pass_target = None
            continue

        # ---------- tiêu đề phần ----------
        is_head = False
        open_q = cur is not None and not opts_done(cur)
        explicit = re.match(r"^\s*(?:•|phần\b|part\b|section\b|[IVX]{1,4}\s*[.):\-]\s)", plain_line, re.I)
        if len(plain_line) < 260 and not split_options(plain_line) and (explicit or not open_q):
            letters = [c for c in plain_line if c.isalpha()]
            caps = letters and sum(c.isupper() for c in letters) / len(letters) > 0.8 and len(letters) >= 4
            if HEAD_START.match(plain_line) or caps:
                pk = _part_of_heading(plain_line)
                if pk or re.match(r"^\s*(?:•|phần|part|section|exercise|bài\s+\d|[IVX]{1,4}\s*[.):\-]\s)",
                                  plain_line, re.I):
                    is_head = True
                    close()
                    if pk:
                        section = pk
                    elif re.match(r"^\s*(?:phần|part|section|[IVX]{1,4}\s*[.):\-]\s)", plain_line, re.I):
                        section = None
                    pass_target = section if section in ("cloze", "reading") else None
                    continue
                if caps and cur is None and section is None:
                    continue  # tiêu đề đề thi
        if is_head:
            continue

        # ---------- dòng thường ----------
        has_blank = bool(BLANK_RE.search(plain_line))
        if cur is not None and not opts_done(cur):
            if has_blank and len(plain_line) > 150:
                close()
                add_passage("cloze", line)
                continue
            cur["raw"].append(line)
            continue
        # câu đã đủ 4 lựa chọn (hoặc chưa có câu nào)
        if has_blank:
            close()
            add_passage("cloze", line)
            continue
        if cur is not None and re.match(r"^[a-z(]", plain_line) and len(plain_line) < 80:
            cur["raw"].append(line)  # dòng bị ngắt (PDF) của lựa chọn cuối
            continue
        tgt = pass_target or (section if section in ("cloze", "reading") else None)
        if tgt and (cur is None or len(plain_line) >= 150):
            close()
            add_passage(tgt, line)
            continue
        if cur is None and len(plain_line) >= 400 and section is None and qs:
            add_passage("reading", line)  # đoạn đọc hiểu không có tiêu đề phần
            continue
        # còn lại: bỏ qua (tên trường, lời dặn...)
    close()

    # ---------- dựng câu hỏi ----------
    cloze_text = _join_passage(passages["cloze"])
    blank_nums = {int(x) for x in re.findall(r"\(\s*(\d{1,3})\s*\)", cloze_text)}
    total = len(qs)
    out = []
    for q in qs:
        text, mask = _marks("\n".join(q["raw"]))
        r = split_options(text, mask)
        if r:
            stem, opts, emph = r
        else:
            stem, opts, emph = text, [], []
        stem_lines = [x for x in stem.split("\n")]
        stem = _join_text(stem_lines)
        stem = re.sub(r"\s*\((?:\d\.?\d*|[0-9]+)\s*(?:điểm|đ|pts?|points?)\)\s*$", "", stem, flags=re.I)
        n = q["num"]
        nint = n if isinstance(n, int) else int(str(n)[:-1])
        part = q["section"]
        if part is None:
            if nint in blank_nums and not stem:
                part = "cloze"
            else:
                part = _guess_part_by_num(nint, total)
        ans = ""
        why = q.get("why", "")
        for key in (n, str(n)):
            if key in answers:
                ans = answers[key]
                break
        if not ans and q.get("inline_ans"):
            ans = q["inline_ans"]
        if not ans and emph and sum(emph) == 1 and len(opts) == 4:
            ans = LETTERS[emph.index(True)]
        if not why:
            why = whys.get(n, "") or whys.get(str(n), "")
        opts4 = (opts + ["", "", "", ""])[:4]
        out.append({"num": n, "part": part, "part_label": PART_LABEL[part],
                    "prompt": TRANSFORM_PROMPT if part == "transform" else "",
                    "text": stem, "options": opts4, "answer": ans, "bonus": not isinstance(n, int),
                    "why_original": why})

    if not any(sum(1 for o in q["options"] if o) >= 2 for q in out):
        out = []  # không câu nào có lựa chọn → không phải đề trắc nghiệm
    reading_text = _join_passage(passages["reading"])
    res = {
        "questions": out,
        "passages": {"cloze": {"title": pass_title["cloze"], "text": cloze_text},
                     "reading": {"title": pass_title["reading"], "text": reading_text}},
    }
    res["problems"] = find_problems(out)
    return res


def find_problems(questions: list[dict]) -> list[dict]:
    """Câu cần sửa: thiếu lựa chọn, thiếu đáp án, trùng số. → [{num, why, i}] (i = vị trí trong danh sách)."""
    probs = []
    seen = {}
    for i, q in enumerate(questions):
        reasons = []
        k = str(q["num"])
        if k in seen:
            reasons.append(f"số câu bị trùng (có 2 câu số {k})")
        seen.setdefault(k, i)
        nopt = sum(1 for o in q.get("options", []) if str(o).strip())
        if nopt < 4:
            reasons.append("không thấy lựa chọn A B C D" if nopt == 0 else f"chỉ thấy {nopt} lựa chọn")
        if not q.get("answer"):
            reasons.append("không thấy đáp án")
        elif nopt == 4 and q["answer"] not in LETTERS:
            reasons.append("đáp án không phải A B C D")
        if q.get("part") not in ("cloze",) and not str(q.get("text", "")).strip():
            reasons.append("không thấy câu hỏi")
        if reasons:
            probs.append({"num": q["num"], "why": "; ".join(reasons), "i": i})
    return probs


# =====================================================================
#                            TÁCH TỪ VỰNG
# =====================================================================
POS = {"v": "động từ", "n": "danh từ", "adj": "tính từ", "a": "tính từ", "adv": "trạng từ", "prep": "giới từ",
       "cụm": "cụm từ", "phr": "cụm từ", "phrase": "cụm từ", "phr v": "cụm động từ", "phr.v": "cụm động từ",
       "phrasal verb": "cụm động từ", "conj": "liên từ", "pron": "đại từ", "det": "từ hạn định",
       "n/adj": "danh từ / tính từ", "v/n": "động từ / danh từ", "n/v": "danh từ / động từ", "num": "số",
       "noun": "danh từ", "verb": "động từ", "adjective": "tính từ", "adverb": "trạng từ", "idiom": "thành ngữ",
       "exp": "cụm từ", "excl": "thán từ", "interj": "thán từ", "modal": "động từ khuyết thiếu",
       "dt": "danh từ", "đt": "động từ", "tt": "tính từ", "trt": "trạng từ",
       "danh từ": "danh từ", "động từ": "động từ", "tính từ": "tính từ", "trạng từ": "trạng từ",
       "giới từ": "giới từ", "cụm từ": "cụm từ", "liên từ": "liên từ"}
POS_RX = r"(?:" + "|".join(sorted((re.escape(k) for k in POS), key=len, reverse=True)) + r")\.?"
IPA_RE = re.compile(r"/[^/\n]{1,60}/(?:\s*/[^/\n]{1,60}/)?|\[[^\]\n]{1,60}\]")
VI_CH = re.compile(r"[ăâđêôơưàảãáạằẳẵắặầẩẫấậèẻẽéẹềểễếệìỉĩíịòỏõóọồổỗốộờởỡớợùủũúụừửữứựỳỷỹýỵ]", re.I)
HEAD_WORDS = {"word", "từ", "từ vựng", "vocabulary", "từ / phiên âm", "từ mới", "english", "tiếng anh", "#", "stt",
              "no", "no.", "nghĩa", "meaning", "loại", "từ loại", "phiên âm", "ipa", "ví dụ", "example",
              "pronunciation", "part of speech", "pos", "type", "vietnamese", "tiếng việt"}


def _pos_norm(p: str) -> str:
    p = _ws(p).strip("().").lower()
    return POS.get(p, POS.get(p.rstrip("."), _ws(p)))


def _is_pos(p: str) -> bool:
    p = _ws(p).strip("().").lower()
    return p in POS or p.rstrip(".") in POS


def _is_english(s: str) -> bool:
    s = _ws(s)
    return bool(s) and not VI_CH.search(s) and bool(re.search(r"[A-Za-z]", s))


def _split_word_ipa(cell: str) -> tuple[str, str, str]:
    """'**word** /ipa/ (n)' → (word, ipa, pos)."""
    ipa = ""
    m = IPA_RE.search(cell)
    if m:
        ipa = _ws(m.group(0))
        cell = cell[: m.start()] + " " + cell[m.end():]
    pos = ""
    pm = re.search(r"\(\s*(" + POS_RX + r")\s*\)", cell, re.I)
    if pm:
        pos = _pos_norm(pm.group(1))
        cell = cell[: pm.start()] + " " + cell[pm.end():]
    return _ws(_plain(cell)).strip(" :-–"), ipa, pos


def _vocab_from_table(rows: list[list[str]]) -> list[dict]:
    out = []
    colmap = None
    for cells in rows:
        cl = [_ws(_plain(c)) for c in cells]
        low = [c.lower() for c in cl]
        if sum(1 for c in low if c in HEAD_WORDS or any(c.startswith(h) for h in ("từ /", "nghĩa", "ví dụ", "phiên âm",
                                                                                  "meaning", "example"))) >= 2:
            colmap = {}
            for i, c in enumerate(low):
                if c in ("#", "stt", "no", "no."):
                    colmap["num"] = i
                elif "phiên âm" in c or c in ("ipa", "pronunciation"):
                    colmap["ipa"] = i
                elif "loại" in c or c in ("pos", "part of speech", "type"):
                    colmap["pos"] = i
                elif "nghĩa" in c or "meaning" in c or c in ("vietnamese", "tiếng việt"):
                    colmap["meaning"] = i
                elif "ví dụ" in c or "example" in c:
                    colmap["example"] = i
                elif c.startswith("từ") or c in ("word", "english", "tiếng anh", "vocabulary"):
                    colmap.setdefault("word", i)
            continue
        nonempty = [c for c in cl if c]
        if len(nonempty) < 2:
            continue  # tên nhóm
        if colmap and "word" in colmap and "meaning" in colmap:
            g = lambda k: cells[colmap[k]] if k in colmap and colmap[k] < len(cells) else ""  # noqa: E731
            word, ipa, pos = _split_word_ipa(g("word"))
            if g("ipa"):
                ipa = _ws(_plain(g("ipa")))
            if g("pos"):
                pos = _pos_norm(_plain(g("pos")))
            meaning = _ws(_plain(g("meaning")))
            example = _ws(_plain(g("example")))
        else:
            # không có hàng tiêu đề: đoán theo nội dung
            rest = list(cells)
            if rest and re.fullmatch(r"\d{1,4}\.?", _ws(_plain(rest[0]))):
                rest = rest[1:]
            if len(rest) < 2:
                continue
            word, ipa, pos = _split_word_ipa(rest[0])
            meaning, example = "", ""
            for c in rest[1:]:
                pc = _ws(_plain(c))
                if not pc:
                    continue
                if not ipa and IPA_RE.fullmatch(pc):
                    ipa = pc
                elif not pos and _is_pos(pc):
                    pos = _pos_norm(pc)
                elif not meaning and (VI_CH.search(pc) or not _is_english(pc) or len(pc.split()) <= 4):
                    meaning = pc
                elif not example and len(pc.split()) >= 3:
                    example = pc
        if not word or not meaning or len(word) > 60 or not _is_english(word):
            continue
        out.append({"word": word, "ipa": ipa, "pos": pos, "meaning": meaning, "example": example})
    return out


LINE_SEP = re.compile(r"\s+[-–—=:]\s+|\s*[:=]\s+|\s+[-–—]\s*|\t+")


def _vocab_from_line(s: str) -> dict | None:
    s = _ws(_plain(s))
    s = re.sub(r"^\s*(?:\d{1,4}\s*[.)\-:]?\s|[•\-–*+]\s)\s*", "", s)
    if not s or len(s) > 300:
        return None
    example = ""
    em = re.search(r"\s*(?:\(|\b)(?:ví dụ|vd|ex|e\.g\.|example)\s*[:.]\s*(.+?)\)?$", s, re.I)
    if em:
        example = _ws(em.group(1))
        s = s[: em.start()]
    ipa = ""
    m = IPA_RE.search(s)
    if m:
        ipa = _ws(m.group(0))
        s = (s[: m.start()] + " " + s[m.end():])
    pos = ""
    pm = re.search(r"\(\s*(" + POS_RX + r")\s*\)", s, re.I)
    if pm:
        pos = _pos_norm(pm.group(1))
        s = s[: pm.start()] + " " + s[pm.end():]
    s = _ws(s)
    # tách từ / nghĩa
    word, meaning = "", ""
    m2 = LINE_SEP.search(s)
    if m2:
        word, meaning = s[: m2.start()], s[m2.end():]
    else:
        # không có dấu ngăn: phần tiếng Anh đứng đầu, nghĩa tiếng Việt phía sau
        toks = s.split(" ")
        k = 0
        while k < len(toks) and _is_english(toks[k]):
            k += 1
        word, meaning = " ".join(toks[:k]), " ".join(toks[k:])
    word = _ws(word).strip(" :-–,;")
    meaning = _ws(meaning).strip(" :-–,;")
    # loại từ viết trơn sau từ: "environment n môi trường"
    wt = word.split(" ")
    if not pos and len(wt) > 1 and _is_pos(wt[-1]) and len(wt[-1].strip(".")) <= 5:
        pos, word = _pos_norm(wt[-1]), " ".join(wt[:-1])
    # câu ví dụ tiếng Anh dính sau nghĩa
    if not example:
        tm = re.search(r"\s([A-Z][A-Za-z']*(?:\s+[A-Za-z',.!?;:\-]+){2,})$", meaning)
        if tm and not VI_CH.search(tm.group(1)) and VI_CH.search(meaning[: tm.start()]):
            example, meaning = _ws(tm.group(1)), _ws(meaning[: tm.start()]).rstrip(" .,;")
    # loại từ dạng "n." ngay đầu nghĩa: "word: n. môi trường"
    pm2 = re.match(r"^(" + POS_RX + r")\s+(.+)$", meaning, re.I)
    if pm2 and not pos and _is_pos(pm2.group(1)) and len(pm2.group(1)) <= 6:
        pos, meaning = _pos_norm(pm2.group(1)), pm2.group(2)
    if not word or not meaning or not _is_english(word) or len(word) > 50 or len(word.split()) > 7:
        return None
    if word.lower() in HEAD_WORDS:
        return None
    if _is_english(meaning) and not ipa and not pos:
        return None  # 2 vế đều tiếng Anh, không có dấu hiệu từ vựng → câu thường
    return {"word": word, "ipa": ipa, "pos": pos, "meaning": meaning, "example": example}


def parse_vocab(lines: list[str]) -> list[dict]:
    out: list[dict] = []
    table: list[list[str]] = []

    def flush_table():
        nonlocal table
        if table:
            out.extend(_vocab_from_table(table))
        table = []

    for ln in lines:
        cells = _cells(ln)
        if cells is not None and len(cells) >= 2:
            table.append(cells)
            continue
        flush_table()
        p = _ws(_plain(ln))
        if not p:
            continue
        em = re.match(r"^(?:ví dụ|vd|ex|e\.g\.|example)\s*[:.]\s*(.+)$", p, re.I)
        if em and out and not out[-1]["example"]:
            out[-1]["example"] = _ws(em.group(1))
            continue
        w = _vocab_from_line(ln)
        if w:
            out.append(w)
    flush_table()
    # bỏ trùng trong cùng file
    seen, res = set(), []
    for w in out:
        k = w["word"].lower()
        if k in seen:
            continue
        seen.add(k)
        res.append(w)
    return res
