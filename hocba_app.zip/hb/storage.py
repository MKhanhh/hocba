"""Lưu tiến độ học.

- Có mã GITHUB_TOKEN trong Secrets  → lưu vào một Gist bí mật trên GitHub (không mất khi app khởi động lại).
- Không có mã                        → lưu tạm vào file trên máy chạy app (chỉ hợp khi chạy trên máy tính).
"""
from __future__ import annotations

import copy
import json
import os
import time
from pathlib import Path

import requests
import streamlit as st

GIST_DESC = "Hoc Ba - tien do hoc (dung xoa)"
GIST_FILE = "hocba_progress.json"
LOCAL_FILE = Path(os.environ.get("HOCBA_DATA_FILE") or Path(__file__).resolve().parent.parent / ".hocba_progress.json")

DEFAULT = {
    "v": 1,
    "rev": 0,                     # tăng mỗi lần lưu (để gộp khi học trên 2 máy)
    "wrong_cleared": 0,           # số câu sai đã "tốt nghiệp" khỏi bảng
    "profile": {"name": ""},
    "settings": {
        "theme": "auto",          # auto | light | dark
        "sound": True,
        "speak_wrong": True,
        "exam": {},               # exam_id -> {"level": 0|1|2, "auto_open": bool}
    },
    "tasks_done": {},             # task_id -> "YYYY-MM-DD"
    "moves": {},                  # task_id -> "YYYY-MM-DD" (ngày mới)
    "activity": {},               # "YYYY-MM-DD" -> phút đã học
    "attempts": {},               # exam_id -> [ {...} ]
    "current": {},                # exam_id -> bài đang làm dở
    "wrong": {},                  # "exam_id#num" -> {...}
    "flags": {},                  # "exam_id#num" -> {...}
    "cards": {},                  # word_id -> fsrs card dict
    "card_log": {},               # "YYYY-MM-DD" -> {"new": n, "reviews": n}
    "lessons": {},                # lesson_id -> {...}
    "uploads": {"exams": {}, "vocab": {}, "docs": []},   # docs: lịch sử tải tài liệu
    "translate": {},              # "YYYY-MM-DD" -> số câu đúng
}


def _merge_defaults(data: dict) -> dict:
    out = copy.deepcopy(DEFAULT)
    for k, v in (data or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k].update(v)
        else:
            out[k] = v
    for k, v in DEFAULT["settings"].items():
        out["settings"].setdefault(k, copy.deepcopy(v))
    out["uploads"].setdefault("exams", {})
    out["uploads"].setdefault("vocab", {})
    out["uploads"].setdefault("docs", [])
    return out


def _token():
    """Mã GitHub dán trong Settings → Secrets của Streamlit (GITHUB_TOKEN = "...")."""
    try:
        tok = st.secrets.get("GITHUB_TOKEN", "")
    except Exception:  # noqa: BLE001  (không có file secrets)
        tok = ""
    return tok or os.environ.get("HOCBA_GITHUB_TOKEN", "")


class GistBackend:
    name = "GitHub"

    def __init__(self, token: str):
        self.h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
                  "X-GitHub-Api-Version": "2022-11-28"}
        self.gist_id = None

    def _find(self):
        page = 1
        while page < 10:
            r = requests.get("https://api.github.com/gists", headers=self.h,
                             params={"per_page": 100, "page": page}, timeout=15)
            r.raise_for_status()
            items = r.json()
            for g in items:
                if g.get("description") == GIST_DESC and GIST_FILE in g.get("files", {}):
                    return g["id"]
            if len(items) < 100:
                return None
            page += 1
        return None

    def load(self) -> dict:
        self.gist_id = self._find()
        if not self.gist_id:
            r = requests.post("https://api.github.com/gists", headers=self.h, timeout=15, json={
                "description": GIST_DESC, "public": False,
                "files": {GIST_FILE: {"content": json.dumps(DEFAULT, ensure_ascii=False)}}})
            r.raise_for_status()
            self.gist_id = r.json()["id"]
            return {}
        r = requests.get(f"https://api.github.com/gists/{self.gist_id}", headers=self.h, timeout=15)
        r.raise_for_status()
        f = r.json()["files"][GIST_FILE]
        content = f.get("content", "")
        if f.get("truncated") and f.get("raw_url"):
            content = requests.get(f["raw_url"], headers=self.h, timeout=20).text
        return json.loads(content or "{}")

    def load_quiet(self) -> dict:
        """Đọc bản đang lưu trên GitHub (không tạo mới)."""
        r = requests.get(f"https://api.github.com/gists/{self.gist_id}", headers=self.h, timeout=15)
        r.raise_for_status()
        f = r.json()["files"][GIST_FILE]
        content = f.get("content", "")
        if f.get("truncated") and f.get("raw_url"):
            content = requests.get(f["raw_url"], headers=self.h, timeout=20).text
        return json.loads(content or "{}")

    def save(self, data: dict):
        r = requests.patch(f"https://api.github.com/gists/{self.gist_id}", headers=self.h, timeout=20, json={
            "files": {GIST_FILE: {"content": json.dumps(data, ensure_ascii=False, separators=(",", ":"))}}})
        r.raise_for_status()


class LocalBackend:
    name = "máy này"

    def load(self) -> dict:
        if LOCAL_FILE.exists():
            return json.loads(LOCAL_FILE.read_text())
        return {}

    def save(self, data: dict):
        LOCAL_FILE.write_text(json.dumps(data, ensure_ascii=False))


def init():
    """Gọi đầu mỗi lần chạy. Tải tiến độ một lần cho mỗi phiên."""
    if "db" in st.session_state:
        return
    tok = _token()
    backend = GistBackend(tok) if tok else LocalBackend()
    err = ""
    try:
        data = backend.load()
    except Exception as e:  # noqa: BLE001
        err = f"Không mở được kho GitHub ({e}). Tạm lưu trên máy chủ, có thể mất khi app khởi động lại."
        backend = LocalBackend()
        data = backend.load()
    st.session_state.db = _merge_defaults(data)
    st.session_state.db_backend = backend
    st.session_state.db_error = err
    st.session_state.db_dirty = False
    st.session_state.db_saved_at = time.time()


def db() -> dict:
    return st.session_state.db


def touch():
    st.session_state.db_dirty = True


SAVE_EVERY = 12  # giây: lưu GitHub tối đa mỗi 12 giây (đỡ chậm khi bấm liên tục)


def flush(force: bool = False):
    """Có thay đổi thì lưu. Lưu vào máy: lưu ngay. Lưu GitHub: gộp lại, tối đa mỗi SAVE_EVERY giây
    (khung tự lưu chạy nền mỗi 15 giây sẽ lưu nốt phần còn lại)."""
    ss = st.session_state
    if not ss.get("db_dirty"):
        return
    be = ss.db_backend
    if isinstance(be, GistBackend) and not force and time.time() - ss.get("db_saved_at", 0) < SAVE_EVERY:
        return
    try:
        if isinstance(be, GistBackend):
            remote = _merge_defaults(be.load_quiet())
            if remote.get("rev", 0) > ss.db.get("rev", 0):
                ss.db = merge(remote, ss.db)  # máy khác vừa lưu → gộp, không ghi đè mất
            ss.db["rev"] = max(remote.get("rev", 0), ss.db.get("rev", 0)) + 1
        else:
            ss.db["rev"] = ss.db.get("rev", 0) + 1
        be.save(ss.db)
        ss.db_dirty = False
        ss.db_saved_at = time.time()
        ss.db_error = ""
    except Exception as e:  # noqa: BLE001
        ss.db_error = f"Chưa lưu được lên GitHub, app sẽ thử lại sau ít giây. ({str(e)[:120]})"


# ---------- Gộp dữ liệu khi học trên 2 máy ----------
def merge(remote: dict, local: dict) -> dict:
    """Gộp tiến độ: giữ phần nhiều hơn / mới hơn của mỗi mục."""
    out = copy.deepcopy(remote)
    L = local
    for k in ("tasks_done", "moves", "flags", "current"):
        out[k].update(L.get(k, {}))
    for k in ("activity", "translate"):
        for d, v in L.get(k, {}).items():
            out[k][d] = max(out[k].get(d, 0), v)
    for d, v in L.get("card_log", {}).items():
        r = out["card_log"].get(d, {"new": 0, "reviews": 0})
        out["card_log"][d] = {"new": max(r["new"], v["new"]), "reviews": max(r["reviews"], v["reviews"])}
    for w, c in L.get("cards", {}).items():
        r = out["cards"].get(w)
        if not r or (c.get("last_review") or "") >= (r.get("last_review") or ""):
            out["cards"][w] = c
    for eid, rs in L.get("attempts", {}).items():
        r = out["attempts"].get(eid, [])
        if len(rs) > len(r) or (len(rs) == len(r) and rs and len(rs[-1]["answers"]) >= len(r[-1]["answers"])):
            out["attempts"][eid] = rs
    for lid, v in L.get("lessons", {}).items():
        r = out["lessons"].get(lid)
        if not r or len(v.get("reviews", [])) >= len(r.get("reviews", [])):
            out["lessons"][lid] = v
    # bảng câu sai: lấy bản của máy đang dùng cho câu nó biết, thêm câu chỉ máy kia có
    w = dict(out["wrong"])
    w.update(L.get("wrong", {}))
    out["wrong"] = w
    out["wrong_cleared"] = max(out.get("wrong_cleared", 0), L.get("wrong_cleared", 0))
    for k in ("exams", "vocab"):
        out["uploads"][k].update(L.get("uploads", {}).get(k, {}))
    gone = set(out.get("deleted_exams", [])) | set(L.get("deleted_exams", []))
    out["deleted_exams"] = sorted(gone)
    for eid in gone:
        out["uploads"]["exams"].pop(eid, None)
        out["attempts"].pop(eid, None)
    names = {(d.get("name"), d.get("added")) for d in out["uploads"]["docs"]}
    out["uploads"]["docs"] += [d for d in L.get("uploads", {}).get("docs", []) if (d.get("name"), d.get("added")) not in names]
    out["settings"] = L.get("settings", out["settings"])
    out["profile"] = L.get("profile", out["profile"])
    return out


def export_json() -> str:
    return json.dumps(st.session_state.db, ensure_ascii=False, indent=1)


def import_json(text: str):
    st.session_state.db = _merge_defaults(json.loads(text))
    st.session_state.db["rev"] = st.session_state.db.get("rev", 0) + 1000  # bản nhập vào là bản mới nhất
    touch()
    flush(force=True)


def backend_name() -> str:
    return st.session_state.db_backend.name
