/* Học Bá – âm thanh, đọc tiếng Anh, đồng hồ học. Chạy trong trang chính (không mất khi app vẽ lại). */
(function () {
  var W = window, D = document;
  var HB = W.HB = W.HB || {};
  if (HB.ver === "7") return;
  HB.ver = "7";
  HB.seen = HB.seen || {};

  /* ================= ÂM THANH ================= */
  var ac = null;
  function A() {
    try {
      if (!ac) { var C = W.AudioContext || W.webkitAudioContext; if (!C) return null; ac = new C(); }
      if (ac.state === "suspended") ac.resume();
    } catch (e) { return null; }
    return ac;
  }
  var unlocked = false;
  function unlock() {               // điện thoại cần 1 lần chạm để bật tiếng
    A();
    if (!unlocked && W.speechSynthesis) {
      try { var u = new W.SpeechSynthesisUtterance(" "); u.volume = 0; W.speechSynthesis.speak(u); } catch (e) {}
      unlocked = true;
    }
  }
  D.addEventListener("pointerdown", unlock, { passive: true, capture: true });
  D.addEventListener("keydown", unlock, { capture: true });

  function tone(f, start, dur, type, vol) {
    var a = A(); if (!a) return;
    var t = a.currentTime + start, o = a.createOscillator(), g = a.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + dur + 0.05);
  }
  function crowd(start, dur, vol) {
    var a = A(); if (!a) return;
    var t = a.currentTime + start, n = Math.floor(a.sampleRate * dur);
    var buf = a.createBuffer(1, n, a.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    var src = a.createBufferSource(); src.buffer = buf;
    var f = a.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = 1100; f.Q.value = 0.7;
    var g = a.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.15);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(a.destination); src.start(t); src.stop(t + dur);
  }
  HB.correct = function (streak) {          // reo hò, to hơn khi đúng 3 câu liền
    var big = streak >= 3;
    (big ? [523, 659, 784, 1047] : [523, 659, 784]).forEach(function (n, i) { tone(n, i * 0.08, 0.3, "triangle", 0.22); });
    crowd(0.05, big ? 1.3 : 0.8, big ? 0.38 : 0.2);
  };
  HB.wrong = function (text) {              // còi trầm rồi đọc câu đúng
    tone(233, 0, 0.28, "triangle", 0.25);
    tone(185, 0.3, 0.45, "triangle", 0.25);
    if (text) setTimeout(function () { HB.speak(text); }, 850);
  };
  function chime() { [0, 0.6].forEach(function (s) { tone(880, s, 1.4, "sine", 0.3); tone(1320, s, 1.0, "sine", 0.12); }); }
  function whistle() {
    var a = A(); if (!a) return;
    [[0, 0.22], [0.32, 0.22], [0.64, 0.8]].forEach(function (p) {
      var t = a.currentTime + p[0], dur = p[1];
      var o = a.createOscillator(), lfo = a.createOscillator(), lg = a.createGain(), g = a.createGain();
      o.type = "sine"; o.frequency.setValueAtTime(2700, t);
      lfo.type = "sine"; lfo.frequency.setValueAtTime(28, t); lg.gain.setValueAtTime(220, t);
      lfo.connect(lg); lg.connect(o.frequency);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.18, t + 0.02);
      g.gain.setValueAtTime(0.18, t + dur - 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(a.destination);
      o.start(t); lfo.start(t); o.stop(t + dur + 0.05); lfo.stop(t + dur + 0.05);
    });
  }
  function schoolBell() { for (var i = 0; i < 12; i++) { tone(1050, i * 0.1, 0.12, "square", 0.06); tone(2100, i * 0.1, 0.1, "sine", 0.05); } }
  HB.bell = function (i) { if (i == 1) whistle(); else if (i == 2) schoolBell(); else chime(); };

  var voice = null;
  function pickVoice() {
    try {
      var vs = W.speechSynthesis.getVoices() || [];
      voice = vs.filter(function (v) { return /^en[-_]US/i.test(v.lang); })[0] ||
              vs.filter(function (v) { return /^en/i.test(v.lang); })[0] || null;
    } catch (e) {}
  }
  if (W.speechSynthesis) { pickVoice(); W.speechSynthesis.onvoiceschanged = pickVoice; }
  HB.speak = function (text, rate) {
    if (!W.speechSynthesis || !text) return;
    try {
      var u = new W.SpeechSynthesisUtterance(String(text).replace(/_{2,}/g, " blank "));
      u.lang = "en-US"; u.rate = rate || 0.85; if (voice) u.voice = voice;
      W.speechSynthesis.cancel(); W.speechSynthesis.speak(u);
    } catch (e) {}
  };

  HB.run = function (list, nonce) {
    if (!list || !list.length || HB.seen[nonce]) return;
    HB.seen[nonce] = 1;
    list.forEach(function (e) {
      var go = function () {
        if (e.k === "correct") HB.correct(e.streak || 0);
        else if (e.k === "wrong") HB.wrong(e.text);
        else if (e.k === "speak") HB.speak(e.text, e.rate);
        else if (e.k === "bell") HB.bell(e.i || 0);
      };
      if (e.delay) setTimeout(go, e.delay); else go();
    });
  };

  /* ================= ĐỒNG HỒ HỌC ================= */
  var KEY = "hb_timer_v1";
  var BELLS = ["Chuông nhẹ", "Còi trọng tài", "Chuông trường"];
  var PRESETS = [
    { s: 25 * 60, b: 5 * 60, label: "25 / 5", sub: "Chuẩn, ngày thường" },
    { s: 50 * 60, b: 10 * 60, label: "50 / 10", sub: "Ngày dài, làm đề" },
    { s: 15 * 60, b: 3 * 60, label: "15 / 3", sub: "Ngày mệt, lười" },
    { s: 10, b: 6, label: "Thử nhanh", sub: "10 giây / 6 giây" }
  ];
  function load() {
    var d = { mode: "idle", running: false, end: 0, left: 0, studySec: 1500, breakSec: 300, studyBell: 0, breakBell: 1, round: 1, modal: "" };
    try { var s = JSON.parse(W.localStorage.getItem(KEY) || "null"); if (s) for (var k in s) d[k] = s[k]; } catch (e) {}
    return d;
  }
  var S = load();
  function save() { try { W.localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
  function left() { return S.running ? Math.max(0, Math.round((S.end - Date.now()) / 1000)) : S.left; }
  function mmss(sec) { var m = Math.floor(sec / 60), r = sec % 60; return (m < 10 ? "0" : "") + m + ":" + (r < 10 ? "0" : "") + r; }
  function lab(sec) { return sec < 60 ? sec + " giây" : Math.round(sec / 60) + " phút"; }

  var css = D.createElement("style");
  css.textContent = [
    "#hb-pill{position:fixed;top:10px;right:12px;z-index:1000;height:40px;padding:0 14px;border-radius:999px;border:1.5px solid var(--hb-line,#DCDDD3);",
    "background:var(--hb-card,#fff);color:var(--hb-ink,#1F2A24);font:600 14px 'Be Vietnam Pro',system-ui,sans-serif;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 2px 8px rgba(0,0,0,.08)}",
    "#hb-pill.study{background:var(--hb-green-soft,#E3F0E6);color:var(--hb-green-ink,#1F5C38);border-color:var(--hb-green,#2F7A4D)}",
    "#hb-pill.break{background:var(--hb-orange-soft,#FCEBDC);color:var(--hb-orange-ink,#8A4510);border-color:#D9822B}",
    ".hb-ov{position:fixed;inset:0;z-index:1001;background:rgba(20,28,24,.55);display:flex;align-items:center;justify-content:center;padding:16px}",
    ".hb-dlg{background:var(--hb-card,#fff);color:var(--hb-ink,#1F2A24);border-radius:24px;padding:20px 18px;width:100%;max-width:420px;max-height:92vh;overflow:auto;",
    "font:15px 'Be Vietnam Pro',system-ui,sans-serif;display:flex;flex-direction:column;gap:12px;box-sizing:border-box}",
    ".hb-dlg h3{margin:0;font:700 22px Lexend,sans-serif;text-align:center}",
    ".hb-dlg .mut{color:var(--hb-muted,#5B6660);font-size:14px;text-align:center}",
    ".hb-dlg button{font:600 15px Lexend,sans-serif;cursor:pointer;border-radius:14px;border:1.5px solid var(--hb-line,#DCDDD3);background:var(--hb-card,#fff);color:var(--hb-ink,#1F2A24);min-height:44px}",
    ".hb-dlg button.main{background:var(--hb-green,#2F7A4D);color:#fff;border:0;min-height:54px;font-size:17px}",
    ".hb-dlg button.soft{background:var(--hb-soft,#EEEEE6);border:0}",
    ".hb-pre{display:grid;grid-template-columns:1fr 1fr;gap:8px}",
    ".hb-pre button{display:flex;flex-direction:column;align-items:flex-start;padding:8px 12px;text-align:left}",
    ".hb-pre button small{font:400 12.5px 'Be Vietnam Pro',sans-serif;color:var(--hb-muted,#5B6660)}",
    ".hb-pre button.on{border:2px solid var(--hb-green,#2F7A4D);background:var(--hb-green-soft,#E3F0E6)}",
    ".hb-row{display:flex;align-items:center;justify-content:space-between;gap:8px}",
    ".hb-step{display:flex;align-items:center;gap:8px}.hb-step button{width:44px;font-size:20px}.hb-step b{min-width:70px;text-align:center;font:700 17px Lexend,sans-serif}",
    ".hb-dlg select{font:15px 'Be Vietnam Pro',sans-serif;padding:8px;border-radius:10px;border:1.5px solid var(--hb-line,#DCDDD3);background:var(--hb-card,#fff);color:var(--hb-ink,#1F2A24)}",
    ".hb-tips{background:var(--hb-green-soft,#E3F0E6);border-radius:16px;padding:12px 14px;display:flex;flex-direction:column;gap:4px}",
    "@media (max-width:899px){#hb-pill{top:8px;right:8px;height:38px;padding:0 12px;font-size:13.5px}}"
  ].join("");
  D.head.appendChild(css);

  var pill = D.createElement("button");
  pill.id = "hb-pill"; pill.type = "button"; pill.setAttribute("aria-label", "Đồng hồ học");
  D.body.appendChild(pill);
  pill.onclick = function () { openPanel(); };

  var ov = null;
  function close() { if (ov) { ov.remove(); ov = null; } }
  function dlg(inner) {
    close();
    ov = D.createElement("div"); ov.className = "hb-ov";
    ov.innerHTML = '<div class="hb-dlg" role="dialog">' + inner + "</div>";
    D.body.appendChild(ov);
    ov.addEventListener("click", function (e) { if (e.target === ov && !S.modal) close(); });
    return ov;
  }
  function on(id, fn) { var el = ov && ov.querySelector("#" + id); if (el) el.onclick = fn; }

  function bellSelect(id, val) {
    return '<select id="' + id + '">' + BELLS.map(function (b, i) { return '<option value="' + i + '"' + (i == val ? " selected" : "") + ">" + b + "</option>"; }).join("") + "</select>";
  }

  function openPanel() {
    var running = S.mode !== "idle";
    var pre = PRESETS.map(function (p, i) {
      var onp = p.s === S.studySec && p.b === S.breakSec;
      return '<button type="button" data-i="' + i + '" class="' + (onp ? "on" : "") + '"><span>' + p.label + "</span><small>" + p.sub + "</small></button>";
    }).join("");
    var ctrl = running
      ? (S.running ? '<button class="main" id="hb-pause">Tạm dừng</button>' : '<button class="main" id="hb-resume">Chạy tiếp</button>') +
        '<button class="soft" id="hb-stop">Dừng hẳn</button>'
      : '<button class="main" id="hb-start">Bắt đầu học ' + lab(S.studySec) + "</button>";
    dlg('<h3>Đồng hồ học</h3><div class="mut">Chọn số phút học và nghỉ. Hết giờ sẽ có chuông và thông báo.</div>' +
      (running ? '<div class="mut" style="font:700 30px Lexend,sans-serif;color:var(--hb-ink,#1F2A24)">' + (S.mode === "study" ? "Đang học · " : "Đang nghỉ · ") + mmss(left()) + "</div>" : "") +
      '<div class="hb-pre">' + pre + "</div>" +
      '<div class="hb-row"><span>Học</span><span class="hb-step"><button id="hb-sm">−</button><b id="hb-sv">' + lab(S.studySec) + '</b><button id="hb-sp">+</button></span></div>' +
      '<div class="hb-row"><span>Nghỉ</span><span class="hb-step"><button id="hb-bm">−</button><b id="hb-bv">' + lab(S.breakSec) + '</b><button id="hb-bp">+</button></span></div>' +
      '<div class="hb-row"><span>Hết giờ học</span><span class="hb-step">' + bellSelect("hb-sb", S.studyBell) + '<button id="hb-st" title="Nghe thử">▶</button></span></div>' +
      '<div class="hb-row"><span>Hết giờ nghỉ</span><span class="hb-step">' + bellSelect("hb-bb", S.breakBell) + '<button id="hb-bt" title="Nghe thử">▶</button></span></div>' +
      ctrl + '<button class="soft" id="hb-close">Đóng</button>');
    ov.querySelectorAll(".hb-pre button").forEach(function (b) {
      b.onclick = function () { var p = PRESETS[+b.getAttribute("data-i")]; S.studySec = p.s; S.breakSec = p.b; save(); openPanel(); };
    });
    function step(k, d, min, max) { return function () { var m = Math.round(S[k] / 60); if (S[k] < 60) m = 0; m = Math.max(min, Math.min(max, m + d)); S[k] = m * 60; save(); openPanel(); }; }
    on("hb-sm", step("studySec", -5, 5, 120)); on("hb-sp", step("studySec", 5, 5, 120));
    on("hb-bm", step("breakSec", -1, 1, 30)); on("hb-bp", step("breakSec", 1, 1, 30));
    ov.querySelector("#hb-sb").onchange = function (e) { S.studyBell = +e.target.value; save(); };
    ov.querySelector("#hb-bb").onchange = function (e) { S.breakBell = +e.target.value; save(); };
    on("hb-st", function () { HB.bell(S.studyBell); });
    on("hb-bt", function () { HB.bell(S.breakBell); });
    on("hb-start", function () { startMode("study"); close(); });
    on("hb-pause", function () { S.left = left(); S.running = false; save(); paint(); openPanel(); });
    on("hb-resume", function () { S.end = Date.now() + S.left * 1000; S.running = true; save(); paint(); openPanel(); });
    on("hb-stop", function () { S.mode = "idle"; S.running = false; S.round = 1; save(); paint(); close(); });
    on("hb-close", close);
  }

  function startMode(m) {
    S.mode = m; S.running = true; S.modal = "";
    var sec = m === "study" ? S.studySec : S.breakSec;
    S.end = Date.now() + sec * 1000; S.left = sec; save(); paint();
  }

  function showModal() {
    if (S.modal === "studyEnd") {
      dlg("<h3>Hết " + lab(S.studySec) + ' học!</h3><div class="mut">Bạn làm tốt lắm. Giờ nghỉ ' + lab(S.breakSec) + ' cho não "nạp" bài nhé.</div>' +
        '<div class="hb-tips"><b style="color:var(--hb-green-ink,#1F5C38)">Nghỉ sao cho đúng</b><div>· Đứng dậy, vươn vai, uống một cốc nước</div>' +
        "<div>· Nhìn ra xa cửa sổ 20 giây cho mắt nghỉ</div><div>· Đừng lướt mạng xã hội, não sẽ khó vào lại bài</div></div>" +
        '<button class="main" id="hb-gobreak">Bắt đầu nghỉ ' + lab(S.breakSec) + '</button><button class="soft" id="hb-skip">Học tiếp, không nghỉ</button>');
      on("hb-gobreak", function () { startMode("break"); close(); });
      on("hb-skip", function () { S.round += 1; startMode("study"); close(); });
    } else if (S.modal === "breakEnd") {
      dlg('<h3>Hết giờ nghỉ!</h3><div class="mut">Vào hiệp ' + (S.round + 1) + " thôi. Làm tiếp chỗ đang dở nhé.</div>" +
        '<button class="main" id="hb-back">Vào học lại ' + lab(S.studySec) + '</button><button class="soft" id="hb-enough">Hôm nay học đủ rồi</button>');
      on("hb-back", function () { S.round += 1; startMode("study"); close(); });
      on("hb-enough", function () { S.mode = "idle"; S.running = false; S.round = 1; S.modal = ""; save(); paint(); close(); });
    }
  }

  var flash = null, baseTitle = D.title;
  function paint() {
    if (S.mode === "idle") { pill.className = ""; pill.textContent = "⏱ Đồng hồ học"; return; }
    pill.className = S.mode;
    pill.textContent = (S.mode === "study" ? "Đang học · " : "Đang nghỉ · ") + mmss(left()) + (S.running ? "" : " (dừng)");
  }
  function tick() {
    if (!D.body.contains(pill)) D.body.appendChild(pill);
    if (S.running && left() <= 0) {
      S.running = false; S.left = 0;
      S.modal = S.mode === "study" ? "studyEnd" : "breakEnd";
      save();
      HB.bell(S.mode === "study" ? S.studyBell : S.breakBell);
      showModal();
      if (D.hidden && !flash) {
        var on_ = false;
        flash = setInterval(function () { on_ = !on_; D.title = on_ ? "⏰ Hết giờ!" : baseTitle; }, 900);
      }
    }
    if (!D.hidden && flash) { clearInterval(flash); flash = null; D.title = baseTitle; }
    paint();
  }
  if (S.modal && !S.running) showModal();
  paint();
  setInterval(tick, 1000);
  HB.timerOpen = openPanel;
})();
