"""Ngăn 3 · Thêm tài liệu (view "upload") và Tài liệu của tôi (view "docs").

- upload: chọn loại (đề / từ vựng) → chọn file .docx/.pdf → kiểm tra, sửa câu lỗi → thêm vào app.
- docs:   tài liệu có sẵn + tài liệu đã tải lên; tải file gửi Claude, nhập bản Claude bổ sung, xóa đề.
"""
from __future__ import annotations

import json
import re
import time
from datetime import date, datetime

import streamlit as st

from .. import clock, data, importer, storage, ui

LETTERS = "ABCD"
CLAUDE_FIELDS = ["chunks", "vi_question", "vi_full", "options_vi", "short", "easy", "super", "why_not", "tip",
                 "read_aloud"]
MERGE_FIELDS = CLAUDE_FIELDS + ["stem_en", "type_tag", "flag"]
ASK_CLAUDE = "Viết phần dịch và giải thích cho đề này theo đúng mẫu Học Bá"
TICK_SVG = ('<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" '
            'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5L19 7"></path></svg>')
CROSS_SVG = ('<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" '
             'stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"></path></svg>')

FAIL_TEXT = {
    "image": "File này giống **ảnh chụp** nên app không đọc được chữ. Bạn gửi file Word, hoặc nhắn Claude gõ lại giúp.",
    "broken": "App **không mở được** file này. File có thể bị hỏng. Bạn mở file trên máy, lưu lại rồi tải lên lần nữa.",
    "type": "App chỉ đọc được file **Word (.docx)** hoặc **PDF**.",
    "exam0": "App **không thấy câu hỏi nào**. Đề cần có số câu (1. 2. 3. …) và 4 lựa chọn A B C D.",
    "vocab0": "App **không thấy từ nào**. Mỗi dòng cần có từ tiếng Anh và nghĩa tiếng Việt.",
}
HINT = {
    "exam": "Giống 19 đề bạn đang có: mỗi câu có **số câu** (1. hoặc Câu 1:), **4 lựa chọn A B C D**, "
            "và **đáp án** (bảng đáp án cuối đề, dòng \"Đáp án: B\", hoặc chữ in đậm / gạch chân / tô màu).",
    "vocab": "Mỗi dòng một từ: **từ tiếng Anh**, **nghĩa tiếng Việt**, có thể kèm phiên âm và từ loại. "
             "Ví dụ: polite (adj) /pəˈlaɪt/: lịch sự. Hoặc một bảng có cột Từ · Nghĩa.",
}

CSS = """<style>
.up-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:4px 0 12px}
.up-stats.two{grid-template-columns:repeat(2,minmax(0,1fr))}
.up-stat{background:var(--hb-card);border:1px solid var(--hb-line);border-radius:14px;padding:10px 6px;text-align:center}
.up-stat b{display:block;font-family:Lexend,sans-serif;font-size:24px;line-height:1.2;color:var(--hb-green)}
.up-stat.warn b{color:var(--hb-orange-dark)} .up-stat.gray b{color:var(--hb-muted)}
.up-stat span{font-size:12.5px;color:var(--hb-muted);line-height:1.3;display:block}
.up-chips{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.up-q{background:var(--hb-card);border:1px solid var(--hb-line);border-radius:16px;padding:12px 14px;margin:0 0 8px;font-size:15px;color:var(--hb-ink)}
.up-q .lab{font-size:12px;font-weight:700;letter-spacing:.3px;color:var(--hb-muted);text-transform:uppercase;margin-bottom:2px}
.up-q .tx{font-weight:600;margin-bottom:4px;line-height:1.5}
.up-q .op{line-height:1.6} .up-q .op .ok{color:var(--hb-ok);font-weight:700}
.up-q .an{color:var(--hb-green-ink);font-size:14px;margin-top:4px}
.up-done{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;margin:10px 0 14px}
.up-tick{width:84px;height:84px;border-radius:999px;background:var(--hb-green-soft);color:var(--hb-green);display:flex;align-items:center;justify-content:center}
.up-tick.bad{background:var(--hb-bad-soft);color:var(--hb-bad)}
.up-done .big{font-family:Lexend,sans-serif;font-size:23px;font-weight:700;color:var(--hb-ink);line-height:1.3}
.up-done .txt{font-size:15px;color:var(--hb-muted);line-height:1.55;max-width:460px}
.up-kind{font-size:12px;font-weight:700;letter-spacing:.4px;color:var(--hb-muted);text-transform:uppercase}
.up-name{font-weight:700;font-size:16.5px;color:var(--hb-ink);word-break:break-word;line-height:1.35;margin:2px 0}
.up-meta{font-size:13.5px;color:var(--hb-muted);line-height:1.45}
.up-line{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;padding:10px 0;border-bottom:1px solid var(--hb-line)}
.up-line:last-child{border-bottom:0;padding-bottom:2px} .up-line:first-child{padding-top:2px}
.up-word{display:flex;gap:8px;align-items:baseline}
.st-key-up_probs{background:var(--hb-orange-soft);border-radius:16px;padding:12px 14px 6px;margin-bottom:10px}
.st-key-up_probs p{color:var(--hb-ink)}
.st-key-up_probs button[kind="secondary"]{min-height:40px;padding:0 14px;background:var(--hb-card)}
.st-key-up_nav{margin-bottom:-6px}
.st-key-up_drop [data-testid="stFileUploaderDropzoneInstructions"]{display:none}
.st-key-up_drop [data-testid="stFileUploaderDropzone"]{justify-content:center;border-radius:16px;border:2px dashed var(--hb-line);background:var(--hb-card);padding:18px 12px}
.st-key-up_drop [data-testid="stFileUploaderDropzone"] button{min-height:48px;border-radius:14px;padding:0 20px}
.st-key-up_drop [data-testid="stFileUploaderDropzone"] button [data-testid="stMarkdownContainer"]{display:none}
.st-key-up_drop [data-testid="stFileUploaderDropzone"] button [data-has-shortcut]::after{content:"Chọn file từ máy";font-size:16px;font-weight:600;margin-left:6px}
.up-legend{font-size:14px;color:var(--hb-ink);line-height:1.9}
[class*="st-key-up_doc_"]{background:var(--hb-card);border:1px solid var(--hb-line) !important;border-radius:18px !important}
[class*="st-key-up_doc_"] .up-last{margin-bottom:4px}
.st-key-up_wordbox{border:1px solid var(--hb-line) !important;border-radius:16px !important;background:var(--hb-card)}
.st-key-up_wordbox em{color:var(--hb-muted);font-size:14px}
[role="dialog"] button[aria-label="Close"]{color:var(--hb-ink) !important}
.stApp [data-variant="segmented_control"]{background:var(--hb-card) !important;color:var(--hb-ink) !important;border-color:var(--hb-line) !important}
.stApp [data-variant="segmented_control"][data-selected="true"]{background:var(--hb-green-soft) !important;color:var(--hb-green-ink) !important;border-color:var(--hb-green) !important}
.stApp [data-variant="segmented_control"] p{color:inherit !important}
[data-testid="stDialog"] div:has(> section[role="dialog"]), [role="dialog"]{background:var(--hb-card) !important;color:var(--hb-ink) !important}
[role="dialog"] h2, [role="dialog"] p, [role="dialog"] label{color:var(--hb-ink) !important}
[role="dialog"] input, [role="dialog"] textarea, [role="dialog"] [data-baseweb="input"],
[role="dialog"] [data-baseweb="textarea"], [role="dialog"] [data-baseweb="base-input"]{background:var(--hb-soft) !important;color:var(--hb-ink) !important;border-color:var(--hb-line) !important}
[role="dialog"] button[kind]{min-height:46px;border-radius:14px}
[role="dialog"] button[kind] p{font-size:15.5px !important;font-weight:600}
[role="dialog"] button[kind="secondary"]{background:var(--hb-card) !important;color:var(--hb-ink) !important;border:1.5px solid var(--hb-line) !important}
[role="dialog"] [data-variant="segmented_control"]{background:var(--hb-card) !important;color:var(--hb-ink) !important;border-color:var(--hb-line) !important;min-height:44px}
[role="dialog"] [data-variant="segmented_control"][data-selected="true"]{background:var(--hb-green-soft) !important;color:var(--hb-green-ink) !important;border-color:var(--hb-green) !important}
[role="dialog"] [data-variant="segmented_control"] p{color:inherit !important;font-weight:700}
</style>"""


# ======================= TIỆN ÍCH =======================
def _ss() -> dict:
    ss = st.session_state
    if "up" not in ss:
        ss.up = {"step": "pick", "n": 0}
    return ss.up


def _reset(keep_kind: bool = True):
    s = _ss()
    n = s.get("n", 0) + 1
    st.session_state.up = {"step": "pick", "n": n}


def _now_iso() -> str:
    return clock.now().replace(tzinfo=None).isoformat(timespec="seconds")


def _when(iso: str) -> str:
    try:
        d = datetime.fromisoformat(iso).date() if "T" in iso else date.fromisoformat(iso)
    except Exception:  # noqa: BLE001
        return ""
    t = clock.today()
    if d == t:
        return "hôm nay"
    if (t - d).days == 1:
        return "hôm qua"
    return clock.label(d)


def _docs() -> list:
    return storage.db()["uploads"]["docs"]


def _add_doc(**kw):
    _docs().append({"added": _now_iso(), **kw})
    storage.touch()


def _md_safe(s: str) -> str:
    return re.sub(r"([\\*_`\[\]<>#|~$])", r"\\\1", str(s or ""))


def _default_name(filename: str) -> str:
    stem = re.sub(r"\.(docx|pdf)$", "", filename or "Đề mới", flags=re.I)
    stem = re.sub(r"[_]+", " ", stem).strip() or "Đề mới"
    stem = stem[:40]
    names = {x["name"] for x in data.exam_list()}
    name, k = stem, 2
    while name in names:
        name = f"{stem} ({k})"
        k += 1
    return name


def _chip(status: str) -> str:
    return {"full": '<span class="hb-chip green">✓ Đầy đủ</span>',
            "wait": '<span class="hb-chip orange">Chờ Claude bổ sung</span>',
            "fail": '<span class="hb-chip red">✗ Chưa đọc được</span>'}.get(status, "")


def _nav(other: str):
    with st.container(horizontal=True, horizontal_alignment="distribute", vertical_alignment="center",
                      key="up_nav"):
        ui.back("Đề thi", "n3", "home", key="up_back")
        if other == "docs":
            if st.button("Tài liệu của tôi →", key="up_to_docs", type="tertiary"):
                ui.go("n3", "docs")
        else:
            if st.button("+ Thêm tài liệu", key="up_to_upload", type="tertiary"):
                _reset()
                ui.go("n3", "upload")


# ======================= ĐỌC FILE =======================
def _process(f, kind: str):
    s = _ss()
    name = f.name
    s.update({"file_id": f.file_id, "file_name": name, "kind": kind})
    try:
        lines = importer.read_text(f.getvalue(), name)
    except importer.ReadError as e:
        _fail(name, kind, e.kind)
        return
    except Exception:  # noqa: BLE001
        _fail(name, kind, "broken")
        return
    if kind == "exam":
        try:
            ex = importer.parse_exam(lines)
        except Exception:  # noqa: BLE001
            ex = {"questions": []}
        if not ex["questions"]:
            # thử xem có phải file từ vựng không, để nhắc người học
            maybe = len(importer.parse_vocab(lines)) >= 5
            _fail(name, kind, "exam0", hint_vocab=maybe)
            return
        s.update({"step": "review", "questions": ex["questions"], "passages": ex["passages"], "dropped": [],
                  "name": _default_name(name)})
    else:
        try:
            ws = importer.parse_vocab(lines)
        except Exception:  # noqa: BLE001
            ws = []
        if not ws:
            _fail(name, kind, "vocab0")
            return
        have = {str(w.get("word", "")).strip().lower() for w in data.words().values()}
        new = [w for w in ws if w["word"].strip().lower() not in have]
        s.update({"step": "review", "words": new, "dup": len(ws) - len(new)})


def _fail(name: str, kind: str, why: str, hint_vocab: bool = False):
    s = _ss()
    msg = FAIL_TEXT.get(why, FAIL_TEXT["broken"])
    if hint_vocab:
        msg += " File này giống **danh sách từ vựng**: bạn chọn \"Từ vựng\" ở trên rồi tải lại nhé."
    s.update({"step": "fail", "fail_msg": msg})
    _add_doc(name=name, type=kind, status="fail", ref="", filename=name, why=re.sub(r"\*\*", "", msg))


# ======================= VIEW: UPLOAD =======================
def _view_upload(params: dict):
    s = _ss()
    if not params.get("_up_seen"):
        params["_up_seen"] = True  # vừa mở trang: màn "đã xong" cũ thì làm lại từ đầu
        if s["step"] in ("done", "fail"):
            _reset()
            s = _ss()
    _nav("docs")
    step = s["step"]
    kind = s.get("kind", "exam")
    if step == "pick":
        ui.title("Thêm tài liệu", "Thêm đề thi hoặc từ vựng từ file của bạn.")
        _pick()
    elif step == "review" and kind == "exam":
        ui.title("Thêm đề thi mới")
        _review_exam()
    elif step == "review":
        ui.title("Thêm từ vựng")
        _review_vocab()
    elif step == "done":
        _done()
    else:
        ui.title("Thêm tài liệu")
        ui.html(f'<div class="up-done"><div class="up-tick bad">{CROSS_SVG}</div>'
                f'<div class="big">Chưa đọc được file</div>'
                f'<div class="txt">{ui.esc(s.get("file_name", ""))}</div></div>')
        ui.html(ui.box("red", "VÌ SAO", ui.md(s.get("fail_msg", ""))))
        ui.html(ui.box("gray", "FILE CẦN TRÔNG THẾ NÀO", ui.md(HINT[kind])))
        if st.button("Chọn file khác", key="up_retry", type="primary", width="stretch"):
            _reset()
            ui.rerun()
        if st.button("Xem Tài liệu của tôi", key="up_fail_docs", width="stretch"):
            ui.go("n3", "docs")


def _pick():
    s = _ss()
    ui.html('<div class="hb-h2">Bạn muốn thêm gì?</div>')
    kind = st.segmented_control("Loại tài liệu", ["exam", "vocab"], key="up_kind", default="exam", required=True,
                                format_func=lambda k: "Đề thi mới" if k == "exam" else "Từ vựng",
                                label_visibility="collapsed", width="stretch") or "exam"
    ui.html('<div class="hb-muted" style="margin:-2px 0 12px">' +
            ("Thành đề mới ở Ngăn Đề thi, làm được ngay." if kind == "exam"
             else "Thêm vào kho từ, thành thẻ ôn ở Ngăn Từ &amp; Ngữ pháp.") + "</div>")
    with st.container(key="up_drop"):
        f = st.file_uploader("File Word hoặc PDF, có chữ (không phải ảnh chụp)", type=["docx", "pdf"],
                             key=f"up_file_{s['n']}")
    with st.expander("File cần trông thế nào?"):
        ui.html(f'<div style="font-size:15px;line-height:1.6">{ui.md(HINT[kind])}</div>')
    if f is not None and f.file_id != s.get("file_id"):
        with st.spinner("Đang đọc file…"):
            _process(f, kind)
        ui.rerun()


# ---------- kiểm tra đề ----------
def _problems(s) -> list[dict]:
    dropped = set(s.get("dropped", []))
    keep = [(i, q) for i, q in enumerate(s["questions"]) if i not in dropped]
    probs = importer.find_problems([q for _, q in keep])
    for p in probs:
        p["i"] = keep[p["i"]][0]
    return probs


def _q_preview(q: dict) -> str:
    opts = []
    for k, o in enumerate(q["options"]):
        L = LETTERS[k]
        txt = f"{L}. {ui.esc(o) if o else '…'}"
        opts.append(f'<span class="ok">{txt}</span>' if q.get("answer") == L else txt)
    lab = f'Câu {ui.esc(q["num"])} · {ui.esc(q.get("part_label", ""))}'
    tx = ui.md(q["text"]) if q.get("text") else '<span class="hb-muted">(chỗ trống trong bài điền từ)</span>'
    an = f'Đáp án: <b>{q["answer"]}</b>' if q.get("answer") else "Chưa có đáp án"
    if q.get("why_original"):
        an += " · có giải thích gốc"
    return (f'<div class="up-q"><div class="lab">{lab}</div><div class="tx">{tx}</div>'
            f'<div class="op">{" · ".join(opts)}</div><div class="an">{an}</div></div>')


@st.dialog("Sửa câu")
def _edit_dialog(i: int):
    s = _ss()
    q = s["questions"][i]
    p = f"up_e{s['n']}_{i}_"
    num = st.text_input("Số câu", value=str(q["num"]), key=p + "num")
    text = st.text_area("Câu hỏi" + (" (bài điền từ thì để trống)" if q.get("part") == "cloze" else ""),
                        value=q.get("text", ""), key=p + "text", height=90)
    opts = []
    for k in range(4):
        opts.append(st.text_input(f"Lựa chọn {LETTERS[k]}", value=q["options"][k] if k < len(q["options"]) else "",
                                  key=p + f"o{k}"))
    ans = st.segmented_control("Đáp án đúng", list(LETTERS), default=q.get("answer") or None, key=p + "ans",
                               width="stretch", required=True)
    err = []
    if not all(o.strip() for o in opts):
        err.append("điền đủ 4 lựa chọn")
    if not ans:
        err.append("chọn đáp án đúng")
    n = num.strip()
    if not re.fullmatch(r"\d{1,3}[ab]?", n):
        err.append("số câu phải là số (ví dụ 12)")
    else:
        others = {str(x["num"]) for j, x in enumerate(s["questions"]) if j != i and j not in s.get("dropped", [])}
        if n in others:
            err.append(f"đã có câu số {n}, đổi số khác")
    if err:
        ui.html(f'<div class="hb-muted" style="margin:4px 0 8px">Cần: {ui.esc(", ".join(err))}.</div>')
    if st.button("Lưu câu này", key=p + "save", type="primary", width="stretch", disabled=bool(err)):
        q.update({"num": int(n) if n.isdigit() else n, "text": text.strip(),
                  "options": [o.strip() for o in opts], "answer": ans, "bonus": not n.isdigit()})
        ui.rerun()
    if st.button("Bỏ câu này", key=p + "drop", width="stretch"):
        s.setdefault("dropped", []).append(i)
        ui.rerun()


def _review_exam():
    s = _ss()
    qs = s["questions"]
    dropped = set(s.get("dropped", []))
    probs = _problems(s)
    bad_idx = {p["i"] for p in probs}
    alive = [q for i, q in enumerate(qs) if i not in dropped]
    good = [q for i, q in enumerate(qs) if i not in dropped and i not in bad_idx]
    n_ans = sum(1 for q in alive if q.get("answer"))
    ui.html(f'<div class="hb-sub">Đã đọc xong <b>{ui.esc(s["file_name"])}</b>. Bạn kiểm tra nhanh rồi bấm thêm.</div>')
    ui.html('<div class="up-stats">'
            f'<div class="up-stat"><b>{len(alive)}</b><span>câu đọc được</span></div>'
            f'<div class="up-stat"><b>{n_ans}</b><span>câu có đáp án</span></div>'
            f'<div class="up-stat {"warn" if probs else "gray"}"><b>{len(probs)}</b><span>câu cần sửa</span></div>'
            '</div>')
    # các phần + đoạn văn
    cnt = {}
    for q in good:
        cnt[q["part_label"]] = cnt.get(q["part_label"], 0) + 1
    chips = [f'<span class="hb-chip blue">{ui.esc(k)} {v}</span>' for k, v in cnt.items()]
    pas = s.get("passages") or {}
    if (pas.get("cloze") or {}).get("text"):
        chips.append('<span class="hb-chip gray">Có bài điền từ</span>')
    if (pas.get("reading") or {}).get("text"):
        chips.append('<span class="hb-chip gray">Có bài đọc</span>')
    ui.html(f'<div class="up-chips">{"".join(chips)}</div>')

    if probs:
        with st.container(key="up_probs"):
            ui.html(f'<div style="font-weight:700;color:var(--hb-orange-ink);font-size:15px">'
                    f'{len(probs)} câu app chưa tách được</div>')
            for p in probs[:30]:
                q = qs[p["i"]]
                head = (q.get("text") or " / ".join(o for o in q["options"] if o) or "")[:70]
                ui.html(f'<div style="font-size:15px;margin-top:8px;color:var(--hb-ink)"><b>Câu {ui.esc(p["num"])}</b>: '
                        f'{ui.esc(p["why"])}<div class="hb-muted" style="font-size:13.5px">{ui.esc(head)}</div></div>')
                with st.container(horizontal=True, gap="small"):
                    if st.button("Sửa", key=f"up_fix_{s['n']}_{p['i']}", icon=":material/edit:"):
                        _edit_dialog(p["i"])
                    if st.button("Bỏ câu này", key=f"up_drop_{s['n']}_{p['i']}"):
                        s.setdefault("dropped", []).append(p["i"])
                        ui.rerun()
            if len(probs) > 30:
                ui.html(f'<div class="hb-muted">… và {len(probs) - 30} câu nữa.</div>')
            ui.html('<div style="font-size:13.5px;color:var(--hb-orange-ink);margin:8px 0 6px">Không sửa cũng được: '
                    'câu lỗi sẽ được bỏ ra, các câu còn lại vẫn làm bình thường.</div>')
    if dropped:
        if st.button(f"Lấy lại {len(dropped)} câu đã bỏ", key=f"up_undrop_{s['n']}", type="tertiary"):
            s["dropped"] = []
            ui.rerun()

    if good:
        ui.html('<div class="hb-h2">Xem trước</div>')
        ui.html("".join(_q_preview(q) for q in good[:3]))
    name = st.text_input("Tên đề (bấm để đổi)", value=s.get("name", ""), key=f"up_name_{s['n']}", max_chars=40)
    s["name"] = name.strip() or s.get("name") or "Đề mới"

    if not good:
        ui.html(ui.box("red", "CHƯA THÊM ĐƯỢC", "Chưa có câu nào đủ 4 lựa chọn và đáp án. Bạn bấm <b>Sửa</b> ở trên."))
        label = "Thêm vào app"
    elif probs:
        label = f"Thêm {len(good)} câu đã đủ (bỏ {len(probs)} câu lỗi)"
    else:
        label = f"Thêm đề vào app ({len(good)} câu)"
    if st.button(label, key=f"up_add_{s['n']}", type="primary", width="stretch", disabled=not good):
        _add_exam(s, good)
    if st.button("Chọn file khác", key=f"up_other_{s['n']}", width="stretch"):
        _reset()
        ui.rerun()


def _add_exam(s, good: list[dict]):
    base = f"up_{int(time.time())}"
    eid, k = base, 2
    ups = storage.db()["uploads"]["exams"]
    while eid in ups:
        eid = f"{base}_{k}"
        k += 1
    qs = []
    for q in good:
        qs.append({"num": q["num"], "part": q["part"], "part_label": q["part_label"], "bonus": bool(q.get("bonus")),
                   "prompt": q.get("prompt", ""), "text": q.get("text", ""), "options": list(q["options"]),
                   "answer": q["answer"], "why_original": q.get("why_original", ""), "flag": ""})
    pas = s.get("passages") or {}
    passages = {"cloze": {"title": (pas.get("cloze") or {}).get("title", ""),
                          "text": (pas.get("cloze") or {}).get("text", "")},
                "reading": {"title": (pas.get("reading") or {}).get("title", ""),
                            "text": (pas.get("reading") or {}).get("text", "")}}
    fname = s["file_name"]
    eid = data.add_exam({"id": eid, "name": s["name"], "questions": qs, "passages": passages,
                         "note": f"Đề tải lên từ {fname}", "complete": False, "filename": fname})
    bad = len([q for i, q in enumerate(s["questions"]) if i not in set(s.get("dropped", []))]) - len(good)
    _add_doc(name=s["name"], type="exam", status="wait", ref=eid, filename=fname, count=len(qs),
             skipped=bad + len(s.get("dropped", [])))
    s.update({"step": "done", "eid": eid, "count": len(qs)})
    ui.rerun()


# ---------- kiểm tra từ vựng ----------
def _review_vocab():
    s = _ss()
    ws = s.get("words", [])
    ui.html(f'<div class="hb-sub">Đã đọc xong <b>{ui.esc(s["file_name"])}</b>. Bỏ chọn từ bạn không muốn, '
            f'rồi bấm thêm.</div>')
    ui.html('<div class="up-stats two">'
            f'<div class="up-stat"><b>{len(ws)}</b><span>từ mới</span></div>'
            f'<div class="up-stat gray"><b>{s.get("dup", 0)}</b><span>từ đã có trong kho (bỏ qua)</span></div>'
            '</div>')
    if not ws:
        ui.html(ui.box("green", "KHÔNG CÓ TỪ MỚI", "Các từ trong file đều đã có trong kho của bạn rồi."))
        if st.button("Chọn file khác", key=f"up_other_v_{s['n']}", type="primary", width="stretch"):
            _reset()
            ui.rerun()
        return
    pre = f"up_w{s['n']}_"
    with st.container(horizontal=True, gap="small"):
        if st.button("Chọn hết", key=pre + "all", type="tertiary"):
            for i in range(len(ws)):
                st.session_state[pre + str(i)] = True
            ui.rerun()
        if st.button("Bỏ hết", key=pre + "none", type="tertiary"):
            for i in range(len(ws)):
                st.session_state[pre + str(i)] = False
            ui.rerun()
    box = st.container(height=420 if len(ws) > 8 else "content", border=True, key="up_wordbox")
    picked = []
    with box:
        for i, w in enumerate(ws):
            extra = " · ".join(x for x in (w.get("pos", ""), w.get("ipa", "")) if x)
            lab = f"**{_md_safe(w['word'])}** — {_md_safe(w['meaning'])}"
            if extra:
                lab += f"  \n_{_md_safe(extra)}_"
            if st.checkbox(lab, value=st.session_state.get(pre + str(i), True), key=pre + str(i)):
                picked.append(w)
    ui.html('<div class="hb-muted" style="margin:8px 0 10px">Từ mới thành thẻ ôn ở Ngăn Từ &amp; Ngữ pháp, '
            'học dần cùng các từ khác.</div>')
    if st.button(f"Thêm {len(picked)} từ vào kho", key=pre + "add", type="primary", width="stretch",
                 disabled=not picked):
        have = {str(w.get("word", "")).strip().lower() for w in data.words().values()}
        ids = []
        for w in picked:
            if w["word"].strip().lower() in have:
                continue
            have.add(w["word"].strip().lower())
            ids.append(data.add_word(w["word"], w["meaning"], pos=w.get("pos", ""), ipa=w.get("ipa", ""),
                                     example=w.get("example", ""), source=s["file_name"]))
        _add_doc(name=re.sub(r"[_]+", " ", re.sub(r"\.(docx|pdf)$", "", s["file_name"], flags=re.I)), type="vocab", status="full",
                 ref=",".join(ids), filename=s["file_name"], count=len(ids))
        s.update({"step": "done", "count": len(ids)})
        ui.rerun()
    if st.button("Chọn file khác", key=pre + "other", width="stretch"):
        _reset()
        ui.rerun()


def _done():
    s = _ss()
    if s.get("kind") == "exam":
        name = s.get("name", "")
        ui.html(f'<div class="up-done"><div class="up-tick">{TICK_SVG}</div>'
                f'<div class="big">Đã thêm! {ui.esc(name)}</div>{_chip("wait")}'
                f'<div class="txt">Đề nằm trong <b>Ngăn Đề thi</b>, nhãn <b>Chờ Claude bổ sung</b> '
                f'(giải thích sẽ có khi Claude viết thêm). Bạn làm được ngay: có {s.get("count", 0)} câu và đáp án.'
                f'</div></div>')
        ui.html(ui.box("blue", "MUỐN CÓ DỊCH VÀ GIẢI THÍCH?",
                       "Vào <b>Tài liệu của tôi</b> → bấm <b>Tải file gửi Claude</b>, gửi file đó cho Claude và nhắn: "
                       f"<b>\"{ASK_CLAUDE}\"</b>. Claude trả file .json → bấm <b>Nhập bản Claude đã bổ sung</b>."))
        if st.button("Làm đề này ngay", key="up_go_exam", type="primary", width="stretch",
                     icon=":material/play_arrow:"):
            eid = s.get("eid")
            _reset()
            ui.go("n3", "exam", eid=eid)
    else:
        ui.html(f'<div class="up-done"><div class="up-tick">{TICK_SVG}</div>'
                f'<div class="big">Đã thêm {s.get("count", 0)} từ</div>{_chip("full")}'
                f'<div class="txt">Từ mới đã vào kho từ, thành thẻ ôn ở <b>Ngăn Từ &amp; Ngữ pháp</b>.</div></div>')
        if st.button("Ôn thẻ ngay", key="up_go_cards", type="primary", width="stretch", icon=":material/style:"):
            _reset()
            ui.go("n2", "cards")
    if st.button("Xem Tài liệu của tôi", key="up_done_docs", width="stretch"):
        _reset()
        ui.go("n3", "docs")
    if st.button("Thêm file khác", key="up_done_more", type="tertiary", width="stretch"):
        _reset()
        ui.rerun()


# ======================= VIEW: DOCS =======================
def _builtin_block():
    n_ex = len(data.builtin_index())
    n_prac = sum(1 for x in data.builtin_index() if x.get("kind") == "practice")
    n_w = len(data.vocab_raw()["words"])
    ls = data.lessons_list()
    n_d = sum(1 for x in ls if str(x["id"]).startswith("d"))
    n_b = len(ls) - n_d
    rows = [("Đề thi", f"{n_ex} đề (Đề 1–{n_prac} + {n_ex - n_prac} đề thi thử)",
             "Có dịch theo cụm, 3 mức giải thích và mẹo"),
            ("Từ vựng", f"Từ vựng {n_w} từ", "Có phát âm, họ từ, mẹo nhớ"),
            ("Bài học", f"Bài học {n_b} + {n_d} bài Cách dịch", "Ngữ pháp và cách dịch câu, có bài tập")]
    body = "".join(f'<div class="up-line"><div><div class="up-kind">{k}</div><div class="up-name">{ui.esc(t)}</div>'
                   f'<div class="up-meta">{ui.esc(m)}</div></div>{_chip("full")}</div>' for k, t, m in rows)
    ui.html(f'<div class="hb-card">{body}</div>')


def _missing_count(ex: dict) -> int:
    def empty(v):
        return v is None or v == "" or v == [] or v == {}
    return sum(1 for q in ex["questions"] if any(empty(q.get(f)) for f in CLAUDE_FIELDS))


def _merge_supplement(ex: dict, raw: bytes):
    """→ (đề mới, số câu còn thiếu, lỗi)."""
    try:
        sup = json.loads(raw.decode("utf-8-sig"))
    except Exception:  # noqa: BLE001
        return None, 0, "File này không phải file .json của Claude (mở không được)."
    sq = sup.get("questions") if isinstance(sup, dict) else sup
    if not isinstance(sq, list) or not all(isinstance(x, dict) and "num" in x for x in sq):
        return None, 0, "File này không có danh sách câu hỏi theo mẫu Học Bá."
    smap = {str(x["num"]): x for x in sq}
    mine = {str(q["num"]) for q in ex["questions"]}
    if len(smap) != len(mine) or set(smap) != mine:
        miss = sorted(mine - set(smap), key=lambda x: (len(x), x))[:5]
        more = sorted(set(smap) - mine, key=lambda x: (len(x), x))[:5]
        why = f"Đề của bạn có {len(mine)} câu, file của Claude có {len(smap)} câu."
        if miss:
            why += f" Thiếu câu {', '.join(miss)}."
        if more:
            why += f" Thừa câu {', '.join(more)}."
        return None, 0, why + " Có thể đây là file của đề khác."
    for q in ex["questions"]:
        a = str(smap[str(q["num"])].get("answer", "") or "").strip().upper()
        if a and a != q["answer"]:
            return None, 0, (f"Câu {q['num']}: đáp án trong file là {a}, còn đề của bạn là {q['answer']}. "
                             "Có thể đây là file của đề khác.")
    new_q = []
    for q in ex["questions"]:
        s = smap[str(q["num"])]
        nq = dict(q)
        for f in MERGE_FIELDS:
            if f in s and s[f] not in (None, ""):
                nq[f] = s[f]
        if not nq.get("why_original") and s.get("why_original"):
            nq["why_original"] = s["why_original"]
        new_q.append(nq)
    new_ex = {**ex, "questions": new_q}
    if isinstance(sup, dict) and isinstance(sup.get("passages_vi"), dict):
        new_ex["passages_vi"] = {**ex.get("passages_vi", {}), **sup["passages_vi"]}
    miss = _missing_count(new_ex)
    new_ex["complete"] = miss == 0
    return new_ex, miss, ""


def _export(ex: dict) -> str:
    out = {"huong_dan": (f"{ASK_CLAUDE}. Giữ nguyên num, options, answer. Mỗi câu viết thêm: stem_en, chunks, "
                        "vi_question, vi_full, options_vi, short, easy, why_not, super, tip, read_aloud, type_tag, flag. "
                        "Thêm passages_vi (cloze, reading) nếu có đoạn văn. Trả lại đúng file .json này."),
           **{k: v for k, v in ex.items() if k not in ("source",)}}
    return json.dumps(out, ensure_ascii=False, indent=1)


def _delete_exam(eid: str):
    db = storage.db()
    db["uploads"]["exams"].pop(eid, None)
    db.setdefault("deleted_exams", []).append(eid)   # để máy khác không gộp lại đề đã xóa
    db["attempts"].pop(eid, None)
    db["current"].pop(eid, None)
    db["settings"].get("exam", {}).pop(eid, None)
    for k in ("wrong", "flags"):
        for key in [x for x in db[k] if x.startswith(f"{eid}#")]:
            db[k].pop(key, None)
    db["uploads"]["docs"] = [d for d in db["uploads"]["docs"] if not (d.get("type") == "exam" and d.get("ref") == eid)]
    storage.touch()


def _doc_item(i: int, d: dict):
    ss = st.session_state
    ups = storage.db()["uploads"]["exams"]
    is_exam = d.get("type") == "exam"
    ex = ups.get(d.get("ref")) if is_exam else None
    status = d.get("status", "wait")
    if is_exam and ex is not None:
        status = "full" if ex.get("complete") else "wait"
    kind = "Đề thi" if is_exam else "Từ vựng"
    if status == "fail":
        meta = d.get("why", "File cần gửi lại dạng khác.")
    elif is_exam and ex is not None:
        n = sum(1 for q in ex["questions"] if not q.get("bonus"))
        meta = f"{n} câu · " + ("có đủ dịch, giải thích và mẹo" if status == "full"
                                else "làm được rồi · chưa có dịch và giải thích")
        if d.get("skipped"):
            meta += f" · đã bỏ {d['skipped']} câu lỗi"
    elif is_exam:
        meta = "Đề này đã bị xóa."
    else:
        meta = f"{d.get('count', 0)} từ mới · đã thành thẻ ôn"
    fn = d.get("filename") or ""
    when = _when(d.get("added", ""))
    with st.container(border=True, key=f"up_doc_{i}"):
        ui.html(f'<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start">'
                f'<div style="min-width:0"><div class="up-kind">{kind}</div>'
                f'<div class="up-name">{ui.esc(d.get("name") or fn)}</div>'
                f'<div class="up-meta">{ui.esc(fn)}{" · " + when if when else ""}</div></div>'
                f'<div style="flex:none">{_chip(status)}</div></div>'
                f'<div class="up-meta up-last" style="margin-top:6px;color:var(--hb-ink)">{ui.esc(meta)}</div>')
        if is_exam and ex is not None:
            eid = d["ref"]
            msg = ss.get(f"up_msg_{eid}")
            if msg:
                ui.html(ui.box(msg[0], msg[1], ui.md(msg[2])))
            with st.container(horizontal=True, gap="small"):
                fname = re.sub(r"[^\w\- ]+", "", ex["name"]).strip() or eid
                st.download_button("Tải file gửi Claude", _export(ex), file_name=f"{fname} - gui Claude.json",
                                   mime="application/json", key=f"up_dl_{eid}", icon=":material/download:",
                                   on_click="ignore")
                if st.button("Làm đề", key=f"up_open_{eid}", icon=":material/play_arrow:"):
                    ui.go("n3", "exam", eid=eid)
            with st.expander("Nhập bản Claude đã bổ sung"):
                cnt = ss.get(f"up_impn_{eid}", 0)
                f = st.file_uploader("File .json Claude gửi lại", type=["json"], key=f"up_imp_{eid}_{cnt}")
                if f is not None:
                    new_ex, miss, err = _merge_supplement(ex, f.getvalue())
                    if err:
                        ss[f"up_msg_{eid}"] = ("red", "CHƯA NHẬP ĐƯỢC", err)
                    else:
                        ups[eid] = new_ex
                        d["status"] = "full" if miss == 0 else "wait"
                        storage.touch()
                        if miss == 0:
                            ss[f"up_msg_{eid}"] = ("green", "ĐÃ NHẬP XONG",
                                                   "Đề đã **đầy đủ**: có dịch theo cụm, 3 mức giải thích và mẹo.")
                        else:
                            ss[f"up_msg_{eid}"] = ("orange", "ĐÃ NHẬP MỘT PHẦN",
                                                   f"Còn **{miss} câu** chưa đủ phần dịch và giải thích. "
                                                   "Gửi lại file cho Claude, nhắn: \"Viết nốt các câu còn thiếu\".")
                    ss[f"up_impn_{eid}"] = cnt + 1
                    ui.rerun()
        if ss.get("up_del") == i:
            ui.html(ui.box("red", "XÓA THẬT KHÔNG?",
                           "Đề này và <b>tiến độ làm đề này</b> (điểm, câu sai) sẽ mất hẳn." if is_exam
                           else "Chỉ xóa dòng này khỏi danh sách. Từ đã thêm vẫn còn trong kho."))
            with st.container(horizontal=True, gap="small"):
                if st.button("Xóa hẳn", key=f"up_delok_{i}", type="primary"):
                    if is_exam and d.get("ref"):
                        _delete_exam(d["ref"])
                        ss.pop(f"up_msg_{d['ref']}", None)
                    if d in _docs():
                        _docs().remove(d)
                    storage.touch()
                    ss.pop("up_del", None)
                    ui.rerun()
                if st.button("Thôi", key=f"up_delno_{i}"):
                    ss.pop("up_del", None)
                    ui.rerun()
        elif is_exam or status == "fail":
            if st.button("Xóa", key=f"up_del_{i}", type="tertiary", icon=":material/delete:"):
                ss["up_del"] = i
                ui.rerun()


def _view_docs():
    _nav("upload")
    ui.title("Tài liệu của tôi", "Những gì app đang có để bạn học.")
    ui.html('<div class="hb-h2">Có sẵn trong app</div>')
    _builtin_block()

    docs = list(enumerate(_docs()))
    docs.sort(key=lambda x: (x[1].get("added", ""), x[0]), reverse=True)
    ui.html('<div class="hb-h2">Bạn tải lên</div>')
    if not docs:
        ui.html('<div class="hb-card"><div class="up-meta" style="color:var(--hb-ink)">Chưa có tài liệu nào. '
                'Bạn có đề mới hoặc danh sách từ (file Word / PDF) thì bấm <b>Thêm tài liệu</b>.</div></div>')
    else:
        n_ex = sum(1 for _, d in docs if d.get("type") == "exam")
        n_v = len(docs) - n_ex
        if n_ex and n_v and len(docs) >= 4:
            opts = {"all": f"Tất cả {len(docs)}", "exam": f"Đề thi {n_ex}", "vocab": f"Từ vựng {n_v}"}
            flt = st.segmented_control("Lọc", list(opts), format_func=opts.get, default="all", required=True,
                                       key="up_filter", label_visibility="collapsed") or "all"
            if flt != "all":
                docs = [x for x in docs if x[1].get("type") == flt]
        waiting = any(d.get("type") == "exam" and d.get("status") == "wait" for _, d in docs)
        if waiting:
            ui.html(ui.box("blue", "CÁCH CÓ ĐỦ DỊCH VÀ GIẢI THÍCH",
                           "1. Bấm <b>Tải file gửi Claude</b> ở đề có nhãn Chờ Claude bổ sung.<br>"
                           f"2. Gửi file vừa tải cho Claude, nhắn: <b>\"{ASK_CLAUDE}\"</b>.<br>"
                           "3. Claude trả file .json → bấm <b>Nhập bản Claude đã bổ sung</b> và chọn file đó."))
        for i, d in docs:
            _doc_item(i, d)
    if st.button("Thêm tài liệu", key="up_docs_add", type="primary", width="stretch", icon=":material/upload_file:"):
        _reset()
        ui.go("n3", "upload")
    with st.expander("Ý nghĩa các nhãn"):
        ui.html('<div class="up-legend">'
                f'{_chip("full")} có hết dịch, giải thích, mẹo.<br>'
                f'{_chip("wait")} học được rồi, nhắn Claude để có thêm dịch và mẹo.<br>'
                f'{_chip("fail")} file cần gửi lại dạng khác (Word, có chữ).</div>')


# ======================= VÀO TRANG =======================
def render(view: str, params: dict):
    ui.html(CSS)
    if view == "docs":
        _view_docs()
    else:
        _view_upload(params)
