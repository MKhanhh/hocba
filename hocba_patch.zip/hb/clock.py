"""Giờ Việt Nam (máy chủ Streamlit chạy giờ quốc tế UTC nên phải đổi)."""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta, timezone

VN = timezone(timedelta(hours=7))
START_DAY = date(2026, 10, 30)
EXAM_DAY = date(2026, 11, 30)


def now() -> datetime:
    fake = os.environ.get("HOCBA_FAKE_NOW")  # chỉ dùng khi kiểm thử, ví dụ 2026-10-22T20:00
    if fake:
        return datetime.fromisoformat(fake).replace(tzinfo=VN)
    return datetime.now(VN)


def today() -> date:
    return now().date()


def days_left() -> int:
    return (EXAM_DAY - today()).days


def is_night() -> bool:
    h = now().hour
    return h >= 19 or h < 6


WD_SHORT = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
WD_LONG = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"]


def label(d: date, long: bool = True) -> str:
    return f"{(WD_LONG if long else WD_SHORT)[d.weekday()]}, {d.day}/{d.month}"
