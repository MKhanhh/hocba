"""Lưu tiến độ học.

- Có mã GITHUB_TOKEN trong Secrets  → lưu vào một Gist bí mật trên GitHub (không mất khi app khởi động lại).
- Không có mã                        → lưu tạm vào file trên máy chạy app (chỉ hợp khi chạy trên máy tính).
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import threading
import time
from pathlib import Path

import requests
import streamlit as st

GIST_DESC = "Hoc Ba - tien do hoc (dung xoa)"
GIST_FILE = "hocba_progress.json"
LOCAL_FILE = Path(os.environ.get("HOCBA_DATA_FILE") or Path(__file__).resolve().parent.parent / ".hocba_progress.json")

DEFAULT = {
    "v": 1,
    "rev": 0,                     # tăng mỗi lần lưu (để gộp khi học trên 2 máy)
    "wrong_cleared": 0,           # số câu sai đã "tốt nghiệp" khỏi bảng
    "profile": {"name": ""},
    "settings": {
        "theme": "auto",          # auto | light | dark
        "sound": True,
        "speak_wrong": True,
        "exam": {},               # exam_id -> {"level": 0|1|2, "auto_open": bool}
    },
    "tasks_done": {},             # task_id -> "YYYY-MM-DD"
    "moves": {},                  # task_id -> "YYYY-MM-DD" (ngày mới)
    "activity": {},               # "YYYY-MM-DD" -> phút đã học
    "attempts": {},               # exam_id -> [ {...} ]
    "current": {},                # exam_id -> bài đang làm dở
    "wrong": {},                  # "exam_id#num" -> {...}
    "flags": {},                  # "exam_id#num" -> {...}
    "cards": {},                  # word_id -> fsrs card dict
    "card_log": {},               # "YYYY-MM-DD" -> {"new": n, "reviews": n}
    "lessons": {},                # lesson_id -> {...}
    "uploads": {"exams": {}, "vocab": {}, "docs": []},   # docs: lịch sử tải tài liệu
    "translate": {},              # "YYYY-MM-DD" -> số câu đúng
    "notes": {},                  # "eid#num" -> ghi chú của người học
    "recall": {},                 # "eid#num" -> {"box", "due", "last", "seen"} nhắc lại cách quãng
    "edits": {},                  # nội dung giải thích / ngữ pháp người học tự viết lại
}


def _merge_defaults(data: dict) -> dict:
    out = copy.deepcopy(DEFAULT)
    for k, v in (data or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k].update(v)
        else:
            out[k] = v
    for k, v in DEFAULT["settings"].items():
        out["settings"].setdefault(k, copy.deepcopy(v))
    out["uploads"].setdefault("exams", {})
    out["uploads"].setdefault("vocab", {})
    out["uploads"].setdefault("docs", [])
    return out


def _token():
    """Mã GitHub dán trong Settings → Secrets của Streamlit (GITHUB_TOKEN = "...")."""
    try:
        tok = st.secrets.get("GITHUB_TOKEN", "")
    except Exception:  # noqa: BLE001  (không có file secrets)
        tok = ""
    return tok or os.environ.get("HOCBA_GITHUB_TOKEN", "")


_GIST_IDS: dict = {}     # mã băm của token -> id sổ Gist (nhớ lại để phiên sau khỏi tìm lại)


class GistBackend:
    name = "GitHub"

    def __init__(self, token: str):
        self.h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
                  "X-GitHub-Api-Version": "2022-11-28"}
        self.gist_id = None
        self.key = hashlib.sha256(token.encode()).hexdigest()[:16]

    def _find(self):
        page = 1
        while page < 10:
            r = requests.get("https://api.github.com/gists", headers=self.h,
                             params={"per_page": 100, "page": page}, timeout=15)
            r.raise_for_status()
            items = r.json()
            for g in items:
                if g.get("description") == GIST_DESC and GIST_FILE in g.get("files", {}):
                    return g["id"]
            if len(items) < 100:
                return None
            page += 1
        return None

    def load(self) -> dict:
        self.gist_id = _GIST_IDS.get(self.key)
        if self.gist_id:
            try:
                return self.load_quiet()
            except Exception:  # noqa: BLE001  (sổ đã bị xóa/đổi → tìm lại)
                self.gist_id = None
        self.gist_id = self._find()
        if self.gist_id:
            _GIST_IDS[self.key] = self.gist_id
        if not self.gist_id:
            r = requests.post("https://api.github.com/gists", headers=self.h, timeout=15, json={
                "description": GIST_DESC, "public": False,
                "files": {GIST_FILE: {"content": json.dumps(DEFAULT, ensure_ascii=False)}}})
            r.raise_for_status()
            self.gist_id = r.json()["id"]
            _GIST_IDS[self.key] = self.gist_id
            return {}
        return self.load_quiet()

    def load_quiet(self) -> dict:
        """Đọc bản đang lưu trên GitHub (không tạo mới)."""
        r = requests.get(f"https://api.github.com/gists/{self.gist_id}", headers=self.h, timeout=15)
        r.raise_for_status()
        f = r.json()["files"][GIST_FILE]
        content = f.get("content", "")
        if f.get("truncated") and f.get("raw_url"):
            content = requests.get(f["raw_url"], headers=self.h, timeout=20).text
        return json.loads(content or "{}")

    def save(self, data: dict):
        r = requests.patch(f"https://api.github.com/gists/{self.gist_id}", headers=self.h, timeout=20, json={
            "files": {GIST_FILE: {"content": json.dumps(data, ensure_ascii=False, separators=(",", ":"))}}})
        r.raise_for_status()


class LocalBackend:
    name = "máy này"

    def load(self) -> dict:
        if LOCAL_FILE.exists():
            return json.loads(LOCAL_FILE.read_text())
        return {}

    def save(self, data: dict):
        LOCAL_FILE.write_text(json.dumps(data, ensure_ascii=False))


class SyncWorker:
    """Đẩy tiến độ lên GitHub ở luồng nền, để bấm đáp án không phải chờ mạng.
    - Gộp: nhiều thay đổi liên tiếp chỉ đẩy 1 lần (chờ DEBOUNCE giây sau thay đổi cuối, tối đa MAX_WAIT giây).
    - Lỗi mạng: tự thử lại sau 5 · 15 · 45 · 60 giây, bản ghi chưa đẩy được vẫn giữ nguyên trong phiên.
    - Máy khác vừa lưu: gộp hai bản (không ghi đè mất). Luồng này KHÔNG được gọi st.* (chỉ requests + json)."""
    MAX_WAIT = 15.0
    IDLE_EXIT = 90.0
    MAX_FAILS = 8
    BACKOFF = 5.0           # giây chờ sau lần lỗi đầu (x3 mỗi lần, tối đa 60)

    def __init__(self, backend, rev: int):
        self.be = backend
        self.rev_known = rev
        self.cv = threading.Condition()
        self.snap = None
        self.due = 0.0
        self.first = 0.0
        self.thread = None
        self.busy = False
        self.inbox = None
        self.error = ""
        self.fails = 0
        self.pushes = 0
        self.last_ok = time.time()

    # ---- gọi từ luồng chính (nhanh, không chờ mạng) ----
    def submit(self, snap_json: str, delay: float):
        now = time.time()
        with self.cv:
            if self.snap is None:
                self.first = now
            self.snap = snap_json
            self.due = now if delay <= 0 else min(now + delay, self.first + self.MAX_WAIT)
            if not (self.thread and self.thread.is_alive()):
                self.fails = 0 if self.fails >= self.MAX_FAILS else self.fails
                self.thread = threading.Thread(target=self._run, name="hb-sync", daemon=True)
                self.thread.start()
            self.cv.notify()

    def take_inbox(self):
        with self.cv:
            x, self.inbox = self.inbox, None
        return x

    def pending(self) -> bool:
        return self.snap is not None or self.busy

    # ---- luồng nền ----
    def _run(self):
        idle_since = time.time()
        while True:
            with self.cv:
                while self.snap is None or time.time() < self.due:
                    self.cv.wait(timeout=2.0 if self.snap is None else max(0.05, self.due - time.time()))
                    if self.snap is None and time.time() - idle_since > self.IDLE_EXIT:
                        self.thread = None
                        return
                snap, self.snap, self.busy = self.snap, None, True
            ok = self._push(snap)
            with self.cv:
                self.busy = False
                idle_since = time.time()
                if ok:
                    self.fails = 0
                    self.error = ""
                    self.last_ok = idle_since
                else:
                    self.fails += 1
                    if self.snap is None:
                        self.snap = snap          # giữ lại để thử lại
                    if self.fails >= self.MAX_FAILS:
                        self.thread = None        # nghỉ; lần thay đổi sau sẽ đánh thức lại
                        return
                    self.first = idle_since
                    self.due = idle_since + min(60.0, self.BACKOFF * 3 ** min(self.fails - 1, 2))

    def _push(self, snap_json: str) -> bool:
        try:
            local = json.loads(snap_json)
            remote_rev = 0
            merged = local
            if isinstance(self.be, GistBackend):
                remote = _merge_defaults(self.be.load_quiet())
                remote_rev = remote.get("rev", 0)
                if remote_rev > self.rev_known:       # máy khác đã lưu từ lần trước → gộp
                    merged = merge(remote, local)
                    self.inbox = merged
            merged["rev"] = max(remote_rev, local.get("rev", 0)) + 1
            self.be.save(merged)
            self.rev_known = merged["rev"]
            self.pushes += 1
            return True
        except Exception as e:  # noqa: BLE001
            self.error = f"Chưa lưu được lên GitHub, app sẽ tự thử lại. ({str(e)[:100]})"
            return False


def init():
    """Gọi đầu mỗi lần chạy. Tải tiến độ một lần cho mỗi phiên."""
    if "db" in st.session_state:
        return
    tok = _token()
    backend = GistBackend(tok) if tok else LocalBackend()
    err = ""
    try:
        data = backend.load()
    except Exception as e:  # noqa: BLE001
        err = f"Không mở được kho GitHub ({e}). Tạm lưu trên máy chủ, có thể mất khi app khởi động lại."
        backend = LocalBackend()
        data = backend.load()
    ss = st.session_state
    ss.db = _merge_defaults(data)
    ss.db_backend = backend
    ss.db_error = err
    ss.db_dirty = False
    ss.db_changes = 0
    ss.db_worker = SyncWorker(backend, ss.db.get("rev", 0)) if isinstance(backend, GistBackend) else None


def db() -> dict:
    return st.session_state.db


def touch(n: int = 0):
    """Đánh dấu đã có thay đổi cần lưu. n = số 'việc đáng kể' (1 câu trả lời, 1 thẻ chấm...);
    cứ đủ 5 việc là đẩy lên GitHub ngay, chưa đủ thì gộp lại chờ vài giây."""
    ss = st.session_state
    ss.db_dirty = True
    ss.db_changes = ss.get("db_changes", 0) + n


DEBOUNCE = 4.0       # giây chờ gộp thay đổi trước khi đẩy lên GitHub


def flush(force: bool = False):
    """Không chờ mạng. Có thay đổi thì giao cho luồng nền lưu lên GitHub (hoặc ghi file nếu chạy trên máy).
    force=True: đẩy ngay (khi rời khỏi đề, bấm xong việc...)."""
    ss = st.session_state
    w = ss.get("db_worker")
    if w is not None:
        inbox = w.take_inbox()
        if inbox is not None:                     # máy khác vừa lưu: nhận phần mới của họ
            ss.db = merge(inbox, ss.db)
            ss.db_dirty = True
    if not ss.get("db_dirty"):
        return
    if w is not None:
        now = force or ss.get("db_changes", 0) >= 5
        if now:
            ss.db_changes = 0
        w.submit(json.dumps(ss.db, ensure_ascii=False, separators=(",", ":")), 0 if now else DEBOUNCE)
    else:
        ss.db["rev"] = ss.db.get("rev", 0) + 1
        try:
            ss.db_backend.save(ss.db)
        except Exception as e:  # noqa: BLE001
            ss.db_error = f"Chưa lưu được: {str(e)[:120]}"
            return
    ss.db_dirty = False


def sync_error() -> str:
    """Lỗi lưu GitHub đang tồn tại (rỗng nếu ổn). Chỉ báo khi đã thất bại từ 2 lần liên tiếp."""
    w = st.session_state.get("db_worker")
    return w.error if (w is not None and w.fails >= 2) else ""


def sync_pending() -> bool:
    w = st.session_state.get("db_worker")
    return bool(w and (w.pending() or st.session_state.get("db_dirty")))


# ---------- Gộp dữ liệu khi học trên 2 máy ----------
def merge(remote: dict, local: dict) -> dict:
    """Gộp tiến độ: giữ phần nhiều hơn / mới hơn của mỗi mục."""
    out = copy.deepcopy(remote)
    L = local
    for k in ("tasks_done", "moves", "flags", "current"):
        out[k].update(L.get(k, {}))
    out.setdefault("notes", {}).update(L.get("notes", {}))
    out.setdefault("edits", {}).update(L.get("edits", {}))
    rc = out.setdefault("recall", {})
    for k, v in L.get("recall", {}).items():
        r = rc.get(k)
        if not r or (v.get("last") or "") >= (r.get("last") or ""):
            rc[k] = v
    for k in ("activity", "translate"):
        for d, v in L.get(k, {}).items():
            out[k][d] = max(out[k].get(d, 0), v)
    for d, v in L.get("card_log", {}).items():
        r = out["card_log"].get(d, {"new": 0, "reviews": 0})
        out["card_log"][d] = {"new": max(r["new"], v["new"]), "reviews": max(r["reviews"], v["reviews"])}
    for w, c in L.get("cards", {}).items():
        r = out["cards"].get(w)
        if not r or (c.get("last_review") or "") >= (r.get("last_review") or ""):
            out["cards"][w] = c
    for eid, rs in L.get("attempts", {}).items():
        r = out["attempts"].get(eid, [])
        if len(rs) > len(r) or (len(rs) == len(r) and rs and len(rs[-1]["answers"]) >= len(r[-1]["answers"])):
            out["attempts"][eid] = rs
    for lid, v in L.get("lessons", {}).items():
        r = out["lessons"].get(lid)
        if not r or len(v.get("reviews", [])) >= len(r.get("reviews", [])):
            out["lessons"][lid] = v
    # bảng câu sai: lấy bản của máy đang dùng cho câu nó biết, thêm câu chỉ máy kia có
    w = dict(out["wrong"])
    w.update(L.get("wrong", {}))
    out["wrong"] = w
    out["wrong_cleared"] = max(out.get("wrong_cleared", 0), L.get("wrong_cleared", 0))
    for k in ("exams", "vocab"):
        out["uploads"][k].update(L.get("uploads", {}).get(k, {}))
    gone = set(out.get("deleted_exams", [])) | set(L.get("deleted_exams", []))
    out["deleted_exams"] = sorted(gone)
    for eid in gone:
        out["uploads"]["exams"].pop(eid, None)
        out["attempts"].pop(eid, None)
    names = {(d.get("name"), d.get("added")) for d in out["uploads"]["docs"]}
    out["uploads"]["docs"] += [d for d in L.get("uploads", {}).get("docs", []) if (d.get("name"), d.get("added")) not in names]
    out["settings"] = L.get("settings", out["settings"])
    out["profile"] = L.get("profile", out["profile"])
    return out


def export_json() -> str:
    return json.dumps(st.session_state.db, ensure_ascii=False, indent=1)


def import_json(text: str):
    st.session_state.db = _merge_defaults(json.loads(text))
    st.session_state.db["rev"] = st.session_state.db.get("rev", 0) + 1000  # bản nhập vào là bản mới nhất
    touch()
    flush(force=True)


def backend_name() -> str:
    return st.session_state.db_backend.name
