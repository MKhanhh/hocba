"""Ghi và đọc tiến độ: lượt làm đề, bảng câu sai, câu đánh dấu, bài học, luyện dịch, ngày học.

Dữ liệu nằm trong storage.db() — xem DEFAULT ở storage.py.
"""
from __future__ import annotations

from datetime import date, timedelta

from . import data, storage
from .clock import today

MILESTONES = [30, 35, 42]
LESSON_GAPS = [1, 3, 7, 14]          # ôn lại bài ngữ pháp sau 1, 3, 7, 14 ngày
WRONG_CLEAR_DAYS = 3                  # đúng ở 3 ngày khác nhau thì xóa khỏi bảng câu sai


def _db():
    return storage.db()


def _t() -> str:
    return today().isoformat()


# ================= NGÀY HỌC =================
def mark_activity(n: int = 1):
    act = _db()["activity"]
    act[_t()] = act.get(_t(), 0) + n
    storage.touch()


def streak() -> int:
    act = _db()["activity"]
    d = today()
    if not act.get(d.isoformat()):
        d -= timedelta(days=1)
    s = 0
    while act.get(d.isoformat()):
        s += 1
        d -= timedelta(days=1)
    return s


# ================= LƯỢT LÀM ĐỀ =================
def rounds(eid: str) -> list[dict]:
    return _db()["attempts"].get(eid, [])


def current_round(eid: str) -> dict | None:
    r = rounds(eid)
    return r[-1] if r and not r[-1].get("finished") else None


def start_round(eid: str) -> dict:
    rs = _db()["attempts"].setdefault(eid, [])
    r = {"n": len(rs) + 1, "started": _t(), "answers": {}, "correct": {}, "finished": None}
    rs.append(r)
    storage.touch()
    return r


def answer(eid: str, num, letter: str) -> bool:
    """Ghi 1 câu trả lời trong lượt hiện tại (tự mở lượt mới nếu chưa có). Trả về đúng/sai.
    Chỉ lần chọn ĐẦU TIÊN của mỗi câu trong một lượt được tính điểm."""
    q = data.question(eid, num)
    ok = bool(q and q.get("answer") == letter)
    r = current_round(eid) or start_round(eid)
    k = str(num)
    if k not in r["answers"]:
        r["answers"][k] = letter
        r["correct"][k] = ok
        ex = data.exam(eid)
        need = {str(x["num"]) for x in data.scored_questions(ex)}
        if need and need <= set(r["answers"]):
            r["finished"] = _t()
    if q and not q.get("bonus"):
        _wrong_record(eid, num, ok, q.get("part", ""))
        recall_seen(eid, num, ok)
    mark_activity()
    storage.touch(1)
    return ok


def round_score(eid: str, r: dict) -> tuple[int, int, int]:
    """(số câu đúng, số câu đã làm, tổng câu tính điểm)"""
    ex = data.exam(eid)
    scored = {str(q["num"]) for q in data.scored_questions(ex)}
    done = [k for k in r["answers"] if k in scored]
    return sum(1 for k in done if r["correct"].get(k)), len(done), len(scored)


def range_done(eid: str, part: str) -> bool:
    """Lượt hiện tại/lượt cuối đã làm hết các câu trong khoảng part ('1-25', '26-50', '1-50') chưa."""
    rs = rounds(eid)
    if not rs:
        return False
    ex = data.exam(eid)
    nums = [str(q["num"]) for q in questions_in_range(ex, part) if not q.get("bonus")]
    return all(k in rs[-1]["answers"] for k in nums)


def questions_in_range(ex: dict, part: str = "1-50") -> list[dict]:
    """Lọc câu theo khoảng số '1-25' / '26-50' / '1-50'. Câu 30a/30b tính theo số 30."""
    try:
        lo, hi = (int(x) for x in part.split("-"))
    except Exception:  # noqa: BLE001
        lo, hi = 1, 10**6
    out = []
    for q in ex["questions"]:
        n = int("".join(ch for ch in str(q["num"]) if ch.isdigit()) or 0)
        if lo <= n <= hi:
            out.append(q)
    return out


def exam_summary(eid: str) -> dict:
    """{'rounds': [(đúng, đã làm, tổng, xong?)...], 'first': int|None, 'last': int|None, 'best': int|None,
        'gain': int|None, 'in_progress': (đã làm, tổng)|None}
    first/last/best là điểm các lượt ĐÃ LÀM XONG."""
    out = {"rounds": [], "first": None, "last": None, "best": None, "gain": None, "in_progress": None}
    fin = []
    for r in rounds(eid):
        c, a, t = round_score(eid, r)
        out["rounds"].append((c, a, t, bool(r.get("finished"))))
        if r.get("finished"):
            fin.append(c)
        else:
            out["in_progress"] = (a, t)
    if fin:
        out["first"], out["last"], out["best"] = fin[0], fin[-1], max(fin)
        if len(fin) > 1:
            out["gain"] = fin[-1] - fin[0]
    return out


def milestone(score: int | None) -> int | None:
    """Mốc cao nhất đã đạt (30/35/42) hoặc None."""
    if score is None:
        return None
    hit = [m for m in MILESTONES if score >= m]
    return hit[-1] if hit else None


def next_milestone(score: int | None) -> int | None:
    for m in MILESTONES:
        if score is None or score < m:
            return m
    return None


def recent_exams(n: int = 5) -> list[str]:
    """Các đề có lượt làm gần nhất (mới nhất trước)."""
    items = []
    for eid, rs in _db()["attempts"].items():
        if rs and data.exam(eid):
            last = max(r.get("finished") or r.get("started") or "" for r in rs)
            items.append((last, eid))
    return [e for _, e in sorted(items, reverse=True)[:n]]


def weakest_exam() -> str | None:
    """Đề đã làm xong có điểm lượt gần nhất thấp nhất (để làm lại lần 3)."""
    best = None
    for eid in _db()["attempts"]:
        s = exam_summary(eid)
        if s["last"] is not None and (best is None or s["last"] < best[0]):
            best = (s["last"], eid)
    return best[1] if best else None


def part_stats() -> dict:
    """Mạnh/yếu theo 5 phần: {part: (đúng, đã làm)} tính trên mọi lượt."""
    out = {p: [0, 0] for p, _ in data.PARTS}
    for eid, rs in _db()["attempts"].items():
        ex = data.exam(eid)
        if not ex:
            continue
        part_of = {str(q["num"]): q.get("part") for q in ex["questions"]}
        for r in rs:
            for k, ok in r["correct"].items():
                p = part_of.get(k)
                if p in out:
                    out[p][1] += 1
                    out[p][0] += 1 if ok else 0
    return {p: tuple(v) for p, v in out.items()}


# ================= BẢNG CÂU SAI =================
def _wkey(eid, num) -> str:
    return f"{eid}#{num}"


def _wrong_record(eid, num, ok: bool, part: str):
    w = _db()["wrong"]
    k = _wkey(eid, num)
    t = _t()
    if not ok:
        it = w.setdefault(k, {"eid": eid, "num": num, "part": part, "wrong": 0, "days": [], "last": t, "added": t})
        it["wrong"] += 1
        it["days"] = []          # sai thì đếm lại từ đầu
        it["last"] = t
    elif k in w:
        it = w[k]
        if t != it["last"] and t not in it["days"]:   # mỗi ngày tính 1 lần, không tính ngày vừa sai
            it["days"].append(t)
        if len(it["days"]) >= WRONG_CLEAR_DAYS:
            del w[k]
            _db()["wrong_cleared"] = _db().get("wrong_cleared", 0) + 1
    storage.touch()


def wrong_answer(eid, num, letter: str) -> bool:
    """Làm lại 1 câu trong bảng câu sai (không tính vào lượt làm đề)."""
    q = data.question(eid, num)
    ok = bool(q and q.get("answer") == letter)
    _wrong_record(eid, num, ok, q.get("part", "") if q else "")
    recall_seen(eid, num, ok)
    mark_activity()
    storage.touch(1)
    return ok


def wrong_list(part: str | None = None) -> list[dict]:
    """Sai nhiều nhất trước. Mỗi mục: {key, eid, num, part, wrong, days, last, added, done_today}."""
    t = _t()
    out = []
    for k, it in _db()["wrong"].items():
        if part and it.get("part") != part:
            continue
        if not data.question(it["eid"], it["num"]):
            continue
        out.append({**it, "key": k, "done_today": t in it["days"] or it["last"] == t})
    out.sort(key=lambda x: (-x["wrong"], x["last"]))
    return out


def wrong_due(part: str | None = None) -> list[dict]:
    """Câu sai cần làm lại hôm nay (hôm nay chưa đúng, hôm nay chưa sai)."""
    return [x for x in wrong_list(part) if not x["done_today"]]


# ================= CÂU ĐÁNH DẤU "VẪN CHƯA HIỂU" =================
def flag(eid, num, note: str, level: int):
    _db()["flags"][_wkey(eid, num)] = {"eid": eid, "num": num, "note": note.strip(), "level": level, "date": _t()}
    storage.touch()


def unflag(eid, num):
    _db()["flags"].pop(_wkey(eid, num), None)
    storage.touch()


def flag_of(eid, num) -> dict | None:
    return _db()["flags"].get(_wkey(eid, num))


def flags(eid: str | None = None) -> list[dict]:
    return [f for f in _db()["flags"].values() if eid is None or f["eid"] == eid]


# ================= CÀI ĐẶT TỪNG ĐỀ =================
LEVELS = ["Ngắn gọn", "Dễ hiểu", "Siêu dễ"]


def exam_settings(eid: str) -> dict:
    s = _db()["settings"]["exam"].get(eid, {})
    return {"level": s.get("level", 1), "auto_open": s.get("auto_open", True)}


def set_exam_settings(eid: str, **kw):
    _db()["settings"]["exam"].setdefault(eid, {}).update(kw)
    storage.touch()


# ================= BÀI HỌC =================
def lesson_state(lid: str) -> dict:
    """{} nếu chưa học. Có: first (ngày học xong), score, reviews [ngày], next (ngày ôn tiếp) hoặc None."""
    return _db()["lessons"].get(lid, {})


def lesson_finish(lid: str, score: int):
    """Gọi khi làm xong phần tập của 1 bài (lần đầu hoặc lần ôn)."""
    L = _db()["lessons"].setdefault(lid, {})
    t = today()
    if not L.get("first"):
        L.update({"first": t.isoformat(), "score": score, "reviews": []})
        gap = LESSON_GAPS[0]
    else:
        L["reviews"].append(t.isoformat())
        L["score"] = max(L.get("score", 0), score)
        i = len(L["reviews"])
        gap = LESSON_GAPS[i] if i < len(LESSON_GAPS) else None
    L["next"] = (t + timedelta(days=gap)).isoformat() if gap else None
    mark_activity()
    storage.touch(5)


def lessons_due() -> list[str]:
    t = _t()
    return [lid for lid, L in _db()["lessons"].items() if L.get("next") and L["next"] <= t]


def next_lesson() -> str | None:
    """Bài chưa học tiếp theo theo thứ tự trong lịch."""
    order = []
    for day in data.schedule():
        for tk in day["tasks"]:
            if tk["type"] == "lesson" and not tk.get("review") and tk["ref"] not in order:
                order.append(tk["ref"])
    for x in data.lessons_list():
        if x["id"] not in order:
            order.append(x["id"])
    for lid in order:
        if not lesson_state(lid).get("first"):
            return lid
    return None


# ================= LUYỆN DỊCH =================
def translate_count(day: date | None = None) -> int:
    return _db()["translate"].get((day or today()).isoformat(), 0)


def translate_add():
    tr = _db()["translate"]
    tr[_t()] = tr.get(_t(), 0) + 1
    mark_activity()
    storage.touch()


# ================= GHI CHÚ TỪNG CÂU =================
def note_get(eid, num) -> str:
    return _db().setdefault("notes", {}).get(_wkey(eid, num), "")


def note_set(eid, num, text: str):
    n = _db().setdefault("notes", {})
    k = _wkey(eid, num)
    if text.strip():
        n[k] = text.strip()
    else:
        n.pop(k, None)
    storage.touch(3)


# ================= NHẮC LẠI CÁCH QUÃNG (mọi câu đã làm) =================
RECALL_GAPS = [1, 3, 6, 12, 20]     # hộp 0..4: làm đúng thì lên hộp, sai thì về hộp 0 (mai làm lại)


def _rc() -> dict:
    return _db().setdefault("recall", {})


def _recall_set(k: str, it: dict, ok: bool):
    t = today()
    it["box"] = min(it.get("box", 0) + 1, len(RECALL_GAPS) - 1) if ok else 0
    it["due"] = (t + timedelta(days=RECALL_GAPS[it["box"]])).isoformat()
    it["last"] = t.isoformat()
    it["n"] = it.get("n", 0) + 1
    it["ok"] = it.get("ok", 0) + (1 if ok else 0)


def recall_seen(eid, num, ok: bool):
    """Gọi mỗi lần trả lời 1 câu ở đề hoặc bảng câu sai. Câu mới vào hàng nhắc lại;
    câu đã có mà đến hạn thì tính như 1 lần nhắc lại."""
    k = _wkey(eid, num)
    rc = _rc()
    it = rc.get(k)
    if it is None:
        it = rc[k] = {"eid": eid, "num": num, "seen": _t(), "box": 0}   # lần đầu: đúng → 3 ngày sau, sai → mai
        _recall_set(k, it, ok)
    elif it.get("due", "") <= _t() and it.get("last") != _t():
        _recall_set(k, it, ok)
    storage.touch()


def recall_answer(eid, num, ok: bool):
    k = _wkey(eid, num)
    it = _rc().setdefault(k, {"eid": eid, "num": num, "seen": _t(), "box": 0})
    _recall_set(k, it, ok)
    mark_activity()
    storage.touch(1)


def recall_due() -> list[dict]:
    """Câu đến hạn nhắc lại hôm nay (hôm nay chưa làm), hộp thấp (hay quên) trước."""
    t = _t()
    out = [{**v, "key": k} for k, v in _rc().items()
           if v.get("due", "") <= t and v.get("last") != t and data.question(v["eid"], v["num"])]
    out.sort(key=lambda x: (x.get("box", 0), x.get("due", ""), x["key"]))
    return out


def recall_done_today() -> int:
    t = _t()
    return sum(1 for v in _rc().values() if v.get("last") == t and v.get("seen") != t)


def recall_stats() -> dict:
    t = today()
    boxes = [0] * len(RECALL_GAPS)
    tomorrow = (t + timedelta(days=1)).isoformat()
    nxt = 0
    for v in _rc().values():
        boxes[max(0, min(v.get("box", 0), len(boxes) - 1))] += 1
        if v.get("due", "") <= tomorrow:
            nxt += 1
    return {"total": len(_rc()), "boxes": boxes, "due": len(recall_due()), "tomorrow": nxt,
            "done_today": recall_done_today()}


# ================= NỘI DUNG TỰ VIẾT LẠI (giải thích, ngữ pháp) =================
def edit_get(key: str) -> str:
    return _db().setdefault("edits", {}).get(key, "")


def edit_set(key: str, text: str):
    e = _db().setdefault("edits", {})
    if text.strip():
        e[key] = text.strip()
    else:
        e.pop(key, None)
    storage.touch(3)
