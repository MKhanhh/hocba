/* Học Bá – phím tắt khi làm câu: 1 2 3 4 = chọn A B C D · Enter = chốt đáp án · Enter lần nữa = sang câu sau. */
(function () {
  var W = window, D = document;
  if (W.HBK && W.HBK.off) W.HBK.off();
  var K = W.HBK = { ver: "1" }, sel = null;
  if (!D.getElementById("hbk-css")) {
    var s = D.createElement("style"); s.id = "hbk-css";
    s.textContent = "button.hb-ksel{outline:3px solid #F2A65A!important;outline-offset:2px;" +
      "box-shadow:0 0 0 6px rgba(242,166,90,.25)!important}";
    D.head.appendChild(s);
  }
  function vis(b) { return b && b.isConnected && b.offsetParent !== null; }
  function opts() { return Array.prototype.slice.call(D.querySelectorAll('[class*="st-key-n3_opt_"] button')).filter(vis); }
  function find(re) {
    return Array.prototype.slice.call(D.querySelectorAll("button")).find(function (b) {
      return vis(b) && re.test((b.innerText || "").trim());
    });
  }
  function clear() { if (sel && sel.isConnected) sel.classList.remove("hb-ksel"); sel = null; }
  function onKey(e) {
    if (e.ctrlKey || e.metaKey || e.altKey || e.isComposing) return;
    var t = e.target, tag = ((t && t.tagName) || "").toLowerCase();
    if (tag === "textarea" || tag === "input" || tag === "select" || (t && t.isContentEditable)) return;
    var o = opts();
    if (/^[1-4]$/.test(e.key)) {
      var i = +e.key - 1;
      if (i >= o.length) return;
      e.preventDefault();
      clear(); sel = o[i]; sel.classList.add("hb-ksel");
      try { sel.scrollIntoView({ block: "nearest" }); } catch (x) {}
      return;
    }
    if (e.key !== "Enter") return;
    if (o.length) {                                  // chưa chốt: Enter = chọn đáp án đang tô
      if (sel && o.indexOf(sel) >= 0) { var b = sel; e.preventDefault(); clear(); b.click(); }
      return;
    }
    var th = find(/Nhớ ra rồi/);                     // ô "thử nhớ lại 5 giây"
    if (th) { e.preventDefault(); th.click(); return; }
    var nx = find(/^(Câu sau|Câu tiếp|Xem kết quả|Làm câu còn sót)\s*→/);
    if (nx) { e.preventDefault(); clear(); nx.click(); }
  }
  D.addEventListener("keydown", onKey, true);
  K.off = function () { D.removeEventListener("keydown", onKey, true); clear(); };
})();
