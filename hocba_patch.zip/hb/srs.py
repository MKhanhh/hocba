"""Ôn từ cách quãng bằng FSRS (thuật toán của Anki đời mới).

3 nút: Quên (again) · Mang máng (hard) · Nhớ chắc (good).
Ngày ôn không bao giờ hẹn quá 20/11 (2 ngày trước thi) để chắc chắn được ôn trước ngày thi.
"""
from __future__ import annotations

import zlib
from datetime import datetime, timedelta, timezone

from fsrs import Card, Rating, Scheduler, State

from . import data, storage
from .clock import EXAM_DAY, VN, now, today

LAST_REVIEW_DAY = datetime(2026, 11, 20, 7, 0, tzinfo=VN)  # hạn ôn muộn nhất trước thi
ROUND_SIZE = 20

_STEPS = dict(desired_retention=0.9,
              learning_steps=(timedelta(minutes=1),),
              relearning_steps=(timedelta(minutes=10),),
              maximum_interval=60)
_sched = Scheduler(enable_fuzzing=True, **_STEPS)
_sched_preview = Scheduler(enable_fuzzing=False, **_STEPS)

RATINGS = {"again": Rating.Again, "hard": Rating.Hard, "good": Rating.Good}
LABELS = {"again": "Quên", "hard": "Mang máng", "good": "Nhớ chắc"}


def _cards() -> dict:
    return storage.db()["cards"]


def _load(wid: str) -> Card | None:
    d = _cards().get(wid)
    return Card.from_dict(d) if d else None


def _new_card(wid: str) -> Card:
    return Card(card_id=zlib.crc32(wid.encode()) + 1)


def _cap(card: Card, at: datetime) -> Card:
    if at < LAST_REVIEW_DAY and card.due > LAST_REVIEW_DAY.astimezone(timezone.utc):
        card.due = LAST_REVIEW_DAY.astimezone(timezone.utc)
    return card


def status(wid: str) -> str:
    """'new' chưa học · 'learning' đang học · 'known' đã thuộc"""
    c = _cards().get(wid)
    if not c:
        return "new"
    return "known" if c["state"] == State.Review.value else "learning"


def counts() -> dict:
    ws = data.words()
    known = learning = 0
    review = State.Review.value
    for wid, c in _cards().items():
        if wid in ws:
            if c["state"] == review:
                known += 1
            else:
                learning += 1
    return {"new": len(ws) - known - learning, "learning": learning, "known": known}


def due_ids(at: datetime | None = None) -> list[str]:
    """Thẻ đã học và đến hạn ôn (quá hạn lâu nhất đứng trước)."""
    at = (at or now()).astimezone(timezone.utc)
    ws = data.words()
    items = [(c["due"], wid) for wid, c in _cards().items()
             if wid in ws and datetime.fromisoformat(c["due"]) <= at]
    return [wid for _, wid in sorted(items)]


def new_ids_today() -> list[str]:
    """Từ mới đến lượt học (theo lịch tới hôm nay, cộng từ còn nợ + từ tự thêm) mà chưa học."""
    t = today().isoformat()
    cards = _cards()
    out = []
    for day in data.schedule():
        if day["date"] > t:
            break
        out += [w for w in day.get("new_words", []) if w not in cards]
    for wid in storage.db()["uploads"]["vocab"]:
        if wid not in cards:
            out.append(wid)
    seen, res = set(), []
    for w in out:
        if w not in seen:
            seen.add(w)
            res.append(w)
    return res


def build_round(limit: int = ROUND_SIZE) -> list[str]:
    """Một lượt ôn: thẻ đến hạn trước, rồi tới từ mới. Tối đa `limit` thẻ."""
    due = due_ids()
    rest = max(0, limit - len(due))
    return due[:limit] + new_ids_today()[:rest]


def review(wid: str, key: str) -> datetime:
    """Chấm 1 thẻ. key: again | hard | good. Trả về hạn ôn mới (giờ Việt Nam)."""
    at = now()
    card = _load(wid)
    is_new = card is None
    card = card or _new_card(wid)
    card, _ = _sched.review_card(card, RATINGS[key], review_datetime=at.astimezone(timezone.utc))
    card = _cap(card, at)
    _cards()[wid] = card.to_dict()
    log = storage.db()["card_log"].setdefault(today().isoformat(), {"new": 0, "reviews": 0})
    log["new" if is_new else "reviews"] += 1
    storage.touch(1)
    return card.due.astimezone(VN)


def preview(wid: str) -> dict:
    """Mỗi nút sẽ hẹn ôn lại sau bao lâu: {'again': '1 phút', 'hard': '6 phút', 'good': '2 ngày'}."""
    at = now()
    base = _load(wid) or _new_card(wid)
    out = {}
    for key, r in RATINGS.items():
        c, _ = _sched_preview.review_card(Card.from_dict(base.to_dict()), r,
                                          review_datetime=at.astimezone(timezone.utc))
        c = _cap(c, at)
        out[key] = human_delta(c.due - at.astimezone(timezone.utc))
    return out


def is_short(due: datetime) -> bool:
    """Hạn ôn trong vòng 15 phút → ôn lại ngay trong lượt này."""
    return due - now() <= timedelta(minutes=15)


def human_delta(d: timedelta) -> str:
    s = max(0, d.total_seconds())
    if s < 3600:
        return f"{max(1, round(s / 60))} phút"
    if s < 86400:
        return f"{round(s / 3600)} giờ"
    days = round(s / 86400)
    return f"{days} ngày"


def learned_on(day_iso: str) -> dict:
    return storage.db()["card_log"].get(day_iso, {"new": 0, "reviews": 0})


__all__ = ["status", "counts", "due_ids", "new_ids_today", "build_round", "review", "preview",
           "is_short", "LABELS", "ROUND_SIZE", "EXAM_DAY", "learned_on"]
