"""Đọc dữ liệu có sẵn (đề, từ, bài học, lịch) + dữ liệu người dùng tải lên.

Mọi hàm trả về dữ liệu CHỈ ĐỂ ĐỌC (được dùng chung, không được sửa trực tiếp).
"""
from __future__ import annotations

import json
from pathlib import Path

import streamlit as st

from . import storage

DATA = Path(__file__).resolve().parent.parent / "data"

PARTS = [
    ("vocab", "Từ vựng"),
    ("grammar", "Ngữ pháp"),
    ("transform", "Biến đổi câu"),
    ("cloze", "Điền từ vào đoạn"),
    ("reading", "Đọc hiểu"),
]
PART_LABEL = dict(PARTS)


@st.cache_resource
def _json(rel: str):
    return json.loads((DATA / rel).read_text(encoding="utf-8"))


# ---------- ĐỀ THI ----------
def builtin_index() -> list[dict]:
    return _json("exams/index.json")


def exam_list() -> list[dict]:
    """[{id, num, name, kind(practice|mock|upload), count, source(builtin|upload), complete}]"""
    out = [{**x, "source": "builtin", "complete": True} for x in builtin_index()]
    ups = storage.db()["uploads"]["exams"]
    for eid, ex in sorted(ups.items(), key=lambda kv: kv[1].get("added", "")):
        out.append({"id": eid, "num": None, "name": ex["name"], "kind": "upload",
                    "count": sum(not q.get("bonus") for q in ex["questions"]),
                    "source": "upload", "complete": bool(ex.get("complete"))})
    return out


def exam(eid: str) -> dict | None:
    if eid.startswith("de") and eid[2:].isdigit():
        return _json(f"exams/{eid}.json")
    return storage.db()["uploads"]["exams"].get(eid)


def exam_id(n: int) -> str:
    return f"de{int(n):02d}"


def exam_name(eid: str) -> str:
    ex = exam(eid)
    return ex["name"] if ex else eid


def question(eid: str, num) -> dict | None:
    ex = exam(eid)
    if not ex:
        return None
    for q in ex["questions"]:
        if str(q["num"]) == str(num):
            return q
    return None


def scored_questions(ex: dict) -> list[dict]:
    """Các câu tính điểm (bỏ câu thưởng 30a/30b)."""
    return [q for q in ex["questions"] if not q.get("bonus")]


# ---------- TỪ VỰNG ----------
def vocab_raw() -> dict:
    return _json("vocab.json")


@st.cache_resource
def _builtin_words() -> dict:
    return {w["id"]: w for w in vocab_raw()["words"]}


def words() -> dict:
    """id -> từ. Gồm 532 từ có sẵn + từ người dùng tự thêm (id bắt đầu 'u_')."""
    custom = storage.db()["uploads"]["vocab"]
    if not custom:
        return _builtin_words()
    return {**_builtin_words(), **custom}


def word_order() -> list[str]:
    """Thứ tự học từ có sẵn: theo đề rồi theo số thứ tự."""
    return [w["id"] for w in sorted(vocab_raw()["words"], key=lambda w: (w["de"], w["idx"]))]


# ---------- BÀI HỌC ----------
def lessons_list() -> list[dict]:
    """[{id, title, scope}] – b00..b15 (ngữ pháp) rồi d1..d3 (cách dịch)."""
    return _json("lessons/_list.json")


def lesson(lid: str) -> dict:
    return _json(f"lessons/{lid}.json")


# ---------- LỊCH ----------
@st.cache_data(show_spinner=False)
def formulas() -> dict:
    """Công thức riêng từng câu: {"de01#16": "..."}."""
    try:
        return _json("formulas.json")
    except Exception:  # noqa: BLE001
        return {}


def grammar() -> dict:
    """Thẻ "Ngữ pháp câu này": {mã: {title, body}}."""
    try:
        return _json("grammar.json")
    except Exception:  # noqa: BLE001
        return {}


def schedule() -> list[dict]:
    return _json("schedule.json")


@st.cache_resource
def translate_pool() -> list[dict]:
    """Câu tiếng Anh có đủ cụm dịch (không có chỗ trống) để luyện dịch hằng ngày.
    Mỗi mục: {eid, num, en, chunks[{en,vi,role}], vi}"""
    pool = []
    for x in builtin_index():
        ex = _json(f"exams/{x['id']}.json")
        for q in ex["questions"]:
            ch = q.get("chunks") or []
            if not 3 <= len(ch) <= 7:
                continue
            if any("___" in c["en"] or "___" in c["vi"] for c in ch):
                continue
            en = q.get("stem_en", "")
            if "___" in en or len(en.split()) < 5:
                continue
            pool.append({"eid": x["id"], "num": q["num"], "en": en, "chunks": ch,
                         "vi": q.get("vi_question") or q.get("vi_full", "")})
    return pool


# ---------- THÊM DỮ LIỆU CỦA NGƯỜI DÙNG ----------
def add_word(word: str, meaning: str, pos: str = "", ipa: str = "", example: str = "", example_vi: str = "",
             source: str = "Tự thêm") -> str:
    """Thêm 1 từ vào kho (thành thẻ mới, học ở lượt ôn kế tiếp). Trả về id 'u_...'."""
    import time as _t
    ups = storage.db()["uploads"]["vocab"]
    wid = f"u_{int(_t.time() * 1000)}_{len(ups)}"
    ups[wid] = {"id": wid, "de": 0, "idx": len(ups) + 1, "word": word.strip(), "ipa": ipa.strip(),
                "pos_raw": pos.strip(), "pos": pos.strip(), "meaning": meaning.strip(), "example": example.strip(),
                "example_vi": example_vi.strip(), "category": source, "family": [], "tip": "", "trap": "",
                "custom": True, "source": source}
    storage.touch()
    return wid


def add_exam(ex: dict) -> str:
    """Thêm 1 đề tải lên. ex theo đúng dạng đề có sẵn (xem DEV.md). Trả về id 'up_...'."""
    import time as _t
    from .clock import today as _today
    eid = ex.get("id") or f"up_{int(_t.time() * 1000)}"
    ex = {**ex, "id": eid, "kind": "upload", "source": "upload", "added": ex.get("added") or _today().isoformat()}
    ex.setdefault("complete", False)
    ex.setdefault("passages", {"cloze": {"title": "", "text": ""}, "reading": {"title": "", "text": ""}})
    ex.setdefault("passages_vi", {})
    ex.setdefault("note", "")
    storage.db()["uploads"]["exams"][eid] = ex
    storage.touch()
    return eid
