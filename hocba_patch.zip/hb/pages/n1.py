"""Ngăn 1 – Lịch học: tuần + việc từng ngày (home), Tiến độ (progress), Bảng điểm cả 19 đề (scores),
Cài đặt chung (settings)."""
from __future__ import annotations

import json
from datetime import date, timedelta

import streamlit as st

from .. import clock, data, plan, progress, srs, storage, ui

FIRST_MON = date(2026, 11, 2)           # tuần đầu (có 8/11)
LAST_MON = date(2026, 11, 30)           # tuần cuối (có ngày thi 1/12)
OD_SHOW = 8                             # số việc còn nợ hiện tối đa
N_WEEKS = (LAST_MON - FIRST_MON).days // 7 + 1

PART_TIP = {
    "vocab": "Phần **Từ vựng** đang yếu nhất. Mỗi ngày ôn thẻ từ cho hết lượt – như tập chuyền bóng, đều chân là lên tay.",
    "grammar": "Phần **Ngữ pháp** đang yếu nhất. Xem lại bài ngữ pháp, rồi làm lại các câu sai của phần này.",
    "transform": "Phần **Biến đổi câu** đang yếu nhất. Làm lại câu sai phần này và đọc kỹ mẹo ở từng câu.",
    "cloze": "Phần **Điền từ vào đoạn** đang yếu nhất. Đọc cả câu trước và câu sau chỗ trống rồi mới chọn.",
    "reading": "Phần **Đọc hiểu** đang yếu nhất. Đọc câu hỏi trước, rồi tìm chữ giống như vậy trong bài.",
}

_CSS = """
<style>
/* ---- dải tuần ---- */
.st-key-n1_weeknav [data-testid="stHorizontalBlock"], .st-key-n1_week [data-testid="stHorizontalBlock"],
.st-key-n1_foot [data-testid="stHorizontalBlock"] { flex-wrap: nowrap !important; }
.st-key-n1_weeknav [data-testid="stColumn"], .st-key-n1_foot [data-testid="stColumn"] { min-width: 0 !important; }
.st-key-n1_weeknav button { min-height: 44px; min-width: 44px; padding: 0 !important; }
.st-key-n1_weeknav button p { font-size: 24px !important; line-height: 1; }
.st-key-n1_weeknav button:disabled { opacity: .25; }
.n1-wk { text-align: center; line-height: 1.25; }
.n1-wk b { font-family: Lexend, sans-serif; font-size: 16px; color: var(--hb-ink); }
.n1-wk span { display: block; font-size: 12.5px; color: var(--hb-muted); }
.st-key-n1_week [data-testid="stHorizontalBlock"] { gap: 5px !important; }
.st-key-n1_week [data-testid="stColumn"] { min-width: 0 !important; flex: 1 1 0 !important; width: auto !important; position: relative; }
.st-key-n1_week [data-testid="stColumn"] [data-testid="stElementContainer"]:has(button) {
  position: absolute !important; inset: 0; z-index: 2; margin: 0 !important; width: 100% !important; height: 100% !important; }
.st-key-n1_week [data-testid="stColumn"] .stButton, .st-key-n1_week [data-testid="stColumn"] button {
  width: 100% !important; height: 100% !important; min-height: 0 !important; opacity: 0; }
.st-key-n1_week [data-testid="stMarkdownContainer"] { margin-bottom: 0 !important; }
.n1-day { border-radius: 14px; border: 1.5px solid var(--hb-line); background: var(--hb-card); color: var(--hb-ink);
  height: 66px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; }
.n1-day .wd { font-size: 12px; font-weight: 600; color: var(--hb-muted); }
.n1-day .dd { font-family: Lexend, sans-serif; font-size: 18px; font-weight: 700; line-height: 1.1; }
.n1-day .dot { width: 9px; height: 9px; border-radius: 50%; background: var(--hb-muted); opacity: .45; margin-top: 3px; }
.n1-day.all .dot, .n1-day.some .dot { opacity: 1; }
.n1-day.all .dot { background: var(--hb-green); } .n1-day.some .dot { background: var(--hb-orange); }
.n1-day.none { opacity: .45; background: var(--hb-soft); border-color: transparent; } .n1-day.none .dot { visibility: hidden; }
.n1-day.today { border: 2.5px solid var(--hb-orange); }
.n1-day.sel { background: var(--hb-green); border-color: var(--hb-green); opacity: 1; }
.n1-day.sel .wd, .n1-day.sel .dd { color: var(--hb-bg); }
.n1-day.sel .dot { box-shadow: 0 0 0 2px var(--hb-bg); }
.n1-day.sel.all .dot { background: var(--hb-bg); box-shadow: none; }
.n1-day.exam .dd, .n1-day.exam .wd { color: var(--hb-orange-dark); }
.n1-day.sel.exam .dd, .n1-day.sel.exam .wd { color: var(--hb-bg); }
.n1-day.sel.today { border-color: var(--hb-orange); }
.n1-legend { display: flex; flex-wrap: wrap; gap: 4px 12px; font-size: 12.5px; color: var(--hb-muted); margin: 6px 2px 4px; }
.n1-legend i { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 4px; background: var(--hb-muted); opacity: .45; }
.n1-legend i.g, .n1-legend i.o, .n1-legend i.t { opacity: 1; }
.n1-legend i.g { background: var(--hb-green); } .n1-legend i.o { background: var(--hb-orange); }
.n1-legend i.t { background: transparent; border: 2px solid var(--hb-orange); border-radius: 4px; }

/* ---- khung ngày ---- */
.n1-dhead { margin: 8px 0 8px; }
.n1-dhead .hb-h2 { margin: 0 0 2px; }
.n1-prog { display: flex; align-items: center; gap: 10px; margin-top: 8px; font-size: 14px; color: var(--hb-muted); }
.n1-prog .hb-bar { flex: 1; }
.n1-prog b { color: var(--hb-ink); }
[class*="st-key-n1_task_"] { gap: 6px !important; }
[class*="st-key-n1_task_"] [data-testid="stCheckbox"] p { font-size: 16px !important; font-weight: 600; line-height: 1.4; }
[class*="st-key-n1_task_d_"] [data-testid="stCheckbox"] p { text-decoration: line-through; color: var(--hb-muted) !important; font-weight: 500; }
[class*="st-key-n1_task_d_"] { opacity: .8; }
.n1-chips { display: flex; flex-wrap: wrap; gap: 6px; padding-left: 28px; }
[class*="st-key-n1_trow_"] { gap: 8px !important; flex-wrap: nowrap !important; }
[class*="st-key-n1_trow_"] > [data-testid="stElementContainer"]:first-child { flex: 1 1 auto !important; min-width: 0 !important; width: auto !important; }
[class*="st-key-n1_trow_"] > [data-testid="stElementContainer"]:not(:first-child) { flex: 0 0 auto !important; }
[class*="st-key-n1_trow_"] button { min-height: 44px !important; padding: 0 12px !important; }
[class*="st-key-n1_trow_"] button p { font-size: 15px !important; }

/* ---- mục tiêu tuần ---- */
.n1-goals { display: grid; grid-template-columns: 1fr; gap: 10px; }
.n1-goal .top { display: flex; justify-content: space-between; font-size: 14.5px; margin-bottom: 4px; color: var(--hb-ink); }
.n1-goal .top b { font-family: Lexend, sans-serif; }

/* ---- tiến độ ---- */
.n1-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 0;
  border-bottom: 1px solid var(--hb-line); color: var(--hb-ink); }
.n1-row:last-child { border-bottom: 0; }
.n1-row .nm { font-family: Lexend, sans-serif; font-weight: 600; font-size: 15.5px; min-width: 64px; }
.n1-row .sc { flex: 1; font-size: 16px; font-weight: 600; }
.n1-row .sc small { font-weight: 500; color: var(--hb-muted); font-size: 14px; }
.n1-row .up { color: var(--hb-ok); font-weight: 700; } .n1-row .down { color: var(--hb-bad); font-weight: 700; }
.n1-row .go { color: var(--hb-muted); font-size: 18px; }
.n1-part { margin: 0 0 10px; }
.n1-part .top { display: flex; justify-content: space-between; font-size: 14.5px; margin-bottom: 4px; color: var(--hb-ink); }
.n1-part .top span { color: var(--hb-muted); }
.n1-big { font-family: Lexend, sans-serif; font-size: 26px; font-weight: 700; color: var(--hb-green); line-height: 1.1; }
.n1-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
.n1-stat { background: var(--hb-soft); border-radius: 14px; padding: 10px 8px; text-align: center; color: var(--hb-ink); }
.n1-stat .v { font-family: Lexend, sans-serif; font-size: 22px; font-weight: 700; }
.n1-stat .l { font-size: 13px; color: var(--hb-muted); }
.n1-stat.g .v { color: var(--hb-green); } .n1-stat.o .v { color: var(--hb-orange-dark); }
.n1-stack { display: flex; height: 12px; border-radius: 99px; overflow: hidden; background: var(--hb-soft); margin: 4px 0 10px; }
.n1-stack span { display: block; height: 100%; }
.n1-stack .k { background: var(--hb-green); } .n1-stack .l { background: var(--hb-orange); }
.n1-dhd { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; margin-bottom: 5px; text-align: center;
  font-size: 12px; font-weight: 600; color: var(--hb-muted); }
.hb-days div.blank { visibility: hidden; }
.hb-days { max-width: 420px; }
.n1-dhd { max-width: 420px; }
.n1-sec { font-family: Lexend, sans-serif; font-weight: 700; font-size: 17px; color: var(--hb-ink); margin: 0 0 8px; }
.n1-line { font-size: 15px; color: var(--hb-ink); margin: 4px 0; }

/* ---- hàng bấm được (bảng điểm) ---- */
[class*="st-key-n1_tap_"] { position: relative; gap: 0 !important; }
[class*="st-key-n1_tap_"] [data-testid="stElementContainer"]:has(button) { position: absolute !important; inset: 0; z-index: 2; margin: 0 !important; width: 100% !important; height: 100% !important; }
[class*="st-key-n1_tap_"] .stButton, [class*="st-key-n1_tap_"] button { width: 100% !important; height: 100% !important; opacity: 0; }
[class*="st-key-n1_tap_"] .n1-row { padding: 12px 2px; border-bottom: 0; }
.st-key-n1_scorelist { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 18px; padding: 2px 14px; gap: 0 !important; }
[class*="st-key-n1_tap_"] .n1-row.sep { border-bottom: 1px solid var(--hb-line); }
.n1-row .nm { min-width: 82px; }
.st-key-n1_pex, [class*="st-key-n1_set_"], [class*="st-key-n1_task_o_"] { background: var(--hb-card); border-radius: 16px; }
[class*="st-key-n1_task_o_od_"] { background: var(--hb-soft); }

/* ---- hộp thoại dời việc ---- */
.stDialog section[role="dialog"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; }
.stDialog section[role="dialog"] p, .stDialog section[role="dialog"] label, .stDialog section[role="dialog"] h2,
.stDialog section[role="dialog"] [data-testid="stMarkdownContainer"] { color: var(--hb-ink) !important; }
.stDialog section[role="dialog"] button[aria-label="Close"] { color: var(--hb-ink) !important; }
.stDialog section[role="dialog"] button[kind="primary"] p { color: inherit !important; }
.stDialog section[role="dialog"] h2 { font-family: Lexend, sans-serif; font-size: 20px !important; }
.stDialog button[kind="primary"], .stDialog button[kind="secondary"] { min-height: 46px; border-radius: 14px; }
.stDialog button p { font-size: 15.5px !important; font-weight: 600; }
.stDialog button[kind="secondary"] { background: var(--hb-card) !important; border: 1.5px solid var(--hb-line) !important; }
.stDialog button[kind="tertiary"] p { color: var(--hb-green) !important; }
.stDialog [data-testid="stRadio"] label { padding: 7px 0; }
.stDialog [data-testid="stRadio"] p { font-size: 16px !important; }
.stDialog .hb-muted { font-size: 15px; }

.st-key-n1_theme button[data-variant] { background: var(--hb-card) !important; color: var(--hb-ink) !important;
  border-color: var(--hb-line) !important; min-height: 44px; }
.st-key-n1_theme button[data-variant][aria-checked="true"] { background: var(--hb-green-soft) !important;
  color: var(--hb-green-ink) !important; border-color: var(--hb-green) !important; }
.st-key-n1_theme button[data-variant] p { color: inherit !important; font-size: 15px !important; font-weight: 600; }

@media (min-width: 900px) { .n1-goals { grid-template-columns: 1fr 1fr; } }
</style>
"""


# ======================= TIỆN ÍCH =======================
def fm(m: int) -> str:
    """Số phút → '4 tiếng 30', '45 phút', '1 tiếng'."""
    m = max(0, int(m))
    h, r = divmod(m, 60)
    if not h:
        return f"{r} phút"
    return f"{h} tiếng" + (f" {r}" if r else "")


def short(d: date | str) -> str:
    if isinstance(d, str):
        d = date.fromisoformat(d)
    return f"{clock.WD_SHORT[d.weekday()]} {d.day}/{d.month}"


def _clamp_day(d: date) -> date:
    return max(FIRST_MON, min(clock.EXAM_DAY, d))


def _default_day() -> date:
    t = clock.today()
    if t < clock.START_DAY:
        return clock.START_DAY
    return min(t, clock.EXAM_DAY)


def _sel() -> date:
    s = st.session_state.get("n1_sel")
    if not s:
        s = _default_day().isoformat()
        st.session_state["n1_sel"] = s
    return date.fromisoformat(s)


def _pick(iso: str):
    st.session_state["n1_sel"] = iso


def _shift_week(n: int):
    sel = _sel()
    mon = sel - timedelta(days=sel.weekday()) + timedelta(days=7 * n)
    mon = max(FIRST_MON, min(LAST_MON, mon))
    wk = [mon + timedelta(days=i) for i in range(7)]
    t = clock.today()
    if t in wk:
        pick = t
    else:
        has = [d for d in wk if plan.day_info(d)]
        pick = has[0] if has else mon
    st.session_state["n1_sel"] = pick.isoformat()


def _day_state(d: date) -> str:
    tasks = plan.tasks_for(d)
    if not tasks:
        return "none"
    n = sum(t["done"] for t in tasks)
    return "all" if n == len(tasks) else ("some" if n else "zero")


def _new_words_line(d: date) -> str:
    info = plan.day_info(d) or {}
    ids = info.get("new_words") or []
    if not ids:
        return ""
    ws = data.words()
    des = sorted({ws[w]["de"] for w in ids if w in ws and ws[w].get("de")})
    src = f" (Đề {', '.join(str(x) for x in des)})" if des else ""
    return f"Từ mới: <b>{len(ids)} từ</b>{src}"


def _set_db(key: str, wkey: str):
    v = st.session_state.get(wkey)
    if v is None:
        return
    storage.db()["settings"][key] = v
    storage.touch()


# ======================= TRANG CHÍNH =======================
def render(view: str, params: dict):
    ui.html(_CSS)
    if view == "progress":
        _progress()
    elif view == "scores":
        _scores()
    elif view == "settings":
        _settings()
    else:
        _home()


# ---------------------------------------------------------------- HOME
def _home():
    t = clock.today()
    _banner(t)
    sel = _sel()
    _week_strip(sel, t)
    left, right = st.columns([3, 2], gap="medium")
    with left:
        _day_panel(sel, t)
        if sel == t and clock.START_DAY < t < clock.EXAM_DAY:
            _overdue()
    with right:
        if t >= clock.START_DAY:
            ui.html(ui.key_box())
        _goals(sel)
        with st.container(key="n1_foot"):
            c1, c2 = st.columns(2, wrap=False)
            if c1.button("Xem tiến độ", key="n1_to_prog", icon=":material/trending_up:", width="stretch"):
                ui.go("n1", "progress")
            if c2.button("Cài đặt", key="n1_to_set", icon=":material/settings:", width="stretch"):
                ui.go("n1", "settings")


def _banner(t: date):
    if t < clock.START_DAY:
        ui.html(ui.box("orange", "SẮP BẮT ĐẦU", ui.md(
            "Lịch học bắt đầu **Chủ nhật, 8/11**.\n"
            "Mọi tiến độ cũ đã được xóa, mai bạn bắt đầu từ Đề 1. Việc đầu tiên của ngày 8/11 là đọc **6 bước làm 1 câu** (ở bên dưới).")))
    elif t == clock.EXAM_DAY:
        ui.html(ui.box("green", "HÔM NAY THI!", ui.md(
            "Bạn đã tập đủ rồi, giờ chỉ cần bình tĩnh.\n"
            "• Thi **buổi chiều**. Sáng chỉ nhắc lại tối đa 30 phút + đọc ghi chú câu hay sai, không học bài mới.\n"
            "• Ăn trưa no, nghỉ 20–30 phút, mang giấy tờ, bút, đến sớm.\n"
            "• Vào phòng thi: làm câu dễ trước, câu khó để sau. **Không bỏ trống câu nào.**\n"
            "Như đá phạt đền: hít thở sâu, nhìn kỹ rồi mới sút.")))
        if st.button("Mở bảng câu sai", key="n1_exam_wrong", icon=":material/play_arrow:"):
            ui.go("n3", "wrong")
    elif t > clock.EXAM_DAY:
        ui.html(ui.box("green", "CHÚC MỪNG BẠN!", ui.md(
            "Bạn đã đi hết chặng đường ôn thi. Ngày nào cũng cố gắng – đó là điều **đáng tự hào nhất**.\n"
            "Lịch cũ và tiến độ vẫn còn ở dưới để bạn xem lại.")))


def _week_strip(sel: date, t: date):
    mon = sel - timedelta(days=sel.weekday())
    wk = plan.week_of(sel)
    idx = (mon - FIRST_MON).days // 7 + 1
    with st.container(key="n1_weeknav"):
        a, b, c = st.columns([1, 5, 1], wrap=False, vertical_alignment="center")
        a.button("‹", key="n1_wprev", on_click=_shift_week, args=(-1,), disabled=mon <= FIRST_MON, type="tertiary")
        with b:
            ui.html(f'<div class="n1-wk"><b>Tuần {mon.day}/{mon.month} – {wk[-1].day}/{wk[-1].month}</b>'
                    f'<span>Tuần {idx} / {N_WEEKS}</span></div>')
        c.button("›", key="n1_wnext", on_click=_shift_week, args=(1,), disabled=mon >= LAST_MON, type="tertiary")
    with st.container(key="n1_week"):
        cols = st.columns(7, wrap=False, gap=None)
        for col, d in zip(cols, wk):
            stt = _day_state(d)
            cls = ["n1-day", stt]
            if d == t:
                cls.append("today")
            if d == sel:
                cls.append("sel")
            wd = clock.WD_SHORT[d.weekday()]
            if d == clock.EXAM_DAY:
                cls.append("exam")
                wd = "THI"
            with col:
                ui.html(f'<div class="{" ".join(cls)}"><span class="wd">{wd}</span>'
                        f'<span class="dd">{d.day}</span><i class="dot"></i></div>')
                st.button(clock.label(d), key=f"n1_day_{d.isoformat()}", on_click=_pick, args=(d.isoformat(),),
                          disabled=d < FIRST_MON or d > clock.EXAM_DAY)
    ui.html('<div class="n1-legend"><span><i class="g"></i>xong hết</span><span><i class="o"></i>xong một phần</span>'
            '<span><i></i>chưa làm</span><span><i class="t"></i>hôm nay</span></div>')


def _day_panel(d: date, t: date):
    info = plan.day_info(d)
    tasks = plan.tasks_for(d)
    head = clock.label(d) + (f" · {info['slot']}" if info and info.get("slot") else "")
    if d == t:
        head = "Hôm nay · " + head
    sub = ""
    if d == clock.EXAM_DAY:
        sub = "Ngày thi. Chỉ ôn nhẹ, giữ sức."
    elif info:
        bud, used = plan.budget(d), plan.planned_minutes(d)
        sub = f"Rảnh {fm(bud)} · đã xếp {fm(used)}"
        if used > bud:
            sub += " · hơi nhiều, có thể dời bớt"
    nw = _new_words_line(d)
    prog = ""
    if tasks:
        n = sum(x["done"] for x in tasks)
        prog = (f'<div class="n1-prog">{ui.bar(n / len(tasks), "green" if n == len(tasks) else "orange")}'
                f'<span><b>{n}/{len(tasks)}</b> việc xong</span></div>')
    ui.html(f'<div class="n1-dhead"><div class="hb-h2">{ui.esc(head)}</div>'
            f'<div class="hb-muted">{ui.esc(sub)}</div>'
            + (f'<div class="n1-line">{nw}</div>' if nw else "") + prog + "</div>")
    if not tasks:
        if d < clock.START_DAY:
            msg = "Ngày này chưa có lịch. Lịch học bắt đầu **Chủ nhật, 8/11**."
        else:
            msg = "Ngày này không có việc nào. Nghỉ ngơi, đá bóng cho khỏe!"
        ui.html(ui.box("gray", "TRỐNG", ui.md(msg)))
        return
    if all(x["done"] for x in tasks):
        ui.html(ui.box("green", "XONG HẾT RỒI", ui.md("Giỏi lắm! Xong hết việc của ngày này. Muốn học lại việc nào, bấm “Học lại” ở việc đó.")))
    for tk in tasks:
        _task_row(tk, "day", t)


def _toggle(tid: str, ck: str):
    plan.set_done(tid, bool(st.session_state.get(ck)))


def _task_row(tk: dict, kp: str, t: date, extra_chip: str = ""):
    sid = tk["id"].replace("#", "_")
    done = tk["done"]
    ck = f"n1_ck_{kp}_{sid}"
    st.session_state[ck] = done
    with st.container(border=True, key=f"n1_task_{'d' if done else 'o'}_{kp}_{sid}"):
        st.checkbox(tk["title"], key=ck, on_change=_toggle, args=(tk["id"], ck))
        chips = [f'<span class="hb-chip gray">{fm(tk["minutes"])}</span>']
        if extra_chip:
            chips.append(f'<span class="hb-chip red">{ui.esc(extra_chip)}</span>')
        if tk.get("moved") or plan.task_date(tk["id"]) != tk["orig"]:
            chips.append(f'<span class="hb-chip orange">dời từ {short(tk["orig"])}</span>')
        chip_html = f'<div class="n1-chips">{"".join(chips)}</div>'
        if tk.get("guide"):
            ui.html(ui.box("blue", "6 BƯỚC LÀM 1 CÂU", ui.md(ui.STEPS6)))
        if done:
            with st.container(horizontal=True, vertical_alignment="center", key=f"n1_trow_{kp}_{sid}"):
                ui.html(chip_html)
                if tk["type"] != "self" and st.button("Học lại", key=f"n1_re_{kp}_{sid}", icon=":material/replay:"):
                    tab_, view_, prm = plan.start_target(tk, redo=True)
                    ui.go(tab_, view_, **prm)
            return
        with st.container(horizontal=True, vertical_alignment="center", key=f"n1_trow_{kp}_{sid}"):
            ui.html(chip_html)
            if tk["type"] != "self" and st.button("Bắt đầu", key=f"n1_go_{kp}_{sid}", type="primary", icon=":material/play_arrow:"):
                tab_, view_, prm = plan.start_target(tk)
                ui.go(tab_, view_, **prm)
            can_move = plan.can_move(tk["id"])
            if can_move and st.button("Dời", key=f"n1_mv_{kp}_{sid}"):
                _move_dialog(tk["id"])


@st.dialog("Dời việc sang ngày nào?")
def _move_dialog(tid: str):
    tk = plan.task(tid)
    if not tk:
        st.write("Không tìm thấy việc này.")
        return
    need = tk["minutes"]
    sid = tid.replace("#", "_")
    ui.html(f'<div class="hb-muted" style="margin-bottom:6px">{ui.esc(tk["title"])} · {fm(need)}</div>')
    ch = plan.move_choices(tid)
    if not ch:
        st.write("Không còn ngày nào để dời.")
        return
    sug = plan.suggest_day(tid)
    free = {d.isoformat(): f for d, f in ch}
    order = [d.isoformat() for d, _ in ch]
    if sug and sug.isoformat() in free:
        order.remove(sug.isoformat())
        order.insert(0, sug.isoformat())
    more_key = f"n1_mvmore_{sid}"
    show = order if st.session_state.get(more_key) else order[:7]

    def fmt(iso: str) -> str:
        f = free[iso]
        if f >= need:
            s = f"{short(iso)} · rảnh {fm(f)}"
        elif f > 0:
            s = f"{short(iso)} · hơi đầy (rảnh {fm(f)})"
        else:
            s = f"{short(iso)} · hơi đầy"
        if sug and iso == sug.isoformat():
            s = f"**Gợi ý:** {s}"
        return s

    pick = st.radio("Chọn ngày", show, format_func=fmt, key=f"n1_mvpick_{sid}", label_visibility="collapsed")
    if len(order) > 7 and not st.session_state.get(more_key):
        st.button("Xem thêm ngày", key=f"n1_mvmorebtn_{sid}", type="tertiary",
                  on_click=st.session_state.__setitem__, args=(more_key, True))
    if pick and free[pick] < need:
        ui.html(ui.box("orange", "HƠI ĐẦY", ui.md("Ngày này gần kín giờ rồi. Vẫn dời được, nhưng hôm đó sẽ học lâu hơn.")))
    if st.button("Dời sang ngày này", key=f"n1_mvok_{sid}", type="primary", width="stretch", disabled=not pick):
        plan.move(tid, date.fromisoformat(pick))
        ui.rerun()
    if st.button("Thôi, không dời", key=f"n1_mvno_{sid}", width="stretch"):
        ui.rerun()


def _overdue():
    od = plan.overdue()
    if not od:
        return
    with st.expander(f"Việc còn nợ ({len(od)})", icon=":material/history:"):
        ui.html('<div class="hb-muted">Việc của mấy ngày trước chưa xong. Làm luôn, dời sang ngày khác, '
                'hoặc tick nếu đã làm rồi.</div>')
        t = clock.today()
        od = sorted(od, key=lambda x: (x["date"], x["id"]), reverse=True)
        for tk in od[:OD_SHOW]:
            tk = {**tk, "moved": False}
            _task_row(tk, "od", t, extra_chip=f"của {short(tk['date'])}")
        if len(od) > OD_SHOW:
            ui.html(f'<div class="hb-muted">Còn {len(od) - OD_SHOW} việc cũ hơn. Không kịp thì bỏ qua cũng được – '
                    f'tập trung làm tốt việc hôm nay trước.</div>')


def _goals(d: date):
    g = plan.week_goals(d)
    rows = [("Việc trong lịch", g["tasks"]), ("Từ mới", g["words"]),
            ("Lượt làm đề", g["exams"]), ("Bài học", g["lessons"])]
    items = []
    for name, (a, b) in rows:
        frac = a / b if b else 0
        val = f"{a}/{b}" if b else "–"
        items.append(f'<div class="n1-goal"><div class="top"><span>{name}</span><b>{val}</b></div>'
                     f'{ui.bar(frac, "green" if b and a >= b else "orange")}</div>')
    ui.html(f'<div class="hb-card" style="margin-top:8px"><div class="n1-sec">Mục tiêu tuần này</div>'
            f'<div class="n1-goals">{"".join(items)}</div></div>')


# ---------------------------------------------------------------- PROGRESS
def _rounds_text(s: dict) -> str:
    fin = [c for c, _a, _t, f in s["rounds"] if f]
    out = ""
    if len(fin) == 1:
        out = f"Lần đầu <b>{fin[0]}</b>"
    elif fin:
        out = " → ".join(str(x) for x in fin)
        g = s["gain"] or 0
        if g > 0:
            out += f' <span class="up">▲{g}</span>'
        elif g < 0:
            out += f' <span class="down">▼{-g}</span>'
    if s["in_progress"]:
        a, tot = s["in_progress"]
        ip = f"<small>đang làm {a}/{tot}</small>"
        out = f"{out} · {ip}" if out else ip
    return out or "<small>chưa làm</small>"


def _ms_chip(s: dict) -> str:
    m = progress.milestone(s["best"])
    return f'<span class="hb-chip green">✓ mốc {m}</span>' if m else ""


def _exam_row(eid: str, name: str, arrow: bool = False, sep: bool = False) -> str:
    s = progress.exam_summary(eid)
    go = '<span class="go">›</span>' if arrow else ""
    return (f'<div class="n1-row{" sep" if sep else ""}"><span class="nm">{ui.esc(name)}</span><span class="sc">{_rounds_text(s)}</span>'
            f'{_ms_chip(s)}{go}</div>')


def _progress():
    ui.back("Lịch học", "n1", "home", key="n1_prog")
    ui.title("Tiến độ của mình", "Nhìn lại mình đã đi được bao xa.")
    left, right = st.columns(2, gap="medium")
    with left:
        _prog_exams()
        _prog_parts()
    with right:
        _prog_days()
        _prog_counts()


def _prog_exams():
    rec = progress.recent_exams(5)
    with st.container(border=True, key="n1_pex"):
        ui.html('<div class="n1-sec">Điểm các đề</div>')
        # mốc tiếp theo
        lasts = [(s["last"], eid) for eid in progress._db()["attempts"]
                 if data.exam(eid) and (s := progress.exam_summary(eid))["last"] is not None]
        if lasts:
            cur, eid = max(lasts)
            nxt = progress.next_milestone(cur)
            if nxt:
                body = (f"Bạn đang ở **{cur} câu** đúng ({data.exam_name(eid)}, lần gần nhất).\n"
                        f"Còn **{nxt - cur} câu** nữa là chạm mốc **{nxt}**.")
            else:
                body = f"Bạn đang ở **{cur} câu** đúng – đã vượt mốc 42! Giữ vững phong độ nhé."
            weak = _weakest_part()
            if weak:
                body += "\n" + PART_TIP[weak]
            ui.html(ui.box("green", "MỐC TIẾP THEO", ui.md(body)))
            if weak and progress.wrong_list(weak):
                if st.button(f"Làm lại câu sai: {data.PART_LABEL[weak]}", key="n1_weak_go",
                             icon=":material/play_arrow:", width="stretch"):
                    ui.go("n3", "wrong_quiz", part=weak)
        elif rec:
            ui.html(ui.box("blue", "MỐC TIẾP THEO", ui.md(
                "Bạn đang làm dở đề. Làm hết **50 câu** của một đề để biết mình đang ở mốc nào nhé.")))
        else:
            ui.html(ui.box("blue", "BẮT ĐẦU THÔI", ui.md(
                "Bạn chưa làm đề nào. Mở **Đề 1** và làm thử – sai cũng không sao, app sẽ giảng từng câu.\n"
                "Các mốc cần chạm: **30 → 35 → 42** câu đúng trên 50.")))
            if st.button("Mở Đề 1", key="n1_open_de01", icon=":material/play_arrow:", width="stretch"):
                ui.go("n3", "exam", eid="de01")
        if rec:
            rows = "".join(_exam_row(eid, data.exam_name(eid)) for eid in rec)
            ui.html(f'<div class="hb-muted" style="margin-top:6px">5 đề làm gần nhất. Số = câu đúng trên 50, '
                    f'mũi tên: lần đầu → lần làm lại.</div><div>{rows}</div>')
        n = len(data.exam_list())
        if st.button(f"Xem cả {n} đề", key="n1_all_scores", width="stretch"):
            ui.go("n1", "scores")


def _weakest_part() -> str | None:
    ps = {p: v for p, v in progress.part_stats().items() if v[1]}
    if not ps:
        return None
    return min(ps, key=lambda p: ps[p][0] / ps[p][1])


def _prog_parts():
    ps = progress.part_stats()
    rows = []
    tried = {p: v for p, v in ps.items() if v[1]}
    for p, lab in data.PARTS:
        c, a = ps.get(p, (0, 0))
        if not a:
            rows.append(f'<div class="n1-part"><div class="top"><b>{lab}</b><span>chưa làm</span></div>'
                        f'{ui.bar(0)}</div>')
            continue
        pct = round(c * 100 / a)
        color = "green" if pct >= 70 else ("orange" if pct >= 50 else "red")
        rows.append(f'<div class="n1-part"><div class="top"><b>{lab}</b><span>đúng {c}/{a} · {pct}%</span></div>'
                    f'{ui.bar(c / a, color)}</div>')
    note = ""
    if len(tried) >= 2:
        best = max(tried, key=lambda p: tried[p][0] / tried[p][1])
        worst = min(tried, key=lambda p: tried[p][0] / tried[p][1])
        note = (f'<div class="n1-line">Mạnh nhất: <b>{data.PART_LABEL[best]}</b> · '
                f'Cần luyện: <b class="hb-bad">{data.PART_LABEL[worst]}</b></div>')
    elif not tried:
        note = '<div class="hb-muted">Làm đề xong sẽ thấy phần nào mạnh, phần nào yếu.</div>'
    ui.html(f'<div class="hb-card"><div class="n1-sec">Mạnh, yếu từng phần</div>'
            f'<div class="hb-muted" style="margin-bottom:8px">Tỉ lệ câu đúng của mỗi phần, tính trên mọi lần làm đề.</div>'
            f'{"".join(rows)}{note}</div>')


def _prog_days():
    act = storage.db()["activity"]
    t = clock.today()
    d0, d1 = clock.START_DAY, clock.EXAM_DAY
    total = (d1 - d0).days + 1
    cells = ['<div class="blank"></div>'] * d0.weekday()
    learned = 0
    d = d0
    while d <= d1:
        cls = []
        if act.get(d.isoformat()):
            cls.append("on")
            learned += 1
        if d == d1:
            cls.append("exam")
        if d == t:
            cls.append("today")
        cells.append(f'<div class="{" ".join(cls)}" title="{clock.label(d)}">{d.day}</div>')
        d += timedelta(days=1)
    head = "".join(f"<span>{w}</span>" for w in clock.WD_SHORT)
    s = progress.streak()
    ui.html(f'<div class="hb-card"><div class="n1-sec">Những ngày đã học</div>'
            f'<div class="n1-dhd">{head}</div><div class="hb-days">{"".join(cells)}</div>'
            f'<div class="n1-line" style="margin-top:8px">Đã học <b>{learned}/{total}</b> ngày · '
            f'Chuỗi <b>{s}</b> ngày</div>'
            f'<div class="hb-muted">Ô xanh = ngày có học. Ô cam = ngày thi 1/12.</div></div>')


def _prog_counts():
    c = srs.counts()
    tot = sum(c.values()) or 1
    k, l, n = c["known"], c["learning"], c["new"]
    stack = (f'<div class="n1-stack"><span class="k" style="width:{k * 100 / tot:.1f}%"></span>'
             f'<span class="l" style="width:{l * 100 / tot:.1f}%"></span></div>')
    ui.html(f'<div class="hb-card"><div class="n1-sec">Từ vựng</div>'
            f'<div><span class="n1-big">{k}</span> <span class="hb-muted">/ {tot} từ đã thuộc</span></div>{stack}'
            f'<div class="n1-stats"><div class="n1-stat g"><div class="v">{k}</div><div class="l">Đã thuộc</div></div>'
            f'<div class="n1-stat o"><div class="v">{l}</div><div class="l">Đang học</div></div>'
            f'<div class="n1-stat"><div class="v">{n}</div><div class="l">Chưa học</div></div></div>'
            f'<div class="hb-muted" style="margin-top:8px">"Đã thuộc" là từ bạn nhớ đúng nhiều lần, cách nhau vài ngày.</div>'
            f'</div>')
    lessons = data.lessons_list()
    ldone = sum(1 for x in lessons if progress.lesson_state(x["id"]).get("first"))
    wrong = len(progress.wrong_list())
    cleared = storage.db().get("wrong_cleared", 0)
    ui.html(f'<div class="hb-card"><div class="n1-sec">Bài học và câu sai</div>'
            f'<div class="n1-stats"><div class="n1-stat g"><div class="v">{ldone}/{len(lessons)}</div>'
            f'<div class="l">Bài đã học</div></div>'
            f'<div class="n1-stat o"><div class="v">{wrong}</div><div class="l">Câu sai cần ôn</div></div>'
            f'<div class="n1-stat g"><div class="v">{cleared}</div><div class="l">Câu sai đã sửa xong</div></div></div>'
            f'<div class="hb-muted" style="margin-top:8px">Câu sai làm đúng 3 ngày khác nhau sẽ được "tốt nghiệp" '
            f'và rời khỏi bảng.</div></div>')


# ---------------------------------------------------------------- SCORES
def _scores():
    ui.back("Tiến độ", "n1", "progress", key="n1_scores")
    ui.title("Điểm cả các đề", "Số = câu đúng trên 50. Bấm vào một đề để mở đề đó.")
    with st.container(key="n1_scorelist"):
        exs = data.exam_list()
        for i, x in enumerate(exs):
            with st.container(key=f"n1_tap_{x['id']}"):
                ui.html(_exam_row(x["id"], x["name"], arrow=True, sep=i < len(exs) - 1))
                if st.button(f"Mở {x['name']}", key=f"n1_sc_{x['id']}"):
                    ui.go("n3", "exam", eid=x["id"])


# ---------------------------------------------------------------- SETTINGS
def _settings():
    ui.back("Lịch học", "n1", "home", key="n1_set")
    ui.title("Cài đặt chung")
    s = storage.db()["settings"]
    with st.container(border=True, key="n1_set_look"):
        ui.html('<div class="n1-sec">Giao diện</div>')
        st.session_state["n1_theme"] = s.get("theme", "auto")
        st.segmented_control("Màu nền", ["auto", "light", "dark"], key="n1_theme", required=True,
                             format_func={"auto": "Tự động", "light": "Luôn sáng", "dark": "Luôn tối"}.get,
                             on_change=_set_db, args=("theme", "n1_theme"), label_visibility="collapsed",
                             width="stretch")
        ui.html('<div class="hb-muted">Tự động: nền sáng ban ngày, nền tối từ 19 giờ (đỡ chói mắt).</div>')
    with st.container(border=True, key="n1_set_sound"):
        ui.html('<div class="n1-sec">Âm thanh</div>')
        st.session_state["n1_sound"] = bool(s.get("sound", True))
        st.toggle("Âm thanh khi chọn đáp án", key="n1_sound", on_change=_set_db, args=("sound", "n1_sound"))
        st.session_state["n1_speak"] = bool(s.get("speak_wrong", True))
        st.toggle("Đọc to câu đúng khi làm sai", key="n1_speak", on_change=_set_db, args=("speak_wrong", "n1_speak"))
    with st.container(border=True, key="n1_set_store"):
        ui.html('<div class="n1-sec">Nơi lưu tiến độ</div>')
        be = storage.backend_name()
        if be == "máy này":
            ui.html(ui.box("orange", "ĐANG LƯU TRÊN MÁY NÀY", ui.md(
                "Chưa nối GitHub nên tiến độ có thể mất khi app khởi động lại. "
                "Xem **hướng dẫn bước 4** để nối GitHub. Trong lúc chờ, nhớ bấm **Tải file sao lưu** thường xuyên.")))
        else:
            ui.html(ui.box("green", f"ĐANG LƯU TRÊN {be.upper()}", ui.md(
                "Tiến độ tự lưu. Học trên điện thoại hay máy tính đều thấy cùng một tiến độ.")))
        ui.html('<div class="hb-muted" style="margin:4px 0 6px">Sao lưu: tải tiến độ về máy thành 1 file. '
                'Khôi phục: chọn lại file đó để lấy tiến độ về.</div>')
        st.download_button("Tải file sao lưu", data=storage.export_json(),
                           file_name=f"hocba_saoluu_{clock.today().isoformat()}.json", mime="application/json",
                           key="n1_backup", icon=":material/download:", on_click="ignore", width="stretch")
        if st.session_state.pop("n1_restored", False):
            st.success("Đã khôi phục tiến độ từ file.", icon=":material/check_circle:")
        n = st.session_state.get("n1_up_n", 0)
        f = st.file_uploader("Khôi phục từ file sao lưu (.json)", type=["json"], key=f"n1_restore_{n}")
        if f is not None:
            ui.html(ui.box("orange", "CHÚ Ý", ui.md(
                f"Tiến độ hiện tại sẽ được **thay bằng** file **{f.name}**. Chắc chưa?")))
            if st.button("Khôi phục từ file này", key="n1_restore_ok", type="primary", width="stretch"):
                try:
                    text = f.getvalue().decode("utf-8")
                    obj = json.loads(text)
                    if not isinstance(obj, dict) or not ({"tasks_done", "cards", "attempts"} & set(obj)):
                        raise ValueError
                except Exception:  # noqa: BLE001
                    st.error("File này không phải file sao lưu của Học Bá.", icon=":material/error:")
                else:
                    storage.import_json(text)
                    st.session_state["n1_up_n"] = n + 1
                    st.session_state["n1_restored"] = True
                    ui.rerun()
    ui.html('<div class="hb-muted" style="margin-top:6px">Đồng hồ học: bấm nút ⏱ góc trên bên phải.</div>')
