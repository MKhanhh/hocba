"""Ngăn 3 – Đề thi: danh sách đề, trang 1 đề, làm đề chấm ngay, bảng câu sai, cài đặt đề."""
from __future__ import annotations

import re

import streamlit as st

from .. import clock, data, plan, progress, storage, ui

RANGES = [("1-50", "Cả đề"), ("1-25", "Câu 1–25"), ("26-50", "Câu 26–50")]
RANGE_LABEL = dict(RANGES)
LETTERS = "ABCD"
LEVEL_KEYS = ["short", "easy", "super"]
LEVEL_HINT = ["Một hai câu, đi thẳng vào ý chính.", "Giảng từng bước bằng lời thường.",
              "Ví dụ đời thường, bóng đá, như kể cho em nhỏ."]
WAIT = "Chờ Claude bổ sung"

_CSS = """
<style>
.n3-row { display:flex; align-items:center; gap:10px; background:var(--hb-card); border:1px solid var(--hb-line);
  border-radius:16px; padding:10px 12px 10px 14px; min-height:58px; color:var(--hb-ink); }
.n3-row .l { flex:1; min-width:0; }
.n3-row .nm { font-family:Lexend,sans-serif; font-weight:600; font-size:16px; line-height:1.3; }
.n3-row .st { color:var(--hb-muted); font-size:13.5px; line-height:1.4; margin-top:1px; }
.n3-row .st b { color:var(--hb-ink); font-weight:600; }
.n3-row .r { display:flex; gap:4px; flex-wrap:wrap; justify-content:flex-end; max-width:48%; }
.n3-row .go { color:var(--hb-muted); font-size:22px; line-height:1; padding-left:2px; }
.n3-row.card-green { background:var(--hb-green-soft); border-color:transparent; }
.n3-row.card-green .nm { color:var(--hb-green-ink); }
.n3-row .big { font-family:Lexend,sans-serif; font-weight:700; font-size:24px; color:var(--hb-green-ink); }
[class*="st-key-n3list_"] { gap:8px !important; }
.n3-grp { display:flex; align-items:baseline; justify-content:space-between; margin:16px 0 6px; }
.n3-grp b { font-family:Lexend,sans-serif; font-weight:600; font-size:17px; color:var(--hb-ink); }
.n3-grp span { color:var(--hb-muted); font-size:13.5px; }
.n3-dots { letter-spacing:2px; color:var(--hb-ok); font-size:13px; }
.n3-dots i { font-style:normal; color:var(--hb-line); }

.n3-top { display:flex; align-items:center; justify-content:space-between; gap:8px; margin:2px 0 6px; flex-wrap:wrap; }
.n3-where { font-family:Lexend,sans-serif; font-weight:600; font-size:17px; color:var(--hb-ink); }
.n3-where span { color:var(--hb-muted); font-weight:500; font-size:15px; }
.n3-count { color:var(--hb-muted); font-size:13px; margin:4px 0 10px; display:flex; justify-content:space-between; }
.n3-mark { background:var(--hb-orange-soft); color:var(--hb-orange-ink); border-radius:6px; padding:0 4px; font-weight:700; }
.n3-blank { color:var(--hb-muted); }
.n3-res { font-family:Lexend,sans-serif; font-weight:700; font-size:18px; }
.hb-box.green .n3-res { color:var(--hb-ok); } .hb-box.red .n3-res { color:var(--hb-bad); }
.n3-res-vi { margin-top:4px; font-size:15.5px; }
.n3-res-vi small { color:var(--hb-muted); font-size:13px; display:block; }
.n3-wn { margin:2px 0; } .n3-wn b.k { color:var(--hb-bad); }
.n3-trans { border:1px dashed var(--hb-line); border-radius:16px; padding:10px 12px; margin:0 0 10px; }
.n3-trans .lab { font-family:Lexend,sans-serif; font-weight:700; font-size:12.5px; letter-spacing:.3px; color:var(--hb-muted); margin-bottom:4px; }
.n3-vi-pass { margin-top:10px; border-top:1px dashed var(--hb-line); padding-top:8px; color:var(--hb-ink); }
.n3-flagged { color:var(--hb-ok); font-weight:600; font-size:15px; }
.n3-score { text-align:center; padding:18px 12px; }
.n3-score .n { font-family:Lexend,sans-serif; font-weight:700; font-size:44px; line-height:1.1; color:var(--hb-green-ink); }
.n3-score .s { color:var(--hb-muted); font-size:15px; margin-top:4px; }
.n3-up { color:var(--hb-ok); font-weight:700; } .n3-down { color:var(--hb-bad); font-weight:700; }

/* nút đáp án to, chữ canh trái */
.st-key-n3_opts [data-testid="stButton"] button { justify-content:flex-start; text-align:left; min-height:54px;
  padding:8px 14px; border-radius:14px; }
.st-key-n3_opts [data-testid="stButton"] button p { font-size:17px !important; font-weight:500 !important; text-align:left; }
.st-key-n3_opts { gap:8px !important; }
.st-key-n3_opts button > div { justify-content:flex-start !important; width:100%; }
.st-key-n3_opts button [data-testid="stMarkdownContainer"] { text-align:left; }
/* bản đồ câu */
.st-key-n3map button { min-width:44px !important; width:44px; min-height:40px !important; padding:0 !important; border-radius:10px !important; }
.st-key-n3map button p { font-size:14px !important; }
[class*="st-key-n3m_ok_"] button { background:var(--hb-ok-soft) !important; color:var(--hb-ok) !important; border-color:var(--hb-ok) !important; }
[class*="st-key-n3m_bad_"] button { background:var(--hb-bad-soft) !important; color:var(--hb-bad) !important; border-color:var(--hb-bad) !important; }
[class*="st-key-n3m_no_"] button { background:var(--hb-soft) !important; color:var(--hb-muted) !important; border-color:transparent !important; }
[class*="st-key-n3m_"][class*="_c_"] button { outline:3px solid var(--hb-orange); outline-offset:1px; }
.st-key-n3_nav button { min-height:54px !important; }
@media (max-width:899px) { [data-testid="stColumn"]:has(.hb-desk) { display:none !important; } }
.st-key-n3_trbtn button p, .st-key-n3_trbtn2 button p { font-size:15px !important; }
</style>
"""


# ======================= TIỆN ÍCH =======================
_DARK = """
<style>
.stApp button[data-variant="segmented_control"], .stApp button[data-variant="pills"] {
  background:var(--hb-card) !important; color:var(--hb-ink) !important; border-color:var(--hb-line) !important; }
.stApp button[data-variant="segmented_control"][aria-checked="true"], .stApp button[data-variant="pills"][aria-checked="true"] {
  background:var(--hb-green-soft) !important; color:var(--hb-green-ink) !important; border-color:var(--hb-green) !important; }
.stApp button[data-variant="segmented_control"][aria-checked="true"] p, .stApp button[data-variant="pills"][aria-checked="true"] p {
  color:var(--hb-green-ink) !important; }
</style>
"""


def _css():
    ui.html(_CSS + (_DARK if ui.is_dark() else ""))


def _mdx(s) -> str:
    """Chữ thường → nhãn nút Streamlit (tránh markdown/LaTeX)."""
    s = str(s or "")
    for ch in "\\`*_[]<>#$~|":
        s = s.replace(ch, "\\" + ch)
    return s


def _nkey(num) -> str:
    return str(num)


def _qint(num) -> int:
    return int("".join(ch for ch in str(num) if ch.isdigit()) or 0)


def _ddmm(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        y, m, d = iso.split("-")
        return f"{int(d)}/{int(m)}"
    except Exception:  # noqa: BLE001
        return iso


def _scored(ex) -> list[dict]:
    return data.scored_questions(ex)


def _range_qs(ex, part) -> list[dict]:
    return progress.questions_in_range(ex, part)


def _complete(ex, r, part) -> bool:
    """Lượt r đã làm hết các câu tính điểm trong khoảng part chưa."""
    if not r:
        return False
    need = [str(q["num"]) for q in _range_qs(ex, part) if not q.get("bonus")]
    return bool(need) and all(k in r["answers"] for k in need)


def _range_score(ex, r, part) -> tuple[int, int, int]:
    """(đúng, đã làm, tổng) – chỉ câu tính điểm trong khoảng."""
    qs = [str(q["num"]) for q in _range_qs(ex, part) if not q.get("bonus")]
    if not r:
        return 0, 0, len(qs)
    done = [k for k in qs if k in r["answers"]]
    return sum(1 for k in done if r["correct"].get(k)), len(done), len(qs)


def _active_round(eid):
    """(lượt đang dùng, đã xong?) – lượt đang mở, hoặc lượt cuối (đã xong) để xem lại."""
    r = progress.current_round(eid)
    if r:
        return r, False
    rs = progress.rounds(eid)
    if rs:
        return rs[-1], True
    return None, False


def _sched_first() -> dict:
    """Số đề → ngày đầu tiên có trong lịch (để ghi 'lịch 22/10')."""
    if "_n3_sched" not in st.session_state:
        out = {}
        for d in data.schedule():
            for t in d["tasks"]:
                if t["type"] == "exam" and t.get("ref") is not None and t["ref"] not in out:
                    out[t["ref"]] = d["date"]
        st.session_state["_n3_sched"] = out
    return st.session_state["_n3_sched"]


def _passage(ex, part):
    p = (ex.get("passages") or {}).get(part)
    if isinstance(p, dict):
        return p.get("title", ""), p.get("text", "")
    return "", p or ""


def _passage_vi(ex, part) -> str:
    p = (ex.get("passages_vi") or {}).get(part)
    if isinstance(p, dict):
        return p.get("text", "")
    return p or ""


_BLANK = re.compile(r"\((\d+)\)\s*_{2,}")


def _passage_html(text: str, num) -> str:
    s = ui.md(text)
    cur = str(_qint(num))

    def rep(m):
        if m.group(1) == cur:
            return f'<span class="n3-mark">({m.group(1)}) ______</span>'
        return f'<span class="n3-blank">({m.group(1)}) ___</span>'
    return _BLANK.sub(rep, s)


def _cloze_sentence(text: str, num) -> str:
    """Câu trong đoạn văn có chỗ trống (num) – dùng khi câu hỏi không có chữ."""
    i = text.find(f"({_qint(num)})")
    if i < 0:
        return ""
    a = max(text.rfind(". ", 0, i), text.rfind("? ", 0, i), text.rfind("! ", 0, i))
    a = 0 if a < 0 else a + 2
    m = re.search(r"[.?!](\s|$)", text[i + 4:])
    b = len(text) if not m else i + 4 + m.start() + 1
    return text[a:b].strip()


def _q_text(ex, q) -> str:
    t = q.get("text") or ""
    if t.strip():
        return t
    if q.get("stem_en"):
        return q["stem_en"]
    if q.get("part") in ("cloze", "reading"):
        sent = _cloze_sentence(_passage(ex, q["part"])[1], q["num"])
        return _BLANK.sub("___", sent) if sent else f"Chỗ trống ({q['num']}) trong bài."
    return ""


def _read_aloud(q) -> str:
    if q.get("read_aloud"):
        return q["read_aloud"]
    t = q.get("stem_en") or q.get("text") or ""
    try:
        ans = q["options"][LETTERS.index(q["answer"])]
    except Exception:  # noqa: BLE001
        ans = ""
    if "___" in t:
        return re.sub(r"_{2,}", ans, t, count=1)
    return ans


def _part_label(q) -> str:
    return data.PART_LABEL.get(q.get("part", ""), q.get("part_label", ""))


def _row(key: str, inner_html: str, label: str, cls: str = "") -> bool:
    """Một dòng bấm được cả dòng (nút trong suốt phủ kín, xem ui.tap_row)."""
    return ui.tap_row(f"n3_{key}", f'<div class="n3-row hb-tapbox {cls}">{inner_html}<div class="go">›</div></div>', label)


def _level(eid) -> int:
    v = st.session_state.get(f"n3_level_{eid}")
    return v if v in (0, 1, 2) else progress.exam_settings(eid)["level"]


# ======================= VẼ 1 CÂU HỎI (dùng chung) =======================
def _draw_question(eid: str, q: dict, chosen: str | None, pick, kp: str, note: str = "", think=None):
    """Vẽ 1 câu: bài đọc, câu hỏi, dịch cụm, 4 đáp án, chấm, giải thích, nhờ viết lại.
    chosen: chữ đã chọn (None = chưa làm). pick(letter) -> bool: ghi câu trả lời.
    kp: tiền tố key ('q' đề thường, 'w' câu sai)."""
    ex = data.exam(eid)
    num = q["num"]
    uid = f"{kp}_{eid}_{num}"
    answered = chosen is not None
    part = q.get("part", "")

    # ---- bài đọc (điền từ / đọc hiểu) ----
    if part in ("cloze", "reading"):
        ptitle, ptext = _passage(ex, part)
        if ptext:
            head = ptitle or ("Đoạn văn điền từ" if part == "cloze" else "Bài đọc")
            with st.expander(f"Đọc bài: {head}", expanded=True):
                vi_on = answered and st.session_state.get(f"n3_pvi_{eid}_{part}", False)
                vi = _passage_vi(ex, part)
                body = _passage_html(ptext, num) if part == "cloze" else ui.md(ptext)
                if vi_on and vi:
                    body += f'<div class="n3-vi-pass"><b>Bản dịch:</b><br>{ui.md(vi)}</div>'
                ui.html(f'<div class="hb-passage">{body}</div>')
                if answered:
                    if vi:
                        lab = "Ẩn bản dịch" if vi_on else "Xem bản dịch cả bài"
                        if st.button(lab, key=f"n3_pvib_{uid}", icon=":material/translate:", type="tertiary"):
                            st.session_state[f"n3_pvi_{eid}_{part}"] = not vi_on
                            ui.rerun()
                    else:
                        ui.html(f'<div class="hb-muted">Bản dịch cả bài: {WAIT}.</div>')
                else:
                    ui.html('<div class="hb-muted" style="margin-top:6px">Bản dịch cả bài sẽ mở sau khi bạn chọn đáp án.</div>')

    # ---- câu hỏi + dịch theo cụm ----
    tr_on = st.session_state.get("n3_tr", False)
    prompt = q.get("prompt") or ""
    if not prompt and part == "cloze":
        prompt = f"Chọn từ đúng điền vào chỗ trống ({_qint(num)}) trong bài:"
    elif not prompt and part == "reading":
        prompt = "Đọc bài rồi chọn đáp án đúng:"
    qtext = _q_text(ex, q)
    chip = (f'<span class="hb-chip orange" style="margin-bottom:6px;display:inline-block">Câu của cô · {ui.esc(q["teacher"])}</span>'
            if q.get("teacher") else "")
    q_html = chip + (f'<div class="hb-prompt">{ui.md(prompt)}</div>' if prompt else "") + \
        f'<div class="hb-q">{re.sub(r"_{3,}", "<span class=n3-mark>___</span>", ui.md(qtext))}</div>'
    if q.get("chunks"):
        tr_html = ('<div class="n3-trans"><div class="lab">DỊCH CÂU HỎI THEO CỤM</div>'
                   + ui.chunks_html(q["chunks"], q.get("vi_question", "")))
    elif q.get("vi_question"):
        tr_html = (f'<div class="n3-trans"><div class="lab">DỊCH CÂU HỎI</div>'
                   f'<div>{ui.md(q["vi_question"])}</div>')
    else:
        tr_html = f'<div class="n3-trans"><div class="lab">DỊCH CÂU HỎI THEO CỤM</div><div class="hb-muted">{WAIT}.</div>'
    _ovi = q.get("options_vi") or []
    if any(_ovi) and not (think and not answered):
        tr_html += ('<div class="lab" style="margin-top:10px">NGHĨA CÁC ĐÁP ÁN</div>' + "".join(
            f'<div style="margin:2px 0"><b>{LETTERS[i]}.</b> {ui.esc(o)} <span class="hb-muted">→ {ui.esc(_ovi[i])}</span></div>'
            for i, o in enumerate(q.get("options") or []) if i < len(_ovi) and _ovi[i]))
    tr_html += "</div>"

    if tr_on:
        left, right = st.columns([3, 2], gap="medium")
    else:
        left, right = st.container(), None
    with left:
        ui.html(q_html)
        gr_on = st.session_state.get("n3_gr", False)
        with st.container(key="n3_trbtn" if kp == "q" else "n3_trbtn2", horizontal=True, gap="small"):
            lab = "Tắt dịch theo cụm" if tr_on else "Dịch câu hỏi theo cụm"
            if st.button(lab, key=f"n3_tr_{uid}", icon=":material/translate:"):
                st.session_state["n3_tr"] = not tr_on
                ui.rerun()
            if st.button("Ẩn ngữ pháp" if gr_on else "Ngữ pháp câu này", key=f"n3_gr_{uid}", icon=":material/school:"):
                st.session_state["n3_gr"] = not gr_on
                ui.rerun()
        if tr_on:
            ui.html(f'<div class="hb-mob">{tr_html}</div>')
        if gr_on:
            gid = q.get("g") or "VOCAB"
            card = data.grammar().get(gid) or {}
            _editable("blue", f"NGỮ PHÁP: {card.get('title', gid).upper()}", f"g:{gid}", card.get("body", ""), uid,
                      hint="Sửa ở đây sẽ đổi thẻ này cho mọi câu cùng dạng.")
        if note:
            ui.html(f'<div class="hb-muted" style="margin:-2px 0 8px">{ui.esc(note)}</div>')
        if think and not answered:
            ui.html(ui.box("orange", "THỬ NHỚ LẠI 5 GIÂY",
                           "Câu này bạn <b>đã làm đúng trước đây</b>. Đọc câu, thử nhớ xem lần trước chọn từ gì "
                           "(hoặc nhớ ghi chú của mình). Nhớ ra một chút cũng được, <b>không nhớ gì cũng không sao</b>: "
                           "chỉ cần cố nhớ 5 giây là não đã ghi chắc hơn rồi."))
            with st.container(horizontal=True, gap="small"):
                if st.button("Nhớ ra rồi · Xem A B C D", key=f"n3_think_{uid}", type="primary", width="stretch",
                             icon=":material/visibility:"):
                    think()
                    ui.rerun()
                if st.button("Không nhớ · Mở luôn", key=f"n3_thinkno_{uid}", width="stretch"):
                    think()
                    ui.rerun()
        else:
            _draw_options(eid, q, chosen, pick, uid)
    if right is not None:
        with right:
            ui.html(f'<div class="hb-desk">{tr_html}</div>')

    if not answered:
        if kp != "r":
            _draw_note(eid, q, uid)
        return

    # ---- kết quả ----
    ok = chosen == q.get("answer")
    ans = q.get("answer", "")
    vi_full = q.get("vi_full", "")
    vi_part = (f'<div class="n3-res-vi"><small>Nghĩa cả câu</small>{ui.md(vi_full)}</div>' if vi_full else "")
    if ok:
        ui.html(f'<div class="hb-box green"><div class="n3-res">✓ Đúng rồi!</div>{vi_part}</div>')
        gk = f"n3_guess_{uid}"
        if st.session_state.get(gk):
            ui.html('<div class="hb-muted">Đã ghi là đoán mò: mai câu này quay lại.</div>')
        elif st.button("Đúng nhưng đoán mò → mai làm lại", key=f"{gk}_b", type="tertiary", icon=":material/casino:"):
            progress.recall_guess(eid, q["num"])
            st.session_state[gk] = True
            ui.rerun()
    else:
        ui.html(f'<div class="hb-box red"><div class="n3-res">✗ Chưa đúng – đáp án đúng là {ui.esc(ans)}</div>{vi_part}</div>')

    s = progress.exam_settings(eid)
    exp_key = f"n3_exp_{uid}"
    exp_open = st.session_state.get(exp_key, (not ok) and s["auto_open"])
    with st.container(horizontal=True, gap="small"):
        ui.speak_button(_read_aloud(q), key=f"n3_{uid}", label="Nghe câu đúng")
        if st.button("Ẩn giải thích" if exp_open else "Xem giải thích", key=f"n3_expb_{uid}",
                     icon=":material/lightbulb:"):
            st.session_state[exp_key] = not exp_open
            ui.rerun()
    if exp_open:
        _draw_explain(eid, q, uid)
        if q.get("orig_answer") and q.get("orig_answer") != ans:
            ui.html(f'<div class="hb-muted">Thứ tự đáp án đã được đảo. Chữ cái trong lời giải là theo đề gốc '
                    f'(đề gốc đáp án đúng là <b>{ui.esc(q["orig_answer"])}</b>).</div>')
    _draw_note(eid, q, uid)
    _draw_flag(eid, q, uid)


def _editable(color: str, title: str, key: str, text: str, uid: str, hint: str = ""):
    """Hộp nội dung có nút "Sửa": người học tự viết lại cho dễ hiểu (lưu riêng, không mất bản gốc)."""
    ov = progress.edit_get(key)
    shown = ov or text
    ek = f"n3_ed_{uid}_{key}"
    if st.session_state.get(ek):
        with st.container(border=True):
            st.text_area(f"Viết lại: {title}", value=shown, key=f"{ek}_ta", height=170,
                         help="**chữ** = in đậm. Xuống dòng bình thường.")
            if hint:
                ui.html(f'<div class="hb-muted">{ui.esc(hint)}</div>')
            with st.container(horizontal=True, gap="small"):
                if st.button("Lưu", key=f"{ek}_s", type="primary"):
                    progress.edit_set(key, st.session_state.get(f"{ek}_ta", ""))
                    st.session_state[ek] = False
                    ui.rerun()
                if st.button("Hủy", key=f"{ek}_c"):
                    st.session_state[ek] = False
                    ui.rerun()
                if ov and st.button("Về bản gốc", key=f"{ek}_r", type="tertiary"):
                    progress.edit_set(key, "")
                    st.session_state[ek] = False
                    ui.rerun()
        return
    if not shown:
        if st.button(f"Thêm: {title.title()}", key=f"{ek}_b", type="tertiary", icon=":material/edit:"):
            st.session_state[ek] = True
            ui.rerun()
        return
    ui.html(ui.box(color, title + (" · BẢN BẠN VIẾT" if ov else ""), ui.md(shown)))
    if st.button("Sửa cho dễ hiểu hơn", key=f"{ek}_b", type="tertiary", icon=":material/edit:"):
        st.session_state[ek] = True
        ui.rerun()


def _draw_note(eid, q, uid):
    """Ô ghi chú riêng của câu: lưu cách giải thích bạn thấy dễ hiểu nhất."""
    num = q["num"]
    k = f"n3_note_{uid}"
    if k not in st.session_state:
        st.session_state[k] = progress.note_get(eid, num)

    def _save(_k=k, _e=eid, _n=num):
        progress.note_set(_e, _n, st.session_state.get(_k, ""))
    st.text_area("Ghi chú của bạn (dán cách giải thích dễ hiểu nhất vào đây)", key=k, on_change=_save, height=110,
                 placeholder="Ví dụ: thấy 'every day' → hiện tại đơn, he/she/it thì thêm s.")
    if st.session_state.get(k):
        ui.html('<div class="hb-muted" style="margin:-8px 0 10px">Đã lưu. Ghi chú sẽ hiện lại mỗi khi gặp câu này.</div>')


def _draw_options(eid, q, chosen, pick, uid):
    opts = q.get("options") or []
    ovi = q.get("options_vi") or []
    if chosen is None:
        with st.container(key="n3_opts"):
            for i, o in enumerate(opts):
                k = LETTERS[i]
                if st.button(f"{k}. {_mdx(o)}", key=f"n3_opt_{uid}_{k}", width="stretch"):
                    ok = pick(k)
                    if ok:
                        st.session_state["n3_streak"] = st.session_state.get("n3_streak", 0) + 1
                        ui.fx("correct", streak=st.session_state["n3_streak"])
                    else:
                        st.session_state["n3_streak"] = 0
                        ui.fx("wrong", text=_read_aloud(q))
                    ui.rerun()
        return
    ans = q.get("answer")
    out = []
    for i, o in enumerate(opts):
        k = LETTERS[i]
        cls, mark = "", ""
        if k == ans:
            cls, mark = "ok", "✓"
        elif k == chosen:
            cls, mark = "bad", "✗"
        vi = f"<small>{ui.esc(ovi[i])}</small>" if i < len(ovi) and ovi[i] else ""
        out.append(f'<div class="hb-opt {cls}"><div class="k">{k}</div><div class="t">{ui.esc(o)}{vi}</div>'
                   f'<div class="m">{mark}</div></div>')
    ui.html("".join(out))


def _draw_explain(eid, q, uid):
    lvl = _level(eid)
    has = any(q.get(k) for k in LEVEL_KEYS)
    if not has:
        ans = q.get("answer", "")
        try:
            txt = q["options"][LETTERS.index(ans)]
        except Exception:  # noqa: BLE001
            txt = ""
        body = f"Đáp án đúng: <b>{ui.esc(ans)}. {ui.esc(txt)}</b>"
        if q.get("why_original"):
            body += f"<br>Lời giải trong đề: {ui.md(q['why_original'])}"
        ui.html(ui.box("green", "✓ ĐÁP ÁN", body))
        ui.html(ui.box("gray", "PHẦN GIẢI THÍCH", f"{WAIT}."))
        return

    def _chg(k=f"n3_lv_{uid}", e=eid):
        v = st.session_state.get(k)
        if v in (0, 1, 2):
            st.session_state[f"n3_level_{e}"] = v
    st.segmented_control("Mức giải thích", [0, 1, 2], format_func=lambda i: progress.LEVELS[i], default=lvl,
                         key=f"n3_lv_{uid}", on_change=_chg, required=True, label_visibility="collapsed")
    lvl = _level(eid)
    why = q.get(LEVEL_KEYS[lvl]) or q.get("easy") or q.get("short") or q.get("super") or ""
    ans = q.get("answer", "")
    base = f"q:{eid}#{q['num']}"
    _editable("green", f"✓ VÌ SAO CHỌN {ans}", f"{base}:why", why, uid)
    wn = q.get("why_not") or []
    if wn:
        txt = "\n".join(f'**{w.get("key", "")}.** {w.get("text", "")}' for w in wn)
        _editable("red", "✗ VÌ SAO KHÔNG CHỌN", f"{base}:whynot", txt, uid)
    _editable("orange", "⚡ MẸO NHỚ NHANH", f"{base}:tip", q.get("tip") or "", uid)
    if q.get("flag"):
        ui.html(f'<div class="hb-box gray" style="font-size:14px"><b>Lưu ý:</b> đề gốc câu này có chỗ chưa rõ. '
                f'{ui.md(q["flag"])}</div>')


def _draw_flag(eid, q, uid):
    num = q["num"]
    f = progress.flag_of(eid, num)
    if f:
        with st.container(horizontal=True, gap="small", vertical_alignment="center"):
            ui.html('<span class="n3-flagged">Đã nhờ viết lại ✓</span>')
            if st.button("Bỏ đánh dấu", key=f"n3_unf_{uid}", type="tertiary"):
                progress.unflag(eid, num)
                ui.rerun()
        if f.get("note"):
            ui.html(f'<div class="hb-muted" style="margin:-4px 0 12px">Ghi chú: {ui.esc(f["note"])}</div>')
        return
    ok_key = f"n3_fform_{uid}"
    if not st.session_state.get(ok_key):
        if st.button("Vẫn chưa hiểu? Nhờ viết lại câu này", key=f"n3_fbtn_{uid}", type="tertiary",
                     icon=":material/help:"):
            st.session_state[ok_key] = True
            ui.rerun()
        return
    with st.container(border=True):
        note = st.text_input("Bạn chưa hiểu chỗ nào? (không bắt buộc)", key=f"n3_fnote_{uid}",
                             placeholder="Ví dụ: chưa hiểu vì sao không chọn A")
        with st.container(horizontal=True, gap="small"):
            if st.button("Lưu, nhờ viết lại", key=f"n3_fsave_{uid}", type="primary"):
                progress.flag(eid, num, note or "", _level(eid))
                st.session_state.pop(ok_key, None)
                ui.rerun()
            if st.button("Thôi", key=f"n3_fno_{uid}"):
                st.session_state.pop(ok_key, None)
                ui.rerun()
        ui.html('<div class="hb-muted">Câu này được lưu trong Cài đặt đề. Nhắn Claude '
                '"Viết lại các câu đã đánh dấu" để có lời giải mới.</div>')


# ======================= HOME =======================
def _status(eid: str, count: int) -> str:
    rs = progress.rounds(eid)
    if not rs:
        return "Chưa làm"
    parts = []
    for r in rs:
        c, a, t = progress.round_score(eid, r)
        if r.get("finished"):
            parts.append(f"Lần {r['n']}: <b>{c}</b>")
        else:
            parts.append(f"Đang làm {a}/{t}" if r["n"] == 1 else f"Lần {r['n']}: đang làm {a}/{t}")
    if len(parts) > 3:
        parts = parts[:1] + ["…"] + parts[-2:]
    return " → ".join(parts)


def _exam_row(x: dict, today_refs: set):
    eid = x["id"]
    s = progress.exam_summary(eid)
    chips = []
    if x["id"] in today_refs:
        chips.append('<span class="hb-chip orange">Hôm nay</span>')
    best = s["best"]
    m = progress.milestone(best)
    if m:
        chips.append(f'<span class="hb-chip green">Mốc {m} ✓</span>')
    elif best is not None:
        chips.append(f'<span class="hb-chip gray">Mốc {progress.next_milestone(best)}</span>')
    if x.get("source") == "upload" and not x.get("complete"):
        chips.append(f'<span class="hb-chip blue">{WAIT}</span>')
    st_txt = _status(eid, x.get("count", 50))
    if st_txt == "Chưa làm" and x.get("num") and _sched_first().get(x["num"]):
        st_txt += f" · lịch {_ddmm(_sched_first()[x['num']])}"
    sub = ""
    if x["kind"] == "mock" and x.get("num"):
        sub = f' <span style="color:var(--hb-muted);font-weight:500;font-size:13.5px">· Đề {x["num"]}</span>'
    inner = (f'<div class="l"><div class="nm">{ui.esc(x["name"])}{sub}</div><div class="st">{st_txt}</div></div>'
             f'<div class="r">{"".join(chips)}</div>')
    if _row(eid, inner, f"Mở {x['name']}"):
        ui.go("n3", "exam", eid=eid, part="1-50")


def _home():
    _css()
    ui.title("Đề thi", "Làm từng câu, chấm ngay. Câu sai tự vào Bảng câu sai.")
    allw = progress.wrong_list()
    due = progress.wrong_due()
    if allw:
        inner = (f'<div class="l"><div class="nm">Bảng câu sai: {len(allw)} câu</div>'
                 f'<div class="st">Hôm nay cần làm lại <b>{len(due)}</b> câu · sai nhiều nhất xếp trước</div></div>'
                 f'<div class="big">{len(due)}</div>')
    else:
        inner = ('<div class="l"><div class="nm">Bảng câu sai: 0 câu</div>'
                 '<div class="st">Làm đề xong, câu sai sẽ vào đây để luyện lại.</div></div>')
    rs = progress.recall_stats()
    rinner = (f'<div class="l"><div class="nm">Nhắc lại để không quên</div>'
              f'<div class="st">{rs["total"]} câu đã làm · hôm nay đến hạn <b>{rs["due"]}</b> câu · đã làm {rs["done_today"]}</div></div>'
              f'<div class="big">{rs["due"]}</div>')
    if _row("recallcard", rinner, "Mở Nhắc lại", "card-green"):
        ui.go("n3", "recall")
    if _row("wrongcard", inner, "Mở Bảng câu sai", "card-green"):
        ui.go("n3", "wrong")

    with st.container(horizontal=True, gap="small"):
        if st.button("+ Thêm đề", key="n3_add", width="stretch"):
            ui.go("n3", "upload")
        if st.button("Tài liệu", key="n3_docs", icon=":material/folder_open:", width="stretch"):
            ui.go("n3", "docs")

    t = clock.today()
    today_refs = set()
    for tk in plan.tasks_for(t):
        if tk["type"] == "exam" and tk.get("ref") is not None and not tk["done"]:
            today_refs.add(data.exam_id(tk["ref"]))
    ex = data.exam_list()
    groups = [
        ("practice", "Đề luyện 1–15", "Làm theo lịch · nhãn cam = câu của cô"),
        ("mock", f"Thi thử ({sum(1 for x in ex if x['kind'] == 'mock')} đề)", "Làm như thi thật"),
        ("teacher", "Bài thêm của cô", "Biến đổi câu, đọc hiểu, điền từ · đáp án do AI giải"),
        ("upload", "Đề bạn tải lên", ""),
    ]
    for kind, label, hint in groups:
        items = [x for x in ex if x["kind"] == kind]
        if not items:
            continue
        ui.html(f'<div class="n3-grp"><b>{ui.esc(label)}</b><span>{ui.esc(hint)}</span></div>')
        with st.container(key=f"n3list_{kind}"):
            for x in items:
                _exam_row(x, today_refs)


# ======================= TRANG 1 ĐỀ =======================
def _first_unanswered(ex, r, part) -> int | None:
    for i, q in enumerate(_range_qs(ex, part)):
        if not r or str(q["num"]) not in r["answers"]:
            return i
    return None


def _exam(params):
    _css()
    eid = params.get("eid") or "de01"
    ex = data.exam(eid)
    if not ex:
        ui.back("Đề thi", "n3", "home")
        st.warning("Không tìm thấy đề này.")
        return
    ui.back("Đề thi", "n3", "home")
    kind = {"practice": "Đề luyện", "mock": "Thi thử", "upload": "Đề tải lên", "teacher": "Bài thêm của cô"}.get(ex.get("kind"), "Đề")
    n_sc = len(_scored(ex))
    ui.title(ex["name"], f"{kind} · {n_sc} câu" + (f" · Đề {ex['num']}" if ex.get("kind") == "mock" and ex.get("num") else ""))
    if ex.get("note"):
        ui.html(ui.box("gray", "GHI CHÚ VỀ ĐỀ", ui.md(ex["note"])))

    if ex.get("kind") == "upload" and not ex.get("complete"):
        ui.html(ui.box("blue", "ĐỀ TẢI LÊN", f"Một số câu chưa có giải thích. Phần thiếu ghi \"{WAIT}\"."))

    rs = progress.rounds(eid)
    if rs:
        rows = []
        for r in rs:
            c, a, t = progress.round_score(eid, r)
            if r.get("finished"):
                m = progress.milestone(c)
                chip = f' <span class="hb-chip green">Mốc {m}</span>' if m else ""
                rows.append(f'<div style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;'
                            f'border-bottom:1px solid var(--hb-line)"><span>Lần {r["n"]} · {_ddmm(r["finished"])}</span>'
                            f'<span><b>{c}/{t}</b>{chip}</span></div>')
            else:
                rows.append(f'<div style="display:flex;justify-content:space-between;gap:8px;padding:6px 0">'
                            f'<span>Lần {r["n"]} · đang làm</span><span>đã làm {a}/{t} · đúng {c}</span></div>')
        ui.html(f'<div class="hb-card"><div class="hb-box-label" style="color:var(--hb-muted)">CÁC LƯỢT ĐÃ LÀM</div>'
                f'{"".join(rows)}</div>')

    # chọn khoảng câu
    pkey = f"n3_part_{eid}"
    if pkey not in st.session_state or params.get("part") and st.session_state.get(f"{pkey}_src") != params.get("part"):
        st.session_state[pkey] = params.get("part") if params.get("part") in RANGE_LABEL else "1-50"
        st.session_state[f"{pkey}_src"] = params.get("part")
    ui.html('<div class="hb-h2">Làm phần nào?</div>')
    _maxn = max((_qint(x["num"]) for x in ex["questions"]), default=50)
    _opts = [p for p, _ in RANGES] if _maxn > 30 else ["1-50"]
    if st.session_state.get(pkey) not in _opts:
        st.session_state[pkey] = "1-50"
    part = st.segmented_control("Khoảng câu", _opts,
                                format_func=lambda p: "Cả đề" if p == "1-50" else (f"Câu 26–{_maxn}" if p == "26-50" else RANGE_LABEL[p]),
                                key=pkey, required=True, label_visibility="collapsed")
    part = part or "1-50"

    cur = progress.current_round(eid)
    if cur:
        done_rng = _complete(ex, cur, part)
        if done_rng:
            c, a, t = _range_score(ex, cur, part)
            ui.html(f'<div class="hb-muted" style="margin:6px 0">Lần {cur["n"]}: {RANGE_LABEL[part]} đã làm xong · đúng {c}/{t}.</div>')
            if st.button(f"Xem kết quả {RANGE_LABEL[part].lower()}", key="n3_seeres", type="primary", width="stretch"):
                st.session_state[f"n3_pos_{eid}_{part}"] = len(_range_qs(ex, part))
                ui.go("n3", "quiz", eid=eid, part=part)
            other = "26-50" if part == "1-25" else "1-25" if part == "26-50" else None
            if other and not _complete(ex, cur, other):
                if st.button(f"Làm tiếp {RANGE_LABEL[other]}", key="n3_other", width="stretch"):
                    st.session_state.pop(f"n3_pos_{eid}_{other}", None)
                    ui.go("n3", "quiz", eid=eid, part=other)
        else:
            i = _first_unanswered(ex, cur, part) or 0
            q0 = _range_qs(ex, part)[i]
            if cur["answers"]:
                lab = f"Làm tiếp từ câu {q0['num']}"
            else:
                lab = "Làm lần đầu" if cur["n"] == 1 else f"Làm lại lần {cur['n']}"
            if st.button(lab, key="n3_start", type="primary", width="stretch", icon=":material/play_arrow:"):
                st.session_state.pop(f"n3_pos_{eid}_{part}", None)
                ui.go("n3", "quiz", eid=eid, part=part)
    else:
        k = len(rs) + 1
        lab = "Làm lần đầu" if k == 1 else f"Làm lại lần {k}"
        if st.button(lab, key="n3_start", type="primary", width="stretch", icon=":material/play_arrow:"):
            progress.start_round(eid)
            st.session_state.pop(f"n3_pos_{eid}_{part}", None)
            ui.go("n3", "quiz", eid=eid, part=part)
        if k > 1:
            ui.html('<div class="hb-muted" style="margin-top:4px">Lượt mới bắt đầu từ trắng. Điểm các lần trước vẫn giữ.</div>')

    if ex.get("kind") == "mock":
        ui.html(ui.box("blue", "LÀM NHƯ THI THẬT", "Bấm <b>⏱ Đồng hồ học</b> ở góc trên, chọn <b>50 / 10</b>. "
                       "Làm hết 50 câu trong 50 phút, rồi nghỉ 10 phút."))

    fl = progress.flags(eid)
    ui.html('<div style="height:6px"></div>')
    with st.container(horizontal=True, gap="small", vertical_alignment="center"):
        if st.button("Cài đặt đề", key="n3_set", icon=":material/settings:"):
            ui.go("n3", "settings", eid=eid)
        if fl:
            ui.html(f'<span class="hb-chip orange">Đã nhờ viết lại {len(fl)} câu</span>')
    lvl = progress.exam_settings(eid)
    ui.html(f'<div class="hb-muted">Giải thích: {progress.LEVELS[lvl["level"]]} · '
            f'{"tự mở khi sai" if lvl["auto_open"] else "bấm mới mở"}</div>')


# ======================= LÀM ĐỀ =======================
def _exam_pick(eid, q, letter) -> bool:
    ex = data.exam(eid)
    r0 = progress.current_round(eid)
    before = {p: _complete(ex, r0, p) for p, _ in RANGES}
    ok = progress.answer(eid, q["num"], letter)
    r1 = progress.rounds(eid)[-1]
    for p, _ in RANGES:
        if not before[p] and _complete(ex, r1, p):
            if ex.get("kind") != "upload" and ex.get("num"):
                plan.auto_done("exam", ref=int(ex["num"]), part=p, mode="new" if r1["n"] == 1 else "redo")
            if p == "1-50" and r1["n"] >= 3:
                plan.auto_done("exam_weak")
    return ok


def _quiz(params):
    _css()
    eid = params.get("eid") or "de01"
    part = params.get("part") if params.get("part") in RANGE_LABEL else "1-50"
    ex = data.exam(eid)
    if not ex:
        ui.back("Đề thi", "n3", "home")
        st.warning("Không tìm thấy đề này.")
        return
    ui.back(ex["name"], "n3", "exam", eid=eid, part=part)
    _quiz_body(eid, part)


@ui.fragment
def _quiz_body(eid: str, part: str):
    """Vùng làm câu hỏi: bấm đáp án / Câu sau chỉ chạy lại vùng này."""
    ex = data.exam(eid)
    qs = _range_qs(ex, part)
    r, finished = _active_round(eid)
    pkey = f"n3_pos_{eid}_{part}"
    if pkey not in st.session_state:
        i = _first_unanswered(ex, r, part)
        st.session_state[pkey] = len(qs) if (i is None or (finished and _complete(ex, r, part))) else i
    pos = max(0, min(st.session_state[pkey], len(qs)))

    if pos >= len(qs):
        if r and (_complete(ex, r, part) or finished):
            _summary(eid, ex, r, part)
            return
        pos = st.session_state[pkey] = _first_unanswered(ex, r, part) or 0

    q = qs[pos]
    k = str(q["num"])
    chosen = r["answers"].get(k) if r else None
    note = ""
    if finished and chosen is None:
        # lượt đã xong nhưng câu này (câu thưởng) chưa làm → làm thử, không ghi điểm
        tk = f"n3_try_{eid}_{k}"
        chosen = st.session_state.get(tk)
        note = "Lượt này đã xong. Câu này chỉ làm thử, không tính điểm."

        def pick(letter, _tk=tk, _q=q):
            st.session_state[_tk] = letter
            return letter == _q.get("answer")
    else:
        def pick(letter, _q=q):
            return _exam_pick(eid, _q, letter)
    if q.get("bonus"):
        note = (note + " " if note else "") + "Câu thưởng: làm cho quen, không tính vào điểm 50 câu."

    c, a, t = _range_score(ex, r, part)
    streak = st.session_state.get("n3_streak", 0)
    chip = f'<span class="hb-chip orange">{streak} câu đúng liền</span> ' if streak >= 2 else ""
    rn = f"Lần {r['n']} · " if r else ""
    ui.html(f'<div class="n3-top"><div class="n3-where">{ui.esc(ex["name"])} · Câu {ui.esc(q["num"])} '
            f'<span>· {ui.esc(_part_label(q))}</span></div><div>{chip}<span class="hb-chip green">đúng {c}/{a}</span></div></div>'
            f'{ui.bar(a / t if t else 0)}<div class="n3-count"><span>{rn}đã làm {a}/{t} câu ({RANGE_LABEL[part]})</span></div>')

    _draw_question(eid, q, chosen, pick, "q", note)

    # ---- điều hướng ----
    last = pos == len(qs) - 1
    with st.container(horizontal=True, gap="small", key="n3_nav"):
        if st.button("← Câu trước", key="n3_prev", disabled=pos == 0, width="stretch"):
            st.session_state[pkey] = pos - 1
            ui.rerun()
        if last:
            r_now, _ = _active_round(eid)
            all_done = r_now and _complete(ex, r_now, part)
            nlab = "Xem kết quả →" if all_done else "Làm câu còn sót →"
        else:
            nlab = "Câu sau →"
        if st.button(nlab, key="n3_next", type="primary" if chosen is not None else "secondary", width="stretch"):
            if last:
                r_now, _ = _active_round(eid)
                if r_now and _complete(ex, r_now, part):
                    st.session_state[pkey] = len(qs)
                else:
                    st.session_state[pkey] = _first_unanswered(ex, r_now, part) or 0
            else:
                st.session_state[pkey] = pos + 1
            ui.rerun()

    mopen = st.session_state.get("n3_mapopen", False)
    if st.button(("Đóng" if mopen else "Mở") + f" bản đồ câu · đã làm {a}/{t}", key="n3_mapbtn", type="tertiary",
                 icon=":material/grid_view:"):
        st.session_state["n3_mapopen"] = not mopen
        ui.rerun()
    if mopen:      # chỉ vẽ 50 nút khi bạn mở bản đồ
        ui.html('<div class="hb-muted" style="margin-bottom:6px">Xanh = đúng · đỏ = sai · xám = chưa làm. Bấm số để nhảy tới câu.</div>')
        with st.container(horizontal=True, gap="small", key="n3map"):
            for i, qq in enumerate(qs):
                kk = str(qq["num"])
                if r and kk in r["answers"]:
                    stt = "ok" if r["correct"].get(kk) else "bad"
                else:
                    stt = "no"
                if st.button(kk, key=f"n3m_{stt}_{'c' if i == pos else 'x'}_{kk}"):
                    st.session_state[pkey] = i
                    st.session_state["n3_mapopen"] = False
                    ui.rerun()


_PRAISE = {
    42: "Siêu phẩm! Cú sút xa thẳng góc chữ A. Bạn đã chạm mốc 42 – đẳng cấp ngôi sao!",
    35: "Bàn thắng đẹp! Qua mốc 35, đội bạn đã vào vòng trong. Giữ phong độ nhé!",
    30: "Vào rồi! Qua mốc 30 – bàn thắng đầu tiên của trận. Hiệp sau ghi thêm nữa!",
}


def _summary(eid, ex, r, part):
    qs = _range_qs(ex, part)
    c, a, t = _range_score(ex, r, part)
    rs = progress.rounds(eid)
    idx = next((i for i, x in enumerate(rs) if x is r), len(rs) - 1)
    cmp_html = ""
    if idx > 0 and _complete(ex, rs[idx - 1], part):
        pc, _, _ = _range_score(ex, rs[idx - 1], part)
        d = c - pc
        if d > 0:
            cmp_html = f'<span class="n3-up">▲ {d} câu</span> so với lần {rs[idx - 1]["n"]} ({pc}/{t})'
        elif d < 0:
            cmp_html = f'<span class="n3-down">▼ {-d} câu</span> so với lần {rs[idx - 1]["n"]} ({pc}/{t})'
        else:
            cmp_html = f"Bằng lần {rs[idx - 1]['n']} ({pc}/{t})"
    ui.html(f'<div class="hb-title">Xong {RANGE_LABEL[part].lower()}!</div>'
            f'<div class="hb-sub">{ui.esc(ex["name"])} · lần {r["n"]}</div>')
    ui.html(f'<div class="hb-card green n3-score"><div class="n">Đúng {c}/{t}</div>'
            f'<div class="s">{cmp_html or "Lần đầu làm phần này"}</div></div>')

    full = _complete(ex, r, "1-50")
    score50 = None
    if full and len(_scored(ex)) == 50:
        score50, _, _ = _range_score(ex, r, "1-50")
        if part != "1-50":
            ui.html(f'<div class="hb-muted" style="text-align:center;margin:-4px 0 8px">Cả đề lần {r["n"]}: <b>{score50}/50</b></div>')
    m = progress.milestone(score50)
    fxk = f"n3_sfx_{eid}_{r['n']}_{part}"
    if m:
        ui.html(ui.box("orange", f"⚡ ĐẠT MỐC {m}", _PRAISE[m]))
        if not st.session_state.get(fxk):
            st.session_state[fxk] = True
            ui.fx("correct", streak=5)
    elif score50 is not None:
        nm = progress.next_milestone(score50)
        ui.html(ui.box("blue", "CỐ LÊN", f"Trận này chưa tới mốc {nm}. Còn thiếu <b>{nm - score50}</b> câu. "
                       "Mỗi câu sai là một bài tập sút – làm lại là ghi bàn!"))
    elif part != "1-50":
        ui.html('<div class="hb-muted" style="text-align:center">Mốc 30 / 35 / 42 tính khi làm đủ cả 50 câu.</div>')

    bonus = [q for q in qs if q.get("bonus") and str(q["num"]) in r["answers"]]
    if bonus:
        bc = sum(1 for q in bonus if r["correct"].get(str(q["num"])))
        ui.html(f'<div class="hb-muted" style="text-align:center">Câu thưởng (không tính điểm): đúng {bc}/{len(bonus)}</div>')

    wrong = [q for q in qs if str(q["num"]) in r["answers"] and not r["correct"].get(str(q["num"]))]
    if wrong:
        ui.html(f'<div class="hb-box red" style="margin-top:10px"><div class="hb-box-label">CÂU SAI</div>'
                f'<b>{len(wrong)} câu</b> sai đã vào Bảng câu sai: câu '
                f'{", ".join(str(q["num"]) for q in wrong)}.</div>')
        if st.button(f"Làm lại {len(wrong)} câu sai", key="n3_redo_wrong", type="primary", width="stretch",
                     icon=":material/replay:"):
            _start_wq([(eid, q["num"]) for q in wrong], f"Câu sai {ex['name']}", None)
    else:
        ui.html(ui.box("green", "SẠCH LƯỚI", "Không sai câu nào. Giữ sạch lưới như thủ môn số 1!"))

    other = "26-50" if part == "1-25" else "1-25" if part == "26-50" else None
    if other and not _complete(ex, r, other) and not r.get("finished"):
        if st.button(f"Làm tiếp {RANGE_LABEL[other]}", key="n3_sum_other", width="stretch"):
            st.session_state.pop(f"n3_pos_{eid}_{other}", None)
            ui.go("n3", "quiz", eid=eid, part=other)
    with st.container(horizontal=True, gap="small"):
        if st.button("Xem lại từng câu", key="n3_review", width="stretch"):
            st.session_state[f"n3_pos_{eid}_{part}"] = 0
            ui.rerun()
        if st.button("Về danh sách đề", key="n3_tohome", width="stretch"):
            ui.go("n3", "home")


# ======================= BẢNG CÂU SAI =======================
def _dots(n: int) -> str:
    n = min(n, progress.WRONG_CLEAR_DAYS)
    return f'<span class="n3-dots">{"●" * n}<i>{"●" * (progress.WRONG_CLEAR_DAYS - n)}</i></span>'


def _start_wq(items, title, part):
    st.session_state["n3_wq"] = {"items": [[e, n] for e, n in items], "pos": 0, "ans": {}, "title": title,
                                 "part": part, "done_fired": False}
    ui.go("n3", "wrong_quiz", part=part or "")


def _wrong():
    _css()
    ui.back("Đề thi", "n3", "home")
    allw = progress.wrong_list()
    ui.title("Bảng câu sai", f"{len(allw)} câu · sai nhiều nhất xếp trước")
    ui.html(ui.box("blue", "LUẬT CỦA BẢNG",
                   "Câu nào làm đúng ở <b>3 ngày khác nhau</b> sẽ tự rời bảng. Sai lại thì đếm lại từ đầu. "
                   "Mỗi chấm ● là 1 ngày làm đúng."))
    fk = "n3_wfilter"
    opts = ["all"] + [p for p, _ in data.PARTS]
    cur = st.session_state.get(fk + "_v", "all")

    def _chg():
        v = st.session_state.get(fk)
        st.session_state[fk + "_v"] = v or "all"
    st.pills("Lọc theo phần", opts, format_func=lambda p: "Tất cả" if p == "all" else data.PART_LABEL[p],
             default=cur, key=fk, on_change=_chg, label_visibility="collapsed")
    cur = st.session_state.get(fk + "_v", "all")
    part = None if cur == "all" else cur
    items = progress.wrong_list(part)
    due = progress.wrong_due(part)
    if due:
        if st.button(f"Làm lại {len(due)} câu đến hạn", key="n3_wq_go", type="primary", width="stretch",
                     icon=":material/replay:"):
            _start_wq([(x["eid"], x["num"]) for x in due], "Làm lại câu sai", part)
    elif items:
        ui.html(ui.box("green", "HÔM NAY XONG ✓", "Các câu ở mục này hôm nay đã làm rồi. Mai làm tiếp nhé."))
    if not items:
        msg = "Không còn câu sai nào." if not part else f"Không còn câu sai nào ở phần {data.PART_LABEL[part]}."
        ui.html(ui.box("green", "SẠCH LƯỚI!", msg + " Như thủ môn giữ sạch lưới cả trận. Tuyệt vời!"))
        cl = storage.db().get("wrong_cleared", 0)
        if cl:
            ui.html(f'<div class="hb-muted">Đã có {cl} câu thuộc hẳn và rời bảng.</div>')
        return
    with st.container(key="n3list_wrong"):
        for x in items:
            q = data.question(x["eid"], x["num"])
            txt = _q_text(data.exam(x["eid"]), q) if q else ""
            if len(txt) > 70:
                txt = txt[:68].rsplit(" ", 1)[0] + "…"
            done = '<span class="hb-chip green">hôm nay xong ✓</span>' if x["done_today"] else ""
            inner = (f'<div class="l"><div class="nm">{ui.esc(data.exam_name(x["eid"]))} · Câu {ui.esc(x["num"])}</div>'
                     f'<div class="st">{ui.esc(txt.replace(chr(10), " "))}</div>'
                     f'<div class="st"><b style="color:var(--hb-bad)">sai {x["wrong"]} lần</b> · {_dots(len(x["days"]))} '
                     f'đúng {len(x["days"])}/3 ngày</div></div>'
                     f'<div class="r"><span class="hb-chip gray">{ui.esc(data.PART_LABEL.get(x["part"], ""))}</span>{done}</div>')
            if _row(f"w_{x['eid']}_{x['num']}", inner, f"Làm {data.exam_name(x['eid'])} câu {x['num']}"):
                _start_wq([(x["eid"], x["num"])], f"{data.exam_name(x['eid'])} · Câu {x['num']}", part)


def _wrong_quiz(params):
    _css()
    ui.back("Bảng câu sai", "n3", "wrong")
    _wq_body(params.get("part") or None)


@ui.fragment
def _wq_body(part):
    W = st.session_state.get("n3_wq")
    if not W:
        due = progress.wrong_due(part)
        W = st.session_state["n3_wq"] = {"items": [[x["eid"], x["num"]] for x in due], "pos": 0, "ans": {},
                                         "title": "Làm lại câu sai", "part": part, "done_fired": False}
    items = [(e, n) for e, n in W["items"] if data.question(e, n)]
    if not items:
        ui.title("Không có câu cần làm", "Hôm nay không còn câu sai đến hạn.")
        if st.button("Về Bảng câu sai", key="n3_wq_back", width="stretch"):
            ui.go("n3", "wrong")
        return
    pos = W["pos"]
    if pos >= len(items):
        _wq_summary(W, items)
        return
    eid, num = items[pos]
    q = data.question(eid, num)
    key = f"{eid}#{num}"
    chosen = W["ans"].get(key)

    def pick(letter, _eid=eid, _num=num, _key=key):
        ok = progress.wrong_answer(_eid, _num, letter)
        W["ans"][_key] = letter
        return ok
    nd = sum(1 for e, n in items if f"{e}#{n}" in W["ans"])
    nc = sum(1 for e, n in items if W["ans"].get(f"{e}#{n}") == (data.question(e, n) or {}).get("answer"))
    ui.html(f'<div class="n3-top"><div class="n3-where">{ui.esc(data.exam_name(eid))} · Câu {ui.esc(num)} '
            f'<span>· {ui.esc(_part_label(q))}</span></div><span class="hb-chip green">đúng {nc}/{nd}</span></div>'
            f'{ui.bar(nd / len(items))}<div class="n3-count"><span>{ui.esc(W["title"])} · câu {pos + 1}/{len(items)}</span></div>')
    it = next((x for x in progress.wrong_list() if x["eid"] == eid and str(x["num"]) == str(num)), None)
    note = f"Đã sai {it['wrong']} lần · đúng {len(it['days'])}/3 ngày" if it else ""
    _draw_question(eid, q, chosen, pick, "w", note)
    with st.container(horizontal=True, gap="small", key="n3_nav"):
        if st.button("← Câu trước", key="n3_wprev", disabled=pos == 0, width="stretch"):
            W["pos"] = pos - 1
            ui.rerun()
        lab = "Xem kết quả →" if pos == len(items) - 1 else "Câu sau →"
        if st.button(lab, key="n3_wnext", type="primary" if chosen else "secondary", width="stretch"):
            W["pos"] = pos + 1
            ui.rerun()


def _wq_summary(W, items):
    nd = sum(1 for e, n in items if f"{e}#{n}" in W["ans"])
    nc = sum(1 for e, n in items if W["ans"].get(f"{e}#{n}") == (data.question(e, n) or {}).get("answer"))
    ui.html(f'<div class="hb-title">Xong lượt làm lại!</div><div class="hb-sub">{ui.esc(W["title"])}</div>')
    ui.html(f'<div class="hb-card green n3-score"><div class="n">Đúng {nc}/{len(items)}</div>'
            f'<div class="s">{"Còn " + str(len(items) - nd) + " câu chưa làm" if nd < len(items) else "Đã làm hết"}</div></div>')
    ui.html(ui.box("blue", "NHỚ NHÉ", "Câu làm đúng hôm nay được thêm 1 chấm ●. Đủ 3 chấm ở 3 ngày khác nhau "
                   "thì câu rời bảng. Câu sai thì đếm lại từ đầu."))
    if not W.get("done_fired"):
        W["done_fired"] = True
        if progress.wrong_list() and not progress.wrong_due():
            plan.auto_done("wrong")
        if nc and nc == len(items):
            ui.fx("correct", streak=5)
    left = progress.wrong_due(W.get("part"))
    if left:
        if st.button(f"Làm tiếp {len(left)} câu đến hạn", key="n3_wq_more", type="primary", width="stretch"):
            _start_wq([(x["eid"], x["num"]) for x in left], "Làm lại câu sai", W.get("part"))
    with st.container(horizontal=True, gap="small"):
        if st.button("Về Bảng câu sai", key="n3_wq_tow", width="stretch"):
            ui.go("n3", "wrong")
        if st.button("Về danh sách đề", key="n3_wq_toh", width="stretch"):
            ui.go("n3", "home")


# ======================= NHẮC LẠI CÁCH QUÃNG =======================
_BOX_NAMES = ["Mới / vừa sai", "Nhớ 1 lần", "Nhớ 2 lần", "Khá chắc", "Thuộc"]


def _teacher_items(which: str = "mcq") -> list[dict]:
    """mcq: 240 câu của cô (Đề 1–15) · mcqA: phần trong Đề 1–7 · mcqB: Đề 8–15 · extra: bài thêm (Đề 20–28)."""
    out = []
    rng = {"mcq": range(1, 16), "mcqA": range(1, 8), "mcqB": range(8, 16)}.get(which, range(20, 29))
    for n in rng:
        ex = data.exam(data.exam_id(n))
        for q in (ex or {}).get("questions", []):
            if which == "extra" or q.get("teacher"):
                out.append({"eid": ex["id"], "num": q["num"]})
    return out


def _recall(params=None):
    _css()
    params = params or {}
    ui.back("Đề thi", "n3", "home")
    s = progress.recall_stats()
    tq = _teacher_items()
    if params.get("teacher"):
        which = str(params.get("teacher"))
        which = which if which in ("extra", "mcqA", "mcqB") else "mcq"
        items = tq if which == "mcq" else _teacher_items(which)
        name = {"extra": "BÀI THÊM CỦA CÔ", "mcqA": "CÂU CỦA CÔ · PHẦN A (ĐỀ 1–7)",
                "mcqB": "CÂU CỦA CÔ · PHẦN B (ĐỀ 8–15)"}.get(which, f"{len(tq)} CÂU CỦA CÔ")
        _k = lambda x: f'{x["eid"]}#{x["num"]}'
        unseen = [x for x in items if not progress.recall_has(_k(x))]
        items = [x for x in items if progress.recall_has(_k(x))]
        todo = [x for x in items if not progress.key_known(_k(x))]
        known = [x for x in items if progress.key_known(_k(x))]
        more = (f"<br>{len(unseen)} câu bạn chưa làm trong đề nên chưa có ở đây: bạn sẽ học chúng khi làm đề theo lịch."
                if unseen else "")
        ui.html(ui.box("orange", f"ÔN NHANH {name}",
                       f"<b>{len(todo)} câu cần ôn</b> · {len(known)} câu đã thuộc (đúng 3/3 ngày). "
                       f"Ôn câu cần ôn trước, đáp án đã đảo, thứ tự xáo trộn. Khoảng {max(1, round(len(todo) / 3))} phút, "
                       f"chia 2–3 lần được. Còn dư sức thì lướt nhanh câu đã thuộc." + more))
        if todo and st.button(f"Ôn {len(todo)} câu cần ôn", key="n3_rct_top", type="primary", width="stretch",
                              icon=":material/bolt:"):
            _start_rq(todo, teacher=which)
        if known and st.button(f"Lướt nhanh {len(known)} câu đã thuộc", key="n3_rct_skim", width="stretch",
                               type="secondary" if todo else "primary", icon=":material/fast_forward:"):
            _start_rq(known, teacher="skim" if todo else which)
    ui.title("Nhắc lại để không quên", f"{s['total']} câu đã làm · hôm nay đến hạn {s['due']} câu")
    ui.html(ui.key_box())
    ui.html(ui.box("blue", "CÁCH HOẠT ĐỘNG",
                   "Mọi câu bạn đã làm đều quay lại theo lịch: sau <b>1, 3, 6, 12, 20 ngày</b>. Làm đúng thì lần sau "
                   "cách xa hơn, làm sai thì mai gặp lại. Mỗi lần nhắc lại, thứ tự A B C D được <b>đảo</b> để bạn nhớ "
                   "nội dung chứ không nhớ vị trí. Ghi chú của bạn hiện ra sau khi chọn đáp án.<br><br>"
                   "<b>Câu của cô và câu biến đổi câu:</b> phải <b>đúng 3 ngày khác nhau</b> mới tính là thuộc "
                   "(đúng → 2 ngày → 4 ngày; sai hoặc đoán mò thì đếm lại từ 0). Câu nào bạn đã từng làm đúng, app che A B C D "
                   "5 giây để bạn thử nhớ lại; không nhớ thì bấm mở luôn."))
    ui.html('<div class="n3-boxes" style="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 12px">' + "".join(
        f'<span class="hb-chip {"red" if i == 0 else "green" if i == len(_BOX_NAMES) - 1 else "gray"}">{n}: {s["boxes"][i]}</span>'
        for i, n in enumerate(_BOX_NAMES)) + "</div>")
    due = progress.recall_due()
    if due:
        with st.container(horizontal=True, gap="small"):
            if len(due) > 20 and st.button("Làm 20 câu", key="n3_rc20", width="stretch"):
                _start_rq(due[:20])
            if st.button(f"Làm hết {len(due)} câu đến hạn", key="n3_rcall", type="primary", width="stretch",
                         icon=":material/replay:"):
                _start_rq(due)
        ui.html(f'<div class="hb-muted">Ước tính khoảng {max(1, round(len(due) * 0.35))} phút. Có thể chia nhiều lần trong ngày.</div>')
    elif s["total"]:
        ui.html(ui.box("green", "HÔM NAY XONG ✓", f"Không còn câu đến hạn. Mai có khoảng {s['tomorrow']} câu."))
    else:
        ui.html(ui.box("gray", "CHƯA CÓ CÂU NÀO", "Làm đề xong, mọi câu sẽ tự vào đây để nhắc lại."))
    if not params.get("teacher") and st.button(f"Ôn nhanh {len(tq)} câu của cô (đảo đáp án)", key="n3_rct",
                                               width="stretch", icon=":material/bolt:"):
        ui.go("n3", "recall", teacher="mcq")


def _start_rq(items, teacher=False):
    import random
    items = list(items)
    if teacher:
        random.shuffle(items)
    order = []
    for x in items:
        q = data.question(x["eid"], x["num"])
        n = len((q or {}).get("options") or [])
        perm = list(range(n))
        random.shuffle(perm)
        order.append([x["eid"], x["num"], perm])
    st.session_state["n3_rq"] = {"items": order, "pos": 0, "ans": {}, "done_fired": False, "teacher": teacher}
    ui.go("n3", "recall_quiz")


def _shuffled(q: dict, perm: list) -> dict:
    opts = q.get("options") or []
    if len(perm) != len(opts):
        return q
    newL = {LETTERS[old]: LETTERS[new] for new, old in enumerate(perm)}
    nq = dict(q)
    nq["options"] = [opts[i] for i in perm]
    ovi = q.get("options_vi") or []
    nq["options_vi"] = [ovi[i] if i < len(ovi) else "" for i in perm]
    nq["orig_answer"] = q.get("answer")
    nq["answer"] = newL.get(q.get("answer"), q.get("answer"))
    nq["why_not"] = [{**w, "key": newL.get(w.get("key"), w.get("key"))} for w in (q.get("why_not") or [])]
    nq["why_not"].sort(key=lambda w: w.get("key", ""))
    return nq


def _recall_quiz(params):
    _css()
    ui.back("Nhắc lại", "n3", "recall")
    _rq_body()


@ui.fragment
def _rq_body():
    W = st.session_state.get("n3_rq")
    if not W:
        due = progress.recall_due()
        if not due:
            ui.title("Không có câu cần nhắc lại", "Hôm nay đã xong.")
            if st.button("Về Nhắc lại", key="n3_rq_back", width="stretch"):
                ui.go("n3", "recall")
            return
        _start_rq(due)
        return
    items = [(e, n, p) for e, n, p in W["items"] if data.question(e, n)]
    pos = W["pos"]
    if pos >= len(items):
        nd = sum(1 for e, n, p in items if f"{e}#{n}" in W["ans"])
        nc = sum(1 for e, n, p in items if W["ans"].get(f"{e}#{n}", ("", False))[1])
        ui.html(f'<div class="hb-title">Xong lượt nhắc lại!</div>')
        ui.html(f'<div class="hb-card green n3-score"><div class="n">Đúng {nc}/{nd}</div>'
                f'<div class="s">Câu đúng sẽ quay lại sau vài ngày, câu sai mai gặp lại.</div></div>')
        if not W.get("done_fired"):
            W["done_fired"] = True
            if W.get("teacher") and W.get("teacher") != "skim" and nd >= len(items) * 0.8:
                w = W.get("teacher")
                plan.auto_done("recall_teacher", ref="None" if w in ("mcq", True) else w)
            elif not progress.recall_due():
                plan.auto_done("recall")
        left = progress.recall_due()
        if left and st.button(f"Làm tiếp {len(left)} câu đến hạn", key="n3_rq_more", type="primary", width="stretch"):
            _start_rq(left)
        if st.button("Về danh sách đề", key="n3_rq_toh", width="stretch"):
            ui.go("n3", "home")
        return
    eid, num, perm = items[pos]
    q0 = data.question(eid, num)
    q = _shuffled(q0, perm)
    key = f"{eid}#{num}"
    got = W["ans"].get(key)
    chosen = got[0] if got else None

    def pick(letter, _eid=eid, _num=num, _key=key, _q=q):
        ok = letter == _q.get("answer")
        progress.recall_answer(_eid, _num, ok)
        W["ans"][_key] = (letter, ok)
        return ok
    nd = len(W["ans"])
    nc = sum(1 for v in W["ans"].values() if v[1])
    ui.html(f'<div class="n3-top"><div class="n3-where">{ui.esc(data.exam_name(eid))} · Câu {ui.esc(num)} '
            f'<span>· {ui.esc(_part_label(q))}</span></div><span class="hb-chip green">đúng {nc}/{nd}</span></div>'
            f'{ui.bar(nd / len(items))}<div class="n3-count"><span>Nhắc lại · câu {pos + 1}/{len(items)}</span></div>')
    rev = W.setdefault("rev", {})
    think = None
    if not chosen and progress.is_key(eid, num) and progress.key_streak(eid, num) >= 1 and not rev.get(key):
        def think(_k=key):
            rev[_k] = True
    _draw_question(eid, q, chosen, pick, "r", think=think)
    if progress.is_key(eid, num):
        stv = progress.key_streak(eid, num)
        if stv >= progress.KEY_NEED:
            ui.html('<div style="margin:6px 0"><span class="hb-chip green">Thuộc ✓ · đúng 3/3 ngày</span></div>')
        else:
            ui.html(f'<div style="margin:6px 0"><span class="hb-chip orange">Bộ đếm: đúng {stv}/3 ngày</span> '
                    f'<span class="hb-muted">Sai hoặc đoán mò thì về 0.</span></div>')
    with st.container(horizontal=True, gap="small", key="n3_nav"):
        if st.button("← Câu trước", key="n3_rprev", disabled=pos == 0, width="stretch"):
            W["pos"] = pos - 1
            ui.rerun()
        lab = "Xem kết quả →" if pos == len(items) - 1 else "Câu sau →"
        if st.button(lab, key="n3_rnext", type="primary" if chosen else "secondary", width="stretch"):
            W["pos"] = pos + 1
            ui.rerun()


# ======================= CÀI ĐẶT ĐỀ =======================
def _settings(params):
    _css()
    eid = params.get("eid") or "de01"
    ex = data.exam(eid)
    ui.back(ex["name"] if ex else "Đề thi", "n3", "exam" if ex else "home", eid=eid)
    if not ex:
        st.warning("Không tìm thấy đề này.")
        return
    ui.title(f"Cài đặt {ex['name']}", "Chỉ áp dụng cho đề này.")
    s = progress.exam_settings(eid)
    ui.html('<div class="hb-h2">Mức giải thích mặc định</div>')

    def _lv():
        v = st.session_state.get("n3_set_level")
        if v in (0, 1, 2):
            progress.set_exam_settings(eid, level=v)
            st.session_state.pop(f"n3_level_{eid}", None)
    st.segmented_control("Mức giải thích", [0, 1, 2], format_func=lambda i: progress.LEVELS[i], default=s["level"],
                         key="n3_set_level", on_change=_lv, required=True, label_visibility="collapsed")
    s = progress.exam_settings(eid)
    ui.html(f'<div class="hb-muted" style="margin-bottom:12px">{LEVEL_HINT[s["level"]]}</div>')

    def _ao():
        progress.set_exam_settings(eid, auto_open=bool(st.session_state.get("n3_set_auto")))
    with st.container(border=True):
        st.toggle("Tự mở giải thích khi làm sai", value=s["auto_open"], key="n3_set_auto", on_change=_ao)
        ui.html('<div class="hb-muted">Làm đúng thì vẫn ẩn cho gọn, muốn xem thì bấm "Xem giải thích".</div>')

    fl = sorted(progress.flags(eid), key=lambda f: _qint(f["num"]))
    ui.html(f'<div class="hb-h2">Câu đã nhờ viết lại ({len(fl)})</div>')
    if not fl:
        ui.html('<div class="hb-muted">Chưa có câu nào. Khi làm đề, câu nào chưa hiểu thì bấm '
                '"Vẫn chưa hiểu? Nhờ viết lại câu này".</div>')
    for f in fl:
        q = data.question(eid, f["num"]) or {}
        with st.container(border=True):
            ui.html(f'<div style="display:flex;justify-content:space-between;gap:8px;align-items:center">'
                    f'<b>Câu {ui.esc(f["num"])}</b><span class="hb-chip gray">{ui.esc(_part_label(q))}</span></div>'
                    f'<div class="hb-muted" style="margin-top:4px">Ghi chú: {ui.esc(f.get("note") or "(không ghi)")} · '
                    f'mức {progress.LEVELS[f.get("level", 1)]} · {_ddmm(f.get("date"))}</div>')
            with st.container(horizontal=True, gap="small", vertical_alignment="center"):
                if st.button("Mở câu", key=f"n3_fopen_s_{f['num']}", icon=":material/open_in_new:"):
                    qs = _range_qs(ex, "1-50")
                    i = next((j for j, x in enumerate(qs) if str(x["num"]) == str(f["num"])), 0)
                    st.session_state[f"n3_pos_{eid}_1-50"] = i
                    ui.go("n3", "quiz", eid=eid, part="1-50")
                if st.button("Bỏ đánh dấu", key=f"n3_funf_s_{f['num']}", type="tertiary"):
                    progress.unflag(eid, f["num"])
                    ui.rerun()
    if fl:
        ui.html('<div class="hb-muted" style="margin-top:6px">Nhắn Claude: <b>"Viết lại các câu đã đánh dấu"</b>. '
                'Claude sẽ đọc ghi chú và viết lời giải mới cho từng câu.</div>')


# ======================= ĐIỀU PHỐI =======================
def render(view: str, params: dict):
    params = params or {}
    if view == "exam":
        _exam(params)
    elif view == "quiz":
        _quiz(params)
    elif view == "wrong":
        _wrong()
    elif view == "wrong_quiz":
        _wrong_quiz(params)
    elif view == "recall":
        _recall(params)
    elif view == "recall_quiz":
        _recall_quiz(params)
    elif view == "settings":
        _settings(params)
    else:
        _home()
