"""Ngăn 2 – Từ vựng · Ngữ pháp · Cách dịch.

Các view: home · cards (ôn thẻ) · store (kho từ) · lessons (danh sách bài) · lesson (lid, review) · translate.
Trạng thái tạm (đang ôn dở, đang làm câu nào...) nằm trong st.session_state với tiền tố "n2_".
Tiến độ thật (thẻ, bài, dịch, việc đã xong) do hàm lõi ghi.
"""
from __future__ import annotations

import random
import re
import unicodedata

import streamlit as st

from .. import clock, data, plan, progress, srs, storage, ui

SS = st.session_state
LETTERS = "ABCD"
STATUS_TXT = {"new": "Chưa học", "learning": "Đang học", "known": "Đã thuộc"}
STATUS_CHIP = {"new": "gray", "learning": "orange", "known": "green"}
STATUS_ICON = {"new": ":material/radio_button_unchecked:", "learning": ":material/autorenew:",
               "known": ":material/check_circle:"}
POS_CHOICES = ["", "danh từ", "động từ", "tính từ", "trạng từ", "cụm từ", "giới từ"]
TR_STEPS = ["Tìm động từ", "Chia cụm: Ai · Làm gì · Cái gì · Ở đâu · Khi nào", "Dịch từng cụm", "Ghép cho mượt"]

_CSS = """
<style>
/* khối to đầu trang */
[class*="st-key-n2_hero_"] { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 18px;
  padding: 14px 16px 16px; gap: 8px !important; }
[class*="st-key-n2_hero_"] [data-testid="stMarkdownContainer"], [class*="st-key-n2_row_"] [data-testid="stMarkdownContainer"],
[class*="st-key-n2_exr_"] [data-testid="stMarkdownContainer"] { margin-bottom: 0 !important; }
[class*="st-key-n2_hero_"] [data-testid="stMarkdown"] { margin-bottom: 4px; }
.st-key-n2_hero_v { background: var(--hb-green-soft); border-color: transparent; }
.st-key-n2_hero_due { background: var(--hb-orange-soft); border-color: transparent; }
.n2-ht { font-family: Lexend, sans-serif; font-weight: 700; font-size: 19px; line-height: 1.3; color: var(--hb-ink); }
.n2-hs { font-size: 15px; color: var(--hb-ink); margin-top: 2px; }
.n2-hm { font-size: 13.5px; color: var(--hb-muted); margin-top: 2px; }
.n2-kick { font-size: 12.5px; font-weight: 700; letter-spacing: .4px; color: var(--hb-muted); text-transform: uppercase; }

/* dòng danh sách bài */
[class*="st-key-n2_row_"] { border-bottom: 1px solid var(--hb-line); padding: 6px 0; min-height: 52px; flex-wrap: nowrap !important; }
[class*="st-key-n2_row_"] > div:first-child { flex: 1 1 auto; min-width: 0; }
[class*="st-key-n2_row_"] button { min-height: 40px !important; padding: 2px 14px !important; }
.n2-li { display: flex; align-items: center; gap: 10px; }
.n2-num { flex: 0 0 34px; height: 34px; border-radius: 10px; background: var(--hb-soft); color: var(--hb-ink);
  display: flex; align-items: center; justify-content: center; font-weight: 700; font-family: Lexend, sans-serif; }
.n2-num.ok { background: var(--hb-green); color: #fff; }
.n2-num.due { background: var(--hb-orange); color: #fff; }
.n2-lt { font-weight: 600; font-size: 15.5px; line-height: 1.3; color: var(--hb-ink); }
.n2-ls { font-size: 13px; color: var(--hb-muted); margin-top: 2px; }
.n2-ls .hb-chip { font-size: 12px; padding: 1px 8px; }
.n2-trow { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 6px 0; min-height: 52px;
  border-bottom: 1px solid var(--hb-line); }
.n2-trow .n2-li { flex: 1 1 auto; min-width: 0; }
.n2-pill { flex: 0 0 auto; display: inline-flex; align-items: center; min-height: 40px; padding: 0 16px; border-radius: 14px;
  border: 1.5px solid var(--hb-line); background: var(--hb-card); color: var(--hb-ink); font-weight: 600; font-size: 15.5px; }
.n2-pill.p { background: var(--hb-green); border-color: var(--hb-green); color: #fff; }
[class*="st-key-hbtap_"]:hover .n2-pill { border-color: var(--hb-green); }
.st-key-n2_list [class*="st-key-hbtap_"]:last-child .n2-trow, .st-key-n2_list > div:last-child .n2-trow { border-bottom: 0; }
.st-key-n2_list { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 18px; padding: 4px 14px; gap: 0 !important; }
.st-key-n2_list [class*="st-key-n2_row_"]:last-child { border-bottom: 0; }

/* thẻ D1–D3 */
.st-key-n2_dgrid { gap: 8px !important; align-items: stretch !important; flex-wrap: nowrap !important; }
.st-key-n2_dgrid [data-testid="stButton"] { height: 100%; }
.st-key-n2_dgrid button { height: 100% !important; }
.st-key-n2_dgrid > div { flex: 1 1 0 !important; min-width: 0 !important; }
.st-key-n2_dgrid button { width: 100% !important; min-height: 92px !important; flex-direction: column; align-items: flex-start !important;
  text-align: left; padding: 10px 10px !important; border-radius: 16px !important; }
.st-key-n2_dgrid button > div, .st-key-n2_dgrid button > div > span { justify-content: flex-start !important; width: 100%; }
.st-key-n2_dgrid button p { font-size: 13.5px !important; line-height: 1.3; text-align: left; white-space: normal; }
.st-key-n2_dgrid button p strong { font-family: Lexend, sans-serif; font-size: 16px; }

/* số liệu kho từ */
.n2-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 4px 0 10px; }
.n2-stat { border-radius: 14px; padding: 8px 10px; background: var(--hb-soft); }
.n2-stat b { display: block; font-family: Lexend, sans-serif; font-size: 22px; color: var(--hb-ink); }
.n2-stat span { font-size: 13px; color: var(--hb-muted); }
.n2-stat.g { background: var(--hb-green-soft); } .n2-stat.g b { color: var(--hb-green-ink); }
.n2-stat.o { background: var(--hb-orange-soft); } .n2-stat.o b { color: var(--hb-orange-ink); }

/* hàng nút không bao giờ xếp dọc */
[class*="st-key-n2_row2"], [class*="st-key-n2_row3"] { flex-wrap: nowrap !important; gap: 8px !important; }
[class*="st-key-n2_row2"] > div, [class*="st-key-n2_row3"] > div { flex: 1 1 0 !important; min-width: 0 !important; width: auto !important; }
[class*="st-key-n2_row2"] button, [class*="st-key-n2_row3"] button { width: 100% !important; padding-left: 4px !important; padding-right: 4px !important; }
[class*="st-key-n2_row3"] button p { font-size: 15px !important; white-space: nowrap; }

/* thẻ từ */
.hb-flash .n2-top { display: flex; justify-content: space-between; align-items: center; gap: 6px; margin-bottom: 14px; }
.hb-flash .w { line-height: 1.2; word-break: break-word; }
.hb-flash.front { padding: 20px 18px 30px; }
.hb-flash.front .w { font-size: 40px; margin: 22px 0 10px; }
.n2-hint { color: var(--hb-muted); font-size: 14px; margin-top: 18px; }
.n2-mean { font-family: Lexend, sans-serif; font-size: 25px; font-weight: 700; color: var(--hb-green-ink); margin: 8px 0 4px; line-height: 1.3; }
.n2-wsmall { font-family: Lexend, sans-serif; font-size: 22px; font-weight: 700; }
.n2-fam { margin: 0; padding: 0; list-style: none; }
.n2-fam li { font-size: 15px !important; padding: 2px 0; }
.n2-fam small { color: var(--hb-muted); font-size: 13px; }
.n2-en { font-size: 16.5px; font-weight: 600; color: var(--hb-ink); }
.n2-vi { font-size: 15px; color: var(--hb-muted); margin-top: 2px; }
.n2-en b, .n2-ex b { color: var(--hb-green-ink); }
.n2-cnt { display: flex; justify-content: space-between; align-items: center; margin: 2px 0 6px; font-size: 14px; color: var(--hb-muted); }
.n2-cnt b { color: var(--hb-ink); }
[data-testid="stLayoutWrapper"]:has(> .st-key-n2_ratebar) { position: sticky; bottom: 78px; z-index: 50; }
.st-key-n2_ratebar [data-testid="stMarkdownContainer"] { margin-bottom: 0 !important; }
.st-key-n2_ratebar { background: var(--hb-bg); padding: 8px 0 8px; gap: 4px !important; box-shadow: 0 -8px 12px -8px var(--hb-bg); }
@media (min-width: 900px) { [data-testid="stLayoutWrapper"]:has(> .st-key-n2_ratebar) { bottom: 12px; } }
@media (max-width: 899px) { [class*="st-key-n2_"] button kbd { display: none !important; } }
.stApp .st-key-n2_r_again button { background: var(--hb-bad-soft) !important; color: var(--hb-bad) !important; border-color: transparent !important; }
.stApp .st-key-n2_r_hard button { background: var(--hb-orange-soft) !important; color: var(--hb-orange-ink) !important; border-color: transparent !important; }
.stApp .st-key-n2_r_good button { background: var(--hb-green) !important; color: #fff !important; border-color: transparent !important; }
.stApp .st-key-n2_r_again button p, .stApp .st-key-n2_r_hard button p, .stApp .st-key-n2_r_good button p { color: inherit !important; }
.n2-when { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; text-align: center; font-size: 12.5px; color: var(--hb-muted); }
.st-key-n2_flip button { min-height: 56px !important; }
.st-key-n2_flip button p { font-size: 17px !important; }
.n2-res { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 8px 0 12px; }
.n2-res div { border-radius: 14px; padding: 10px; text-align: center; }
.n2-res b { display: block; font-family: Lexend, sans-serif; font-size: 26px; }
.n2-res span { font-size: 13px; }
.n2-res .g { background: var(--hb-ok-soft); color: var(--hb-ok); }
.n2-res .o { background: var(--hb-orange-soft); color: var(--hb-orange-ink); }
.n2-res .r { background: var(--hb-bad-soft); color: var(--hb-bad); }

/* kho từ: nút lọc + ô tìm (đúng màu cả sáng lẫn tối) */
.st-key-n2_sf button[data-variant="pills"] { background: var(--hb-card) !important; border: 1.5px solid var(--hb-line) !important; color: var(--hb-ink) !important; }
.st-key-n2_sf button[data-variant="pills"] p { color: inherit !important; }
.st-key-n2_sf button[data-variant="pills"][data-selected="true"] { background: var(--hb-green-soft) !important; color: var(--hb-green-ink) !important; border-color: var(--hb-green) !important; }
.st-key-n2_de svg, .st-key-n2_q svg { fill: var(--hb-muted) !important; color: var(--hb-muted) !important; }

/* hộp thoại thêm từ (nằm ngoài .stApp nên tự tô màu) */
.stDialog:has(.st-key-n2_add_w) > div, .stDialog:has(.st-key-n2_add_w) [role="dialog"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; }
.stDialog:has(.st-key-n2_add_w) h2, .stDialog:has(.st-key-n2_add_w) [data-testid="stWidgetLabel"] p,
.stDialog:has(.st-key-n2_add_w) [data-testid="stAlert"] p, .stDialog:has(.st-key-n2_add_w) svg { color: var(--hb-ink) !important; }
.stDialog:has(.st-key-n2_add_w) [role="group"], .stDialog:has(.st-key-n2_add_w) input,
.stDialog:has(.st-key-n2_add_w) [data-testid="stTextInputRootElement"] { background: var(--hb-soft) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
.stDialog:has(.st-key-n2_add_w) button[aria-label="Close"], .stDialog:has(.st-key-n2_add_w) [role="dialog"] > button { background: transparent !important; }
.stDialog:has(.st-key-n2_add_w) input::placeholder { color: var(--hb-muted) !important; }
[class*="st-key-n2_"] [role="group"] { background: var(--hb-card) !important; color: var(--hb-ink) !important; border-color: var(--hb-line) !important; }
.st-key-n2_q [data-testid="stTextInputRootElement"] { background: var(--hb-card) !important; border: 1.5px solid var(--hb-line) !important; }
[class*="st-key-n2_"] input::placeholder { color: var(--hb-muted) !important; opacity: 1; }
[class*="st-key-n2_"] [role="group"] input { background: transparent !important; color: var(--hb-ink) !important; }

/* bài học */
.n2-dots { display: flex; gap: 6px; align-items: center; margin: 4px 0 10px; }
.n2-dots i { flex: 1; height: 7px; border-radius: 9px; background: var(--hb-soft); }
.n2-dots i.on { background: var(--hb-green); }
.n2-step { font-family: Lexend, sans-serif; font-weight: 700; font-size: 21px; color: var(--hb-ink); margin: 2px 0 8px; }
.n2-line { font-size: 16.5px; line-height: 1.6; color: var(--hb-ink); margin: 0 0 8px; }
.n2-line b { color: var(--hb-green-ink); }
.hb-box .n2-bl { margin: 2px 0; }
[class*="st-key-n2_exr_"] { background: var(--hb-card); border: 1px solid var(--hb-line); border-radius: 14px; padding: 8px 6px 8px 12px;
  flex-wrap: nowrap !important; margin-bottom: 2px; }
[class*="st-key-n2_exr_"] > div:first-child { flex: 1 1 auto; min-width: 0; }
[class*="st-key-n2_exr_"] button { min-height: 40px !important; }
.n2-blank { display: inline-block; min-width: 52px; border-bottom: 2px solid var(--hb-ink); margin: 0 3px; }

/* lựa chọn trắc nghiệm */
[class*="st-key-n2_opts_"] button { justify-content: flex-start !important; text-align: left; min-height: 52px !important;
  padding: 8px 14px !important; }
[class*="st-key-n2_opts_"] button > div, [class*="st-key-n2_opts_"] button > div > span { justify-content: flex-start !important; width: 100%; }
[class*="st-key-n2_opts_"] button p { text-align: left; font-weight: 500 !important; font-size: 16px !important; white-space: normal; }
[class*="st-key-n2_chips_"] { gap: 8px !important; }
[class*="st-key-n2_chips_"] button { min-height: 46px !important; border-style: dashed !important; }
.n2-built { min-height: 58px; border: 2px dashed var(--hb-line); border-radius: 14px; padding: 8px; display: flex; flex-wrap: wrap; gap: 6px;
  align-items: center; margin-bottom: 8px; background: var(--hb-card); }
.n2-built .p { background: var(--hb-green-soft); color: var(--hb-green-ink); border-radius: 10px; padding: 6px 10px; font-weight: 600; font-size: 15px; }
.n2-built .e { color: var(--hb-muted); font-size: 14px; }
.n2-score { font-family: Lexend, sans-serif; font-size: 44px; font-weight: 700; color: var(--hb-green); line-height: 1.1; }
.n2-center { text-align: center; }
.n2-steps4 { display: flex; flex-wrap: wrap; gap: 4px 6px; align-items: center; font-size: 13.5px; color: var(--hb-ink); }
.n2-steps4 span.n { display: inline-flex; width: 20px; height: 20px; border-radius: 6px; background: var(--hb-green); color: #fff;
  font-size: 12px; font-weight: 700; align-items: center; justify-content: center; margin-right: 3px; }
.n2-steps4 i { color: var(--hb-muted); font-style: normal; }
.n2-word { font-family: Lexend, sans-serif; font-size: 22px; font-weight: 700; color: var(--hb-ink); }
</style>
"""


# ======================= TIỆN ÍCH =======================
def _fresh() -> bool:
    """Vừa mở trang này (bằng ui.go) – lần vẽ đầu tiên."""
    return bool(SS.get("n2_fresh"))


def _scroll_top():
    """Cuộn lên đầu trang ở lần vẽ tới (không tính là mở trang mới)."""
    SS["scroll_top"] = True
    if not ui.in_fragment():
        SS["n2_noentry"] = True


def _plain(s: str) -> str:
    return re.sub(r"\*\*(.+?)\*\*", r"\1", str(s or "")).replace("___", "...")


def _fold(s: str) -> str:
    s = unicodedata.normalize("NFD", str(s or "").lower().replace("đ", "d"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")


def _t() -> str:
    return clock.today().isoformat()


def _once(tag: str) -> bool:
    """True đúng 1 lần cho mỗi tag trong phiên (tránh gọi auto_done nhiều lần)."""
    k = f"n2_once_{tag}"
    if SS.get(k):
        return False
    SS[k] = True
    return True


def _lname(lid: str, short: bool = False) -> str:
    title = next((x["title"] for x in data.lessons_list() if x["id"] == lid), lid)
    if lid.startswith("d"):
        return f"D{lid[1:]}" if short else f"Cách dịch D{lid[1:]} · {title}"
    return f"Bài {int(lid[1:])}" if short else f"Bài {int(lid[1:])} · {title}"


def _lesson(lid: str) -> dict | None:
    try:
        return data.lesson(lid)
    except Exception:  # noqa: BLE001
        return None


def _lstatus(lid: str) -> tuple[str, str, str]:
    """(kiểu, chữ chip, màu chip) – kiểu: new | due | done"""
    L = progress.lesson_state(lid)
    if not L.get("first"):
        return "new", "Chưa học", "gray"
    if lid in progress.lessons_due():
        return "due", "Đến hạn ôn", "orange"
    return "done", f"✓ {L.get('score', 0)}/6", "green"


def _date_label(iso: str | None) -> str:
    from datetime import date
    if not iso:
        return ""
    d = date.fromisoformat(iso)
    return "hôm nay" if d == clock.today() else clock.label(d)


def _speak_small(text: str, key: str, label: str = "Nghe"):
    if st.button(label, key=f"n2_spk_{key}", icon=":material/volume_up:", type="tertiary"):
        ui.fx("speak", text=_plain(text))


# ======================= TRANG CHÍNH =======================
def render(view: str, params: dict):
    SS["n2_fresh"] = bool(SS.get("scroll_top")) and not SS.pop("n2_noentry", False)
    ui.html(_CSS)
    if SS.pop("n2_added", None):
        st.success(f"Đã thêm “{SS.pop('n2_added_word', '')}”. Từ này sẽ học ở lượt ôn tới.", icon=":material/check:")
    fn = {"home": _home, "cards": _cards, "store": _store, "lessons": _lessons_view, "lesson": _lesson_view,
          "translate": _translate}.get(view, _home)
    fn(params or {})


# ======================= HOME =======================
def _home(_p):
    ui.title("Từ vựng & Ngữ pháp", "Mỗi ngày: ôn thẻ từ → học 1 bài nhỏ → dịch 3 câu.")

    # --- ôn thẻ ---
    n_due, n_new = len(srs.due_ids()), len(srs.new_ids_today())
    with st.container(key="n2_hero_v"):
        if n_due + n_new:
            n = min(srs.ROUND_SIZE, n_due + n_new)
            ui.html(f'<div class="n2-kick">Việc 1</div><div class="n2-ht">Ôn từ hôm nay</div>'
                    f'<div class="n2-hs"><b>{n_due}</b> thẻ đến hạn · <b>{n_new}</b> từ mới</div>'
                    f'<div class="n2-hm">Một lượt {n} thẻ, khoảng {max(2, round(n * 20 / 60))} phút</div>')
            if st.button("Ôn từ ngay", key="n2_go_cards", type="primary", width="stretch", icon=":material/style:"):
                _new_round()
                ui.go("n2", "cards")
        elif clock.today() < clock.START_DAY and not storage.db()["cards"]:
            ui.html('<div class="n2-kick">Việc 1</div><div class="n2-ht">Ôn từ</div>'
                    '<div class="n2-hs">Từ mới bắt đầu từ <b>Chủ nhật 18/10</b> (25 từ của Đề 1).</div>')
        else:
            ui.html('<div class="n2-kick">Việc 1</div><div class="n2-ht">Ôn từ hôm nay ✓</div>'
                    '<div class="n2-hs">Hôm nay ôn xong hết rồi. Giỏi lắm!</div>')

    # --- bài tiếp theo ---
    nxt = progress.next_lesson()
    with st.container(key="n2_hero_l"):
        if nxt:
            L = _lesson(nxt) or {}
            kind = "Bài cách dịch tiếp theo" if nxt.startswith("d") else "Bài ngữ pháp tiếp theo"
            ui.html(f'<div class="n2-kick">{kind}</div><div class="n2-ht">{ui.esc(_lname(nxt))}</div>'
                    f'<div class="n2-hm">{ui.esc(L.get("subtitle", ""))} · {len(L.get("steps", []))} bước nhỏ, '
                    f'khoảng {L.get("minutes", 20)} phút</div>')
            if st.button("Học bài này", key="n2_go_next", type="primary", width="stretch", icon=":material/school:"):
                _open_lesson(nxt, False)
        else:
            ui.html('<div class="n2-ht">Đã học hết các bài ✓</div><div class="n2-hm">Chỉ còn ôn lại khi đến hạn.</div>')

    # --- bài đến hạn ôn ---
    due = progress.lessons_due()
    if due:
        with st.container(key="n2_hero_due"):
            ui.html(f'<div class="n2-kick">Đến hạn ôn lại</div>'
                    f'<div class="n2-hm">Ôn lại để không quên. Mỗi bài chỉ 6 câu, khoảng 5 phút.</div>')
            for lid in due:
                if st.button(f"Ôn lại: {_lname(lid)}", key=f"n2_due_{lid}", width="stretch", icon=":material/replay:"):
                    _open_lesson(lid, True)

    # --- luyện dịch ---
    tc = progress.translate_count()
    with st.container(key="n2_hero_t"):
        done = tc >= 3
        ui.html(f'<div class="n2-ht">Luyện dịch 3 câu hôm nay ({min(tc, 3)}/3){" ✓" if done else ""}</div>'
                f'<div class="n2-hm">Khoảng 5 phút. Dịch theo cụm, mở dần từng cụm để so.</div>')
        if st.button("Làm thêm 3 câu" if done else "Luyện dịch", key="n2_go_tr", width="stretch",
                     type="secondary" if done else "primary", icon=":material/translate:"):
            ui.go("n2", "translate")

    # --- cách dịch D1–D3 ---
    ui.html('<div class="hb-h2">Cách dịch · 3 bài</div>')
    with st.container(key="n2_dgrid", horizontal=True):
        for x in [x for x in data.lessons_list() if x["id"].startswith("d")]:
            kind, txt, _c = _lstatus(x["id"])
            mark = {"new": "Chưa học", "due": "▲ Đến hạn ôn", "done": txt}[kind]
            if st.button(f"**D{x['id'][1:]}**  \n{x['title']}  \n_{mark}_", key=f"n2_d_{x['id']}"):
                _open_lesson(x["id"], kind != "new")

    # --- 16 bài ngữ pháp ---
    ui.html('<div class="hb-h2">16 bài ngữ pháp</div>')
    _lesson_rows([x for x in data.lessons_list() if x["id"].startswith("b")], nxt)

    # --- kho từ ---
    c = srs.counts()
    ui.html(f'<div class="hb-h2">Kho từ · {sum(c.values())} từ</div>'
            f'<div class="n2-stats"><div class="n2-stat g"><b>{c["known"]}</b><span>Đã thuộc</span></div>'
            f'<div class="n2-stat o"><b>{c["learning"]}</b><span>Đang học</span></div>'
            f'<div class="n2-stat"><b>{c["new"]}</b><span>Chưa học</span></div></div>')
    with st.container(key="n2_row2_store", horizontal=True):
        if st.button("Mở kho từ", key="n2_go_store", icon=":material/search:"):
            ui.go("n2", "store")
        if st.button("+ Thêm từ", key="n2_add_home"):
            _add_dialog()


def _lesson_rows(items: list[dict], nxt: str | None):
    with st.container(key="n2_list"):
        for x in items:
            lid = x["id"]
            kind, txt, color = _lstatus(lid)
            num = lid[1:] if lid.startswith("d") else str(int(lid[1:]))
            if lid == nxt:
                chip, ncls, btn = '<span class="hb-chip blue">Học tiếp</span>', "", "Học"
            elif kind == "new":
                chip, ncls, btn = f'<span class="hb-chip gray">{txt}</span>', "", "Học"
            elif kind == "due":
                chip, ncls, btn = f'<span class="hb-chip orange">{txt}</span>', "due", "Ôn"
            else:
                nx = progress.lesson_state(lid).get("next")
                more = f" · ôn {_date_label(nx)}" if nx else " · đã thuộc"
                chip, ncls, btn = f'<span class="hb-chip green">{txt}</span>{ui.esc(more)}', "ok", "Xem"
            pill = "p" if (lid == nxt or kind == "due") else ""
            inner = (f'<div class="n2-trow"><div class="n2-li"><span class="n2-num {ncls}">{num}</span><div>'
                     f'<div class="n2-lt">{ui.esc(x["title"])}</div><div class="n2-ls">{chip}</div></div></div>'
                     f'<span class="n2-pill {pill}">{btn}</span></div>')
            if ui.tap_row(f"n2_{lid}", inner, f"{btn}: {x['title']}"):   # bấm chỗ nào trong dòng cũng mở
                _open_lesson(lid, kind != "new")


def _lessons_view(_p):
    ui.back("Từ & Ngữ pháp", "n2", "home", key="n2_ls")
    ui.title("Tất cả bài học", "16 bài ngữ pháp và 3 bài cách dịch. Học xong, app tự hẹn ngày ôn lại.")
    _lesson_rows(data.lessons_list(), progress.next_lesson())


def _open_lesson(lid: str, review: bool):
    SS.pop(f"n2_L_{lid}", None)
    ui.go("n2", "lesson", lid=lid, review=review)


# ======================= THÊM TỪ =======================
@st.dialog("Thêm từ mới")
def _add_dialog():
    ui.html('<div class="hb-muted">Gặp từ lạ trong đề? Thêm vào đây. App sẽ cho học ở lượt ôn tới.</div>')
    with st.form("n2_addform", border=False, enter_to_submit=False):
        w = st.text_input("Từ tiếng Anh *", key="n2_add_w", placeholder="ví dụ: goalkeeper")
        m = st.text_input("Nghĩa tiếng Việt *", key="n2_add_m", placeholder="ví dụ: thủ môn")
        pos = st.selectbox("Loại từ (không bắt buộc)", POS_CHOICES, key="n2_add_p",
                           format_func=lambda x: x or "Không rõ")
        ex = st.text_input("Câu ví dụ (không bắt buộc)", key="n2_add_ex")
        exv = st.text_input("Dịch câu ví dụ (không bắt buộc)", key="n2_add_exv")
        ok = st.form_submit_button("Thêm vào kho", type="primary", width="stretch")
    if ok:
        if not w.strip() or not m.strip():
            st.error("Cần điền cả **từ** và **nghĩa** nhé.")
            return
        have = [x for x in data.words().values() if x["word"].strip().lower() == w.strip().lower()]
        if have:
            st.warning(f"Từ “{w.strip()}” đã có trong kho rồi (nghĩa: {have[0]['meaning']}).")
            return
        data.add_word(w, m, pos=pos, example=ex, example_vi=exv)
        SS["n2_added"] = True
        SS["n2_added_word"] = w.strip()
        ui.rerun()


# ======================= ÔN THẺ =======================
def _new_round():
    q = srs.build_round(srs.ROUND_SIZE)
    SS["n2_round"] = {"date": _t(), "queue": q, "total": len(q), "done": 0, "words": list(q), "again": [],
                      "res": {"again": 0, "hard": 0, "good": 0}, "flip": False}


def _cards(_p):
    ui.back("Từ & Ngữ pháp", "n2", "home", key="n2_cards")
    R = SS.get("n2_round")
    if R is None or (_fresh() and (not R["queue"] or R["date"] != _t())):
        _new_round()
        R = SS["n2_round"]

    _cards_body()


@ui.fragment
def _cards_body():
    """Vùng thẻ từ: lật thẻ, chấm Quên/Mang máng/Nhớ chắc chỉ chạy lại vùng này."""
    R = SS["n2_round"]
    if R["total"] == 0:
        ui.title("Ôn thẻ từ")
        ui.html('<div class="hb-card green n2-center"><div class="n2-ht">Hôm nay ôn xong hết rồi!</div>'
                '<div class="n2-hs">Không còn thẻ nào đến hạn, cũng hết từ mới của hôm nay.</div>'
                '<div class="n2-hm">Mai quay lại nhé. App tự hẹn ngày ôn cho từng thẻ.</div></div>')
        if _once(f"vocab_{_t()}"):
            plan.auto_done("vocab")
        if st.button("Về Ngăn 2", key="n2_cards_home", width="stretch"):
            ui.go("n2", "home")
        return
    if not R["queue"]:
        _round_end(R)
        return

    wid = R["queue"][0]
    w = data.words().get(wid)
    if not w:                    # từ đã bị xóa → bỏ qua
        R["queue"].pop(0)
        R["done"] += 1
        ui.rerun()
    st_ = srs.status(wid)
    tag = ('<span class="hb-chip orange">Gặp lại</span>' if wid in R["again"] else
           '<span class="hb-chip blue">Từ mới</span>' if st_ == "new" else '<span class="hb-chip green">Ôn lại</span>')
    pos = f'<span class="hb-chip gray">{ui.esc(w.get("pos"))}</span>' if w.get("pos") else ""
    k = min(R["total"], R["done"] + 1)
    ui.html(f'<div class="n2-cnt"><span>Thẻ <b>{k}/{R["total"]}</b></span>'
            f'<span>còn {len(R["queue"])} thẻ trong lượt</span></div>{ui.bar(R["done"] / max(1, R["total"]))}'
            f'<div style="height:10px"></div>')

    if not R["flip"]:
        ui.html(f'<div class="hb-flash front"><div class="n2-top">{tag}{pos}</div>'
                f'<div class="w">{ui.esc(w["word"])}</div>'
                f'<div class="n2-hint">Tự nghĩ nghĩa trong đầu trước, rồi mới lật thẻ.</div></div>')
        with st.container(key="n2_row2_front", horizontal=True):
            if st.button("Nghe", key="n2_say_front", icon=":material/volume_up:"):
                ui.fx("speak", text=w["word"])
            if st.button("Lật thẻ", key="n2_flip", type="primary", shortcut="space", icon=":material/flip:"):
                R["flip"] = True
                ui.fx("speak", text=w["word"])
                ui.rerun()
        return

    # ---- mặt sau ----
    ipa = f'<div class="ipa">{ui.esc(w.get("ipa"))}</div>' if w.get("ipa") else ""
    ui.html(f'<div class="hb-flash"><div class="n2-top">{tag}{pos}</div>'
            f'<div class="n2-wsmall">{ui.esc(w["word"])}</div>{ipa}'
            f'<div class="n2-mean">{ui.md(w.get("meaning"))}</div></div>')
    with st.container(key="n2_row2_say", horizontal=True):
        if st.button("Nghe từ", key="n2_say_w", icon=":material/volume_up:"):
            ui.fx("speak", text=w["word"])
        if w.get("example") and st.button("Nghe câu", key="n2_say_ex", icon=":material/record_voice_over:"):
            ui.fx("speak", text=_plain(w["example"]))
    ui.html(_word_boxes(w))

    pv = srs.preview(wid)
    with st.container(key="n2_ratebar"):
        with st.container(key="n2_row3_rate", horizontal=True):
            for i, key in enumerate(("again", "hard", "good")):
                if st.button(srs.LABELS[key], key=f"n2_r_{key}", shortcut=str(i + 1)):
                    _rate(R, wid, key)
        ui.html('<div class="n2-when">' + "".join(f"<span>gặp lại {pv[k]}</span>" for k in ("again", "hard", "good"))
                + "</div>")


def _word_boxes(w: dict) -> str:
    out = []
    if w.get("example"):
        vi = f'<div class="n2-vi">{ui.md(w.get("example_vi"))}</div>' if w.get("example_vi") else ""
        out.append(ui.box("blue", "VÍ DỤ", f'<div class="n2-en">{ui.md(w["example"])}</div>{vi}'))
    fam = [f for f in (w.get("family") or []) if f.get("w")]
    if fam:
        seen, lis = set(), []
        for f in fam:
            sig = (f.get("w"), f.get("p"))
            if sig in seen:
                continue
            seen.add(sig)
            lis.append(f'<li><b>{ui.esc(f.get("w"))}</b> <small>({ui.esc(f.get("p"))})</small> – {ui.md(f.get("m"))}</li>')
        out.append(ui.box("gray", "HỌ TỪ", f'<ul class="n2-fam">{"".join(lis)}</ul>'))
    if w.get("tip"):
        out.append(ui.box("orange", "⚡ MẸO NHỚ", ui.md(w["tip"])))
    if w.get("trap"):
        tr = re.sub(r"^\s*Bẫy\s*:\s*", "", w["trap"])
        out.append(ui.box("red", "✗ BẪY", ui.md(tr)))
    return "".join(out)


def _rate(R: dict, wid: str, key: str):
    due = srs.review(wid, key)
    R["res"][key] += 1
    R["queue"].pop(0)
    if srs.is_short(due):
        R["queue"].append(wid)          # quên → gặp lại ngay trong lượt
        if wid not in R["again"]:
            R["again"].append(wid)
    else:
        R["done"] += 1
    R["flip"] = False
    progress.mark_activity()
    ui.rerun()


def _round_end(R: dict):
    r = R["res"]
    ui.title("Xong lượt!", f"Bạn vừa ôn {R['total']} thẻ.")
    ui.html(f'<div class="n2-res"><div class="g"><b>{r["good"]}</b><span>Nhớ chắc</span></div>'
            f'<div class="o"><b>{r["hard"]}</b><span>Mang máng</span></div>'
            f'<div class="r"><b>{r["again"]}</b><span>Quên</span></div></div>')
    more = srs.build_round(srs.ROUND_SIZE)
    if more:
        ui.html(ui.box("blue", "CÒN THẺ", f"Còn <b>{len(srs.due_ids())}</b> thẻ đến hạn và "
                       f"<b>{len(srs.new_ids_today())}</b> từ mới hôm nay. Làm thêm 1 lượt nữa nhé?"))
        if st.button("Ôn tiếp lượt nữa", key="n2_more_round", type="primary", width="stretch", icon=":material/style:"):
            _new_round()
            ui.rerun()
    else:
        if _once(f"vocab_{_t()}"):
            plan.auto_done("vocab")
        ui.html('<div class="hb-card green"><div class="n2-ht">Hôm nay ôn xong hết rồi! ✓</div>'
                '<div class="n2-hs">Như đội bóng tập đủ giáo án hôm nay. Mai app sẽ hẹn thẻ để ôn tiếp.</div></div>')
    des = {data.words().get(x, {}).get("de") for x in R["words"]}
    conf = [c for c in data.vocab_raw().get("confusables", []) if c.get("de") in des][:3]
    if conf:
        ui.html('<div class="hb-h2">Cặp từ dễ nhầm</div>' +
                "".join(ui.box("gray", "", ui.md(c["text"]).replace(" ↔ ", "<br>↔ ")) for c in conf))
    if st.button("Về Ngăn 2", key="n2_round_home", width="stretch"):
        ui.go("n2", "home")


# ======================= KHO TỪ =======================
def _store(_p):
    ui.back("Từ & Ngữ pháp", "n2", "home", key="n2_store")
    c = srs.counts()
    ui.title("Kho từ", f"{sum(c.values())} từ · {c['known']} đã thuộc · {c['learning']} đang học")
    if st.button("+ Thêm từ", key="n2_add_store", type="primary", width="stretch"):
        _add_dialog()
    q = st.text_input("Tìm từ", key="n2_q", placeholder="Gõ từ tiếng Anh hoặc nghĩa (không dấu cũng được)",
                      label_visibility="collapsed", icon=":material/search:")
    des = sorted({w["de"] for w in data.vocab_raw()["words"]})
    opts = ["Tất cả đề"] + [f"Đề {d}" for d in des] + ["Tự thêm"]
    de = st.selectbox("Đề", opts, key="n2_de", label_visibility="collapsed")
    sf = st.pills("Trạng thái", ["Tất cả", "Chưa học", "Đang học", "Đã thuộc"], default="Tất cả",
                  key="n2_sf", label_visibility="collapsed")

    ws = data.words()
    custom = [wid for wid in reversed(list(ws)) if ws[wid].get("custom")]
    order = custom + data.word_order()
    rev = {v: k for k, v in STATUS_TXT.items()}
    want = rev.get(sf or "Tất cả")
    fq = _fold(q.strip())
    items = []
    for wid in order:
        w = ws.get(wid)
        if not w:
            continue
        if de == "Tự thêm" and not w.get("custom"):
            continue
        if de.startswith("Đề ") and w.get("de") != int(de[3:]):
            continue
        if fq and fq not in _fold(w["word"]) and fq not in _fold(w.get("meaning")):
            continue
        s = srs.status(wid)
        if want and s != want:
            continue
        items.append((wid, w, s))

    sig = (q, de, sf)
    if SS.get("n2_store_sig") != sig:
        SS["n2_store_sig"] = sig
        SS["n2_pg"] = 0
    per = 30
    pages = max(1, (len(items) + per - 1) // per)
    pg = min(SS.get("n2_pg", 0), pages - 1)
    ui.html(f'<div class="hb-muted" style="margin:4px 0 6px">Có <b>{len(items)}</b> từ'
            f'{f" · trang {pg + 1}/{pages}" if pages > 1 else ""}</div>')
    if not items:
        ui.html(ui.box("gray", "KHÔNG THẤY", "Không có từ nào khớp. Thử gõ ít chữ hơn, hoặc chọn “Tất cả đề”."))
    for wid, w, s in items[pg * per:(pg + 1) * per]:
        label = f"**{w['word']}** — {_plain(w.get('meaning'))} · {STATUS_TXT[s]}"
        with st.expander(label, icon=STATUS_ICON[s]):
            src = "Tự thêm" if w.get("custom") else f"Đề {w.get('de')}"
            pos = f'<span class="hb-chip gray">{ui.esc(w.get("pos"))}</span> ' if w.get("pos") else ""
            ipa = f' <span class="hb-muted">{ui.esc(w.get("ipa"))}</span>' if w.get("ipa") else ""
            ui.html(f'<div><span class="n2-word">{ui.esc(w["word"])}</span>{ipa}</div>'
                    f'<div style="margin:4px 0 8px">{pos}<span class="hb-chip {STATUS_CHIP[s]}">{STATUS_TXT[s]}</span> '
                    f'<span class="hb-chip gray">{src}</span></div>'
                    f'<div class="n2-line"><b>{ui.md(w.get("meaning"))}</b></div>' + _word_boxes(w))
            with st.container(key=f"n2_row2_st_{wid}", horizontal=True):
                if st.button("Nghe từ", key=f"n2_stw_{wid}", icon=":material/volume_up:"):
                    ui.fx("speak", text=w["word"])
                if w.get("example") and st.button("Nghe câu", key=f"n2_stx_{wid}", icon=":material/record_voice_over:"):
                    ui.fx("speak", text=_plain(w["example"]))
    if pages > 1:
        with st.container(key="n2_row2_pg", horizontal=True):
            if st.button("← Trang trước", key="n2_pg_prev", disabled=pg == 0):
                SS["n2_pg"] = pg - 1
                ui.rerun()
            if st.button("Trang sau →", key="n2_pg_next", disabled=pg >= pages - 1):
                SS["n2_pg"] = pg + 1
                ui.rerun()


# ======================= CÂU HỎI (dùng chung cho bài học + luyện dịch) =======================
def _qtype(q: dict) -> str:
    return q.get("type") or "mcq"


def _q_en(q: dict) -> str:
    """Câu tiếng Anh để đọc to khi sai."""
    if _qtype(q) == "mcq":
        try:
            ans = q["options"][LETTERS.index(q["answer"])]
            return _plain(q["q"].replace("___", ans, 1)) if "___" in q["q"] else ""
        except Exception:  # noqa: BLE001
            return ""
    return _plain(q.get("en", ""))


def _order_shuffle(q: dict, seed: str) -> list[int]:
    n = len(q["chunks_vi"])
    idx = list(range(n))
    random.Random(seed).shuffle(idx)
    if idx == list(range(n)) and n > 1:
        idx = idx[1:] + idx[:1]
    return idx


def _ask(q: dict, kp: str, qs: dict, streak: dict) -> bool:
    """Vẽ 1 câu và chấm ngay. qs lưu trạng thái câu, streak = {'n': chuỗi đúng}. Trả về True khi đã chấm xong."""
    ty = _qtype(q)
    if ty == "mcq":
        ui.html(f'<div class="hb-prompt">Chọn đáp án đúng điền vào chỗ trống.</div>'
                f'<div class="hb-q">{ui.md(q["q"]).replace("___", "<span class=n2-blank></span>")}</div>')
    else:
        lead = "Chọn bản dịch đúng." if ty == "choose" else "Bấm các cụm theo đúng thứ tự để thành câu tiếng Việt."
        with st.container(key=f"n2_exr_{kp}_q", horizontal=True, vertical_alignment="center"):
            ui.html(f'<div class="hb-prompt">{lead}</div><div class="hb-q" style="margin:0">{ui.md(q["en"])}</div>')
            _speak_small(q["en"], f"{kp}_q")

    if ty == "order":
        return _ask_order(q, kp, qs, streak)

    opts = q["options"]
    if "pick" not in qs:
        with st.container(key=f"n2_opts_{kp}"):
            for i, o in enumerate(opts):
                if st.button(f"{LETTERS[i]}.  {_plain(o)}", key=f"n2_o_{kp}_{i}", width="stretch"):
                    _grade(qs, streak, LETTERS[i] == q["answer"], _q_en(q))
                    qs["pick"] = LETTERS[i]
                    ui.rerun()
        return False

    rows = []
    for i, o in enumerate(opts):
        L = LETTERS[i]
        cls = "ok" if L == q["answer"] else ("bad" if L == qs["pick"] else "")
        mark = "✓" if cls == "ok" else ("✗" if cls == "bad" else "")
        rows.append(f'<div class="hb-opt {cls}"><span class="k">{L}</span><span class="t">{ui.md(o)}</span>'
                    f'<span class="m">{mark}</span></div>')
    ui.html("".join(rows))
    ok = qs["pick"] == q["answer"]
    verdict = "✓ Đúng rồi!" if ok else f"✗ Chưa đúng. Đáp án đúng là {q['answer']}."
    ui.html(f'<div class="{"hb-ok" if ok else "hb-bad"}" style="font-size:18px;margin:2px 0 8px">{verdict}</div>')
    if q.get("why"):
        ui.html(ui.box("green", "✓ VÌ SAO ĐÚNG", ui.md(q["why"])))
    wn = {x["key"]: x["text"] for x in q.get("why_not", []) if x.get("text")}
    if not ok and wn.get(qs["pick"]):
        ui.html(ui.box("red", f"✗ VÌ SAO {qs['pick']} SAI", ui.md(wn[qs["pick"]])))
    elif ok and wn:
        body = "".join(f'<div class="n2-bl"><b>{k}.</b> {ui.md(v)}</div>' for k, v in sorted(wn.items()))
        ui.html(ui.box("red", "✗ VÌ SAO CÁC ĐÁP ÁN KIA SAI", body))
    return True


def _ask_order(q: dict, kp: str, qs: dict, streak: dict) -> bool:
    parts = q["chunks_vi"]
    sh = _order_shuffle(q, kp)
    picked = qs.setdefault("seq", [])
    if "pick" not in qs:
        built = "".join(f'<span class="p">{ui.esc(parts[j])}</span>' for j in picked) or \
            '<span class="e">Câu của bạn sẽ hiện ở đây…</span>'
        ui.html(f'<div class="n2-built">{built}</div>')
        with st.container(key=f"n2_chips_{kp}", horizontal=True):
            for j in sh:
                if j in picked:
                    continue
                if st.button(parts[j], key=f"n2_c_{kp}_{j}"):
                    picked.append(j)
                    if len(picked) == len(parts):
                        ok = [parts[x] for x in picked] == list(parts)
                        _grade(qs, streak, ok, _q_en(q))
                        qs["pick"] = list(picked)
                    ui.rerun()
        if picked and st.button("Làm lại", key=f"n2_reset_{kp}", icon=":material/undo:", type="tertiary"):
            qs["seq"] = []
            ui.rerun()
        return False
    mine = " · ".join(parts[j] for j in qs["pick"])
    right = " · ".join(parts)
    if qs["ok"]:
        ui.html('<div class="hb-ok" style="font-size:18px;margin:2px 0 8px">✓ Đúng rồi!</div>')
        ui.html(ui.box("green", "✓ CÂU DỊCH", f"<b>{ui.esc(' '.join(parts))}</b>"
                       '<div class="n2-vi">Giữ đúng thứ tự cụm như tiếng Anh: Ai → Làm gì → Cái gì → Ở đâu → Khi nào.</div>'))
    else:
        ui.html('<div class="hb-bad" style="font-size:18px;margin:2px 0 8px">✗ Chưa đúng thứ tự.</div>')
        ui.html(ui.box("red", "✗ BẠN GHÉP", ui.esc(mine)))
        ui.html(ui.box("green", "✓ THỨ TỰ ĐÚNG", f"<b>{ui.esc(right)}</b><div class='n2-vi'>"
                       "Đi theo thứ tự tiếng Anh: Ai → Làm gì → Cái gì → Ở đâu → Khi nào.</div>"))
    return True


def _grade(qs: dict, streak: dict, ok: bool, en: str):
    qs["ok"] = ok
    if ok:
        streak["n"] = streak.get("n", 0) + 1
        ui.fx("correct", streak=streak["n"])
    else:
        streak["n"] = 0
        ui.fx("wrong", **({"text": en} if en else {}))


# ======================= BÀI HỌC =======================
def _lesson_view(p):
    lid = p.get("lid") or progress.next_lesson() or "b00"
    ui.back("Từ & Ngữ pháp", "n2", "home", key="n2_lesson")
    L = _lesson(lid)
    if not L:
        ui.html(ui.box("gray", "CHƯA CÓ BÀI", "Bài này chưa có nội dung."))
        return
    key = f"n2_L_{lid}"
    S = SS.get(key)
    if S is None or (_fresh() and S["mode"] == "done"):
        learned = bool(progress.lesson_state(lid).get("first"))
        review = bool(p.get("review")) or learned
        S = SS[key] = {"mode": "practice" if review else "learn", "review": review, "step": 0, "qi": 0,
                       "qs": {}, "streak": {"n": 0}, "score": 0}
    ui.html(f'<div class="hb-title">{ui.esc(_lname(lid))}</div>'
            f'<div class="hb-sub">{ui.md(L.get("subtitle", ""))}</div>')
    _lesson_body(lid)


@ui.fragment
def _lesson_body(lid: str):
    L = _lesson(lid)
    S = SS[f"n2_L_{lid}"]
    if S["mode"] == "learn":
        _learn(lid, L, S)
    elif S["mode"] == "practice":
        if S["review"]:
            with st.expander("Xem lại bài (tất cả các bước)", icon=":material/menu_book:"):
                for i, step in enumerate(L["steps"]):
                    _step_body(lid, step, f"rv{i}", heading=True)
        _practice(lid, L, S)
    else:
        _lesson_done(lid, L, S)


def _step_body(lid: str, step: dict, tag: str, heading: bool = False):
    if heading:
        ui.html(f'<div class="hb-h2">{ui.esc(step.get("title"))}</div>')
    for line in step.get("lines", []):
        ui.html(f'<div class="n2-line">{ui.md(line)}</div>')
    for j, ex in enumerate(step.get("examples", [])):
        with st.container(key=f"n2_exr_{lid}_{tag}_{j}", horizontal=True, vertical_alignment="center", gap="small"):
            ui.html(f'<div class="n2-en">{ui.md(ex.get("en"))}</div><div class="n2-vi">{ui.md(ex.get("vi"))}</div>')
            _speak_small(ex.get("en", ""), f"{lid}_{tag}_{j}")
    for b in step.get("boxes", []):
        body = "".join(f'<div class="n2-bl">{ui.md(x)}</div>' for x in b.get("lines", []))
        ui.html(ui.box(b.get("color", "gray"), b.get("label", ""), body))
    if step.get("tip"):
        ui.html(ui.box("orange", "⚡ MẸO NHỚ", ui.md(step["tip"])))


def _learn(lid: str, L: dict, S: dict):
    steps = L["steps"]
    i = S["step"]
    dots = "".join(f'<i class="{"on" if k <= i else ""}"></i>' for k in range(len(steps)))
    ui.html(f'<div class="n2-cnt"><span>Bước <b>{i + 1}/{len(steps)}</b></span>'
            f'<span>sau đó tập 6 câu</span></div><div class="n2-dots">{dots}</div>'
            f'<div class="n2-step">{ui.esc(steps[i].get("title"))}</div>')
    _step_body(lid, steps[i], f"s{i}")
    last = i == len(steps) - 1
    with st.container(key="n2_row2_steps", horizontal=True):
        if st.button("Quay lại", key=f"n2_prev_{lid}", disabled=i == 0, icon=":material/arrow_back:"):
            S["step"] = i - 1
            _scroll_top()
            ui.rerun()
        if st.button("Tập ngay 6 câu" if last else "Tiếp", key=f"n2_next_{lid}", type="primary",
                     icon=":material/edit:" if last else ":material/arrow_forward:", icon_position="right"):
            if last:
                S["mode"] = "practice"
            else:
                S["step"] = i + 1
            _scroll_top()
            ui.rerun()


def _practice(lid: str, L: dict, S: dict):
    qs_all = L["practice"]
    n = len(qs_all)
    qi = S["qi"]
    q = qs_all[qi]
    ui.html(f'<div class="n2-cnt"><span><b>Tập ngay</b> · Câu <b>{qi + 1}/{n}</b></span>'
            f'<span>đúng {S["score"]}</span></div>{ui.bar(qi / n)}<div style="height:12px"></div>')
    qs = S["qs"].setdefault(qi, {})
    done = _ask(q, f"{lid}_{qi}", qs, S["streak"])
    if done:
        last = qi == n - 1
        if st.button("Xem kết quả" if last else "Câu tiếp", key=f"n2_qnext_{lid}_{qi}", type="primary",
                     width="stretch", icon=":material/arrow_forward:", icon_position="right"):
            S["score"] = sum(1 for x in S["qs"].values() if x.get("ok"))
            if last:
                _finish_lesson(lid, S)
            else:
                S["qi"] = qi + 1
            _scroll_top()
            ui.rerun()


def _finish_lesson(lid: str, S: dict):
    S["mode"] = "done"
    st_ = progress.lesson_state(lid)
    t = _t()
    did_today = st_.get("first") == t or t in st_.get("reviews", [])
    is_due = not st_.get("first") or (st_.get("next") and st_["next"] <= t)
    if is_due and not did_today:
        progress.lesson_finish(lid, S["score"])
        S["saved"] = True
    plan.auto_done("lesson", ref=lid)


def _lesson_done(lid: str, L: dict, S: dict):
    sc, n = S["score"], len(L["practice"])
    if sc == n:
        msg = "Tuyệt vời! Đúng hết, như sút penalty không trượt quả nào."
    elif sc >= n - 2:
        msg = "Giỏi lắm! Xem lại câu sai một chút là chắc luôn."
    else:
        msg = "Không sao cả! Cầu thủ giỏi cũng phải tập nhiều lần. Đọc lại bài rồi làm lại nhé."
    nx = progress.lesson_state(lid).get("next")
    when = (f"App sẽ nhắc bạn ôn lại bài này vào <b>{_date_label(nx)}</b>." if nx else
            "Bài này bạn đã ôn đủ rồi, không cần hẹn ôn nữa.")
    ui.html(f'<div class="hb-card green n2-center"><div class="n2-hm">Bạn đúng</div>'
            f'<div class="n2-score">{sc}/{n}</div><div class="n2-hs" style="margin-top:6px">{msg}</div></div>'
            + ui.box("blue", "ÔN CÁCH QUÃNG", when + " Ôn đúng hẹn thì nhớ rất lâu."))
    with st.expander("Xem lại bài", icon=":material/menu_book:"):
        for i, step in enumerate(L["steps"]):
            _step_body(lid, step, f"dn{i}", heading=True)
    if st.button("Về Ngăn 2", key=f"n2_ldone_home_{lid}", type="primary", width="stretch"):
        ui.go("n2", "home")
    nxt = progress.next_lesson()
    if nxt and nxt != lid and st.button(f"Học tiếp: {_lname(nxt)}", key=f"n2_ldone_next_{lid}", width="stretch"):
        _open_lesson(nxt, False)
    if st.button("Làm lại 6 câu", key=f"n2_ldone_redo_{lid}", type="tertiary", icon=":material/replay:"):
        SS[f"n2_L_{lid}"] = {"mode": "practice", "review": True, "step": 0, "qi": 0, "qs": {}, "streak": {"n": 0},
                             "score": 0}
        ui.rerun()


# ======================= LUYỆN DỊCH =======================
def _tr_items(batch: int) -> list[dict]:
    """3 câu của một đợt, cố định theo ngày (hạt giống ngẫu nhiên = ngày)."""
    pool = data.translate_pool()
    order = list(range(len(pool)))
    random.Random(_t()).shuffle(order)
    rng = random.Random(f"{_t()}#{batch}")
    take = [order[(batch * 3 + k) % len(order)] for k in range(3)] if order else []
    items = [{"kind": "pool", "i": i} for i in take]
    learned = [x["id"] for x in data.lessons_list()
               if x["id"].startswith("d") and progress.lesson_state(x["id"]).get("first")]
    les = []
    for lid in learned:
        L = _lesson(lid) or {}
        les += [{"kind": "lesson", "lid": lid, "qi": k} for k, q in enumerate(L.get("practice", []))
                if q.get("type") in ("order", "choose")]
    if les and items:
        items[rng.randrange(len(items))] = rng.choice(les)
    return items


def _translate(_p):
    ui.back("Từ & Ngữ pháp", "n2", "home", key="n2_tr")
    _translate_body()


@ui.fragment
def _translate_body():
    n = progress.translate_count()
    ui.title("Luyện dịch 3 câu", f"Hôm nay đã dịch **{n}** câu.")
    ui.html('<div class="n2-steps4">' + ' <i>→</i> '.join(
        f'<span><span class="n">{k + 1}</span>{ui.esc(s)}</span>' for k, s in enumerate(TR_STEPS)) + '</div>'
        '<div style="height:12px"></div>')

    if n > 0 and n % 3 == 0 and SS.get("n2_tr_morev") != n:
        ui.html(f'<div class="hb-card green n2-center"><div class="n2-ht">Xong 3 câu rồi! ✓</div>'
                f'<div class="n2-hs">Hôm nay bạn đã dịch {n} câu. Mỗi ngày 3 câu là đủ để quen tay.</div></div>')
        if st.button("Làm thêm 3 câu", key="n2_tr_more", width="stretch", icon=":material/add:"):
            SS["n2_tr_morev"] = n
            ui.rerun()
        if st.button("Về Ngăn 2", key="n2_tr_home", type="primary", width="stretch"):
            ui.go("n2", "home")
        return

    batch, i = n // 3, n % 3
    item = _tr_items(batch)[i] if _tr_items(batch) else None
    if not item:
        ui.html(ui.box("gray", "CHƯA CÓ CÂU", "Chưa có câu để luyện."))
        return
    tk = f"{_t()}_{batch}_{i}"
    T = SS.setdefault("n2_trs", {})
    if T.get("k") != tk:
        T.clear()
        T.update({"k": tk, "open": 0, "full": False, "qs": {}, "streak": {"n": 0}})

    ui.html(f'<div class="n2-cnt"><span>Câu <b>{i + 1}/3</b></span></div>{ui.bar(i / 3)}<div style="height:12px"></div>')

    if item["kind"] == "lesson":
        L = _lesson(item["lid"])
        q = L["practice"][item["qi"]]
        ui.html(f'<span class="hb-chip blue">Từ bài {ui.esc(_lname(item["lid"], short=True))}</span>')
        if _ask(q, f"tr{batch}{i}_{item['lid']}_{item['qi']}", T["qs"], T["streak"]):
            if st.button("Câu tiếp", key=f"n2_tr_next_{tk}", type="primary", width="stretch",
                         icon=":material/arrow_forward:", icon_position="right"):
                _tr_done()
        return

    P = data.translate_pool()[item["i"]]
    chunks = P["chunks"]
    with st.container(key=f"n2_exr_tr_{tk}", horizontal=True, vertical_alignment="center"):
        ui.html(f'<div class="hb-prompt">{ui.esc(data.exam_name(P["eid"]))} · câu {P["num"]}</div>'
                f'<div class="hb-q" style="margin:0">{ui.esc(P["en"])}</div>')
        _speak_small(P["en"], f"tr_{tk}")
    k = T["open"]
    if k == 0:
        ui.html('<div class="hb-muted" style="margin:6px 0 10px">Tự dịch trong đầu (hoặc ra giấy) trước. '
                'Rồi bấm mở từng cụm để so.</div>')
    else:
        ui.html(ui.chunks_html(chunks[:k], P["vi"] if T["full"] else ""))
    if k < len(chunks):
        if st.button(f"Hiện cụm tiếp ({k}/{len(chunks)})", key=f"n2_tr_open_{tk}", type="primary", width="stretch"):
            T["open"] = k + 1
            ui.rerun()
        return
    if not T["full"]:
        if st.button("Xem câu dịch hoàn chỉnh", key=f"n2_tr_full_{tk}", type="primary", width="stretch"):
            T["full"] = True
            ui.rerun()
        return
    ui.html('<div class="hb-h2">Bạn tự chấm: mình dịch được không?</div>')
    with st.container(key="n2_row3_self", horizontal=True):
        for lab, kk in (("Dịch được", "good"), ("Gần được", "hard"), ("Chưa được", "again")):
            if st.button(lab, key=f"n2_tr_{kk}_{tk}",
                         type="primary" if kk == "good" else "secondary"):
                if kk == "good":
                    ui.fx("correct", streak=1)
                _tr_done()


def _tr_done():
    progress.translate_add()
    n = progress.translate_count()
    if n % 3 == 0:
        plan.auto_done("translate")
    _scroll_top()
    ui.rerun()
