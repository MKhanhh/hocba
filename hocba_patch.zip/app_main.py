"""HỌC BÁ – app ôn thi Anh văn cấp độ 3 (thi 22/11/2026).

Chạy trên máy:  streamlit run streamlit_app.py
"""
import streamlit as st

st.set_page_config(page_title="Học Bá", page_icon="⚽", layout="wide", initial_sidebar_state="collapsed")

from hb import plan, storage, ui  # noqa: E402
from hb.pages import n1, n2, n3, upload  # noqa: E402

storage.init()
ui.inject_css()
ui.header()
ui.nav()

if "auto_checked" not in st.session_state or st.session_state.get("_last_tab") != ui.tab():
    plan.refresh_auto()
    st.session_state.auto_checked = True
st.session_state._last_tab = ui.tab()

ROUTES = {"n1": n1.render, "n2": n2.render, "n3": n3.render}
if ui.tab() == "n3" and ui.view() in ("upload", "docs"):
    upload.render(ui.view(), ui.params())
else:
    ROUTES.get(ui.tab(), n1.render)(ui.view(), ui.params())

ui.render_bridge()
storage.flush()
